.class public final synthetic LAo/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:Lorg/xbet/betting/event_card/presentation/delegates/a;

.field public final synthetic b:LQ4/a;


# direct methods
.method public synthetic constructor <init>(Lorg/xbet/betting/event_card/presentation/delegates/a;LQ4/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAo/j;->a:Lorg/xbet/betting/event_card/presentation/delegates/a;

    iput-object p2, p0, LAo/j;->b:LQ4/a;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LAo/j;->a:Lorg/xbet/betting/event_card/presentation/delegates/a;

    iget-object v1, p0, LAo/j;->b:LQ4/a;

    invoke-static {v0, v1}, Lorg/xbet/betting/event_card/presentation/linelive/gamecard/type14/GameCardType14ViewHolderKt;->i(Lorg/xbet/betting/event_card/presentation/delegates/a;LQ4/a;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method
