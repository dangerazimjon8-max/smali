.class public final synthetic LAo/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:Lorg/xbet/betting/event_card/presentation/delegates/a;


# direct methods
.method public synthetic constructor <init>(Lorg/xbet/betting/event_card/presentation/delegates/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAo/b;->a:Lorg/xbet/betting/event_card/presentation/delegates/a;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LAo/b;->a:Lorg/xbet/betting/event_card/presentation/delegates/a;

    check-cast p1, LQ4/a;

    invoke-static {v0, p1}, Lorg/xbet/betting/event_card/presentation/linelive/gamecard/type14/GameCardType14ViewHolderKt;->j(Lorg/xbet/betting/event_card/presentation/delegates/a;LQ4/a;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
