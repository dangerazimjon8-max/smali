.class public final LBn/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0006\u001a)\u0010\u0008\u001a\u00020\u0007*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0008\u0010\t\u001a\u001f\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0003H\u0002\u00a2\u0006\u0004\u0008\u000b\u0010\u000c\u001a\'\u0010\u000e\u001a\u00020\n2\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\u00012\u0006\u0010\u0006\u001a\u00020\u0005H\u0002\u00a2\u0006\u0004\u0008\u000e\u0010\u000f\u00a8\u0006\u0010"
    }
    d2 = {
        "Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;",
        "",
        "hyperBonusValue",
        "",
        "hyperBonusPercent",
        "",
        "includeBonus",
        "LCn/a;",
        "c",
        "(Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;DIZ)LCn/a;",
        "Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;",
        "a",
        "(DI)Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;",
        "possibleWin",
        "b",
        "(DDZ)Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;",
        "core_release"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final a(DI)Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;
    .locals 3

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmpg-double v2, p0, v0

    .line 4
    .line 5
    if-nez v2, :cond_0

    .line 6
    .line 7
    sget-object p0, Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;->Companion:Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel$a;

    .line 8
    .line 9
    invoke-virtual {p0}, Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel$a;->a()Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0

    .line 14
    :cond_0
    new-instance v0, Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 15
    .line 16
    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    invoke-direct {v0, p2, p0, p1}, Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;-><init>(Ljava/lang/String;D)V

    .line 21
    .line 22
    .line 23
    return-object v0
.end method

.method public static final b(DDZ)Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;
    .locals 1

    .line 1
    new-instance v0, Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 2
    .line 3
    if-eqz p4, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    const-wide/16 p0, 0x0

    .line 7
    .line 8
    :goto_0
    add-double/2addr p2, p0

    .line 9
    const-string p0, ""

    .line 10
    .line 11
    invoke-direct {v0, p0, p2, p3}, Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;-><init>(Ljava/lang/String;D)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public static final c(Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;DIZ)LCn/a;
    .locals 11
    .param p0    # Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    new-instance v0, LCn/a;

    .line 2
    .line 3
    invoke-virtual {p0}, Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;->getVat()Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {p0}, Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;->getSumAfterTax()Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    invoke-virtual {p0}, Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;->getPayout()Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    invoke-virtual {p0}, Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;->getTax()Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    invoke-virtual {p0}, Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;->getTaxRefund()Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 20
    .line 21
    .line 22
    move-result-object v5

    .line 23
    invoke-virtual {p0}, Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;->getPotentialWinning()Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 24
    .line 25
    .line 26
    move-result-object v6

    .line 27
    invoke-static {p1, p2, p3}, LBn/a;->a(DI)Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 28
    .line 29
    .line 30
    move-result-object v7

    .line 31
    invoke-virtual {p0}, Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;->getPotentialWinning()Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 32
    .line 33
    .line 34
    move-result-object p3

    .line 35
    invoke-virtual {p3}, Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;->getValue()D

    .line 36
    .line 37
    .line 38
    move-result-wide v8

    .line 39
    invoke-static {p1, p2, v8, v9, p4}, LBn/a;->b(DDZ)Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;

    .line 40
    .line 41
    .line 42
    move-result-object v8

    .line 43
    invoke-virtual {p0}, Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;->getPayDiff()D

    .line 44
    .line 45
    .line 46
    move-result-wide v9

    .line 47
    if-eqz p4, :cond_0

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_0
    const-wide/16 p1, 0x0

    .line 51
    .line 52
    :goto_0
    add-double/2addr v9, p1

    .line 53
    invoke-direct/range {v0 .. v10}, LCn/a;-><init>(Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;Lorg/xbet/betting/core/tax/domain/models/TaxInfoModel;D)V

    .line 54
    .line 55
    .line 56
    return-object v0
.end method
