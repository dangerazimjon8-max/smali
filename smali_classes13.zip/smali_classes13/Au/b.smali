.class public final LAu/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LAu/a$b;


# instance fields
.field public final a:Lorg/xbet/core/presentation/bonuses/k;


# direct methods
.method public constructor <init>(Lorg/xbet/core/presentation/bonuses/k;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAu/b;->a:Lorg/xbet/core/presentation/bonuses/k;

    .line 5
    .line 6
    return-void
.end method

.method public static c(Lorg/xbet/core/presentation/bonuses/k;)Ldagger/internal/h;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/xbet/core/presentation/bonuses/k;",
            ")",
            "Ldagger/internal/h<",
            "LAu/a$b;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, LAu/b;

    .line 2
    .line 3
    invoke-direct {v0, p0}, LAu/b;-><init>(Lorg/xbet/core/presentation/bonuses/k;)V

    .line 4
    .line 5
    .line 6
    invoke-static {v0}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)Landroidx/lifecycle/f0;
    .locals 0

    .line 1
    check-cast p1, LWY0/c;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, LAu/b;->b(LWY0/c;)Lorg/xbet/core/presentation/bonuses/OneXGameBonusesViewModel;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public b(LWY0/c;)Lorg/xbet/core/presentation/bonuses/OneXGameBonusesViewModel;
    .locals 1

    .line 1
    iget-object v0, p0, LAu/b;->a:Lorg/xbet/core/presentation/bonuses/k;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lorg/xbet/core/presentation/bonuses/k;->b(LWY0/c;)Lorg/xbet/core/presentation/bonuses/OneXGameBonusesViewModel;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method
