.class public final LAu/d$a$k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldagger/internal/h;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAu/d$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "k"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ldagger/internal/h<",
        "Lorg/xbet/remoteconfig/domain/usecases/i;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:LAu/c;


# direct methods
.method public constructor <init>(LAu/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAu/d$a$k;->a:LAu/c;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public a()Lorg/xbet/remoteconfig/domain/usecases/i;
    .locals 1

    .line 1
    iget-object v0, p0, LAu/d$a$k;->a:LAu/c;

    .line 2
    .line 3
    invoke-interface {v0}, LAu/c;->l()Lorg/xbet/remoteconfig/domain/usecases/i;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, Ldagger/internal/g;->d(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Lorg/xbet/remoteconfig/domain/usecases/i;

    .line 12
    .line 13
    return-object v0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, LAu/d$a$k;->a()Lorg/xbet/remoteconfig/domain/usecases/i;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
