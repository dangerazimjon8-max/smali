.class public final LAu/d$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LAu/a$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAu/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LAu/e;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LAu/d$b;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LAu/c;Lcom/xbet/onexuser/domain/entity/onexgame/configs/OneXGamesType;)LAu/a;
    .locals 1

    .line 1
    invoke-static {p1}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    invoke-static {p2}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    new-instance v0, LAu/d$a;

    .line 8
    .line 9
    invoke-direct {v0, p1, p2}, LAu/d$a;-><init>(LAu/c;Lcom/xbet/onexuser/domain/entity/onexgame/configs/OneXGamesType;)V

    .line 10
    .line 11
    .line 12
    return-object v0
.end method
