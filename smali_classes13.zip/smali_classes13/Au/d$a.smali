.class public final LAu/d$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LAu/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAu/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAu/d$a$f;,
        LAu/d$a$o;,
        LAu/d$a$l;,
        LAu/d$a$h;,
        LAu/d$a$m;,
        LAu/d$a$i;,
        LAu/d$a$j;,
        LAu/d$a$n;,
        LAu/d$a$g;,
        LAu/d$a$d;,
        LAu/d$a$c;,
        LAu/d$a$b;,
        LAu/d$a$e;,
        LAu/d$a$a;,
        LAu/d$a$k;
    }
.end annotation


# instance fields
.field public A:Lorg/xbet/core/presentation/bonuses/k;

.field public B:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LAu/a$b;",
            ">;"
        }
    .end annotation
.end field

.field public final a:LAu/d$a;

.field public b:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LDu/a;",
            ">;"
        }
    .end annotation
.end field

.field public c:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/core/domain/usecases/bonus/GetBonusesUseCase;",
            ">;"
        }
    .end annotation
.end field

.field public d:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LI8/a;",
            ">;"
        }
    .end annotation
.end field

.field public e:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/core/domain/usecases/game_info/n;",
            ">;"
        }
    .end annotation
.end field

.field public f:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LA7/j;",
            ">;"
        }
    .end annotation
.end field

.field public g:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/core/domain/usecases/game_info/GetGameBonusAllowedScenario;",
            ">;"
        }
    .end annotation
.end field

.field public h:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/core/domain/usecases/bonus/j;",
            ">;"
        }
    .end annotation
.end field

.field public i:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LX20/l;",
            ">;"
        }
    .end annotation
.end field

.field public j:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LX20/v;",
            ">;"
        }
    .end annotation
.end field

.field public k:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LX20/s;",
            ">;"
        }
    .end annotation
.end field

.field public l:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LX20/u;",
            ">;"
        }
    .end annotation
.end field

.field public m:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/core/domain/usecases/bonus/e;",
            ">;"
        }
    .end annotation
.end field

.field public n:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/core/domain/usecases/GetGameBonusModelListScenario;",
            ">;"
        }
    .end annotation
.end field

.field public o:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lcom/xbet/onexuser/domain/entity/onexgame/configs/OneXGamesType;",
            ">;"
        }
    .end annotation
.end field

.field public p:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LuZ0/e;",
            ">;"
        }
    .end annotation
.end field

.field public q:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/core/domain/usecases/GetPromoItemsUseCase;",
            ">;"
        }
    .end annotation
.end field

.field public r:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/core/domain/usecases/GetGameCraftingBonusesScenario;",
            ">;"
        }
    .end annotation
.end field

.field public s:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LU20/c;",
            ">;"
        }
    .end annotation
.end field

.field public t:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/L;",
            ">;"
        }
    .end annotation
.end field

.field public u:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LF7/a;",
            ">;"
        }
    .end annotation
.end field

.field public v:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/analytics/domain/b;",
            ">;"
        }
    .end annotation
.end field

.field public w:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LLf/c;",
            ">;"
        }
    .end annotation
.end field

.field public x:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LIQ/a;",
            ">;"
        }
    .end annotation
.end field

.field public y:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/core/domain/usecases/AddCommandScenario;",
            ">;"
        }
    .end annotation
.end field

.field public z:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/remoteconfig/domain/usecases/i;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LAu/c;Lcom/xbet/onexuser/domain/entity/onexgame/configs/OneXGamesType;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p0, p0, LAu/d$a;->a:LAu/d$a;

    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, LAu/d$a;->b(LAu/c;Lcom/xbet/onexuser/domain/entity/onexgame/configs/OneXGamesType;)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p1, p2}, LAu/d$a;->c(LAu/c;Lcom/xbet/onexuser/domain/entity/onexgame/configs/OneXGamesType;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public a(Lorg/xbet/core/presentation/bonuses/OneXGameBonusesFragment;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, LAu/d$a;->d(Lorg/xbet/core/presentation/bonuses/OneXGameBonusesFragment;)Lorg/xbet/core/presentation/bonuses/OneXGameBonusesFragment;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final b(LAu/c;Lcom/xbet/onexuser/domain/entity/onexgame/configs/OneXGamesType;)V
    .locals 3

    .line 1
    new-instance v0, LAu/d$a$f;

    .line 2
    .line 3
    invoke-direct {v0, p1}, LAu/d$a$f;-><init>(LAu/c;)V

    .line 4
    .line 5
    .line 6
    iput-object v0, p0, LAu/d$a;->b:Ldagger/internal/h;

    .line 7
    .line 8
    invoke-static {v0}, Lorg/xbet/core/domain/usecases/bonus/g;->a(Ldagger/internal/h;)Lorg/xbet/core/domain/usecases/bonus/g;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p0, LAu/d$a;->c:Ldagger/internal/h;

    .line 13
    .line 14
    new-instance v0, LAu/d$a$o;

    .line 15
    .line 16
    invoke-direct {v0, p1}, LAu/d$a$o;-><init>(LAu/c;)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, LAu/d$a;->d:Ldagger/internal/h;

    .line 20
    .line 21
    iget-object v1, p0, LAu/d$a;->b:Ldagger/internal/h;

    .line 22
    .line 23
    invoke-static {v1, v0}, Lorg/xbet/core/domain/usecases/game_info/o;->a(Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/core/domain/usecases/game_info/o;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    iput-object v0, p0, LAu/d$a;->e:Ldagger/internal/h;

    .line 28
    .line 29
    new-instance v0, LAu/d$a$l;

    .line 30
    .line 31
    invoke-direct {v0, p1}, LAu/d$a$l;-><init>(LAu/c;)V

    .line 32
    .line 33
    .line 34
    iput-object v0, p0, LAu/d$a;->f:Ldagger/internal/h;

    .line 35
    .line 36
    iget-object v1, p0, LAu/d$a;->e:Ldagger/internal/h;

    .line 37
    .line 38
    invoke-static {v1, v0}, Lorg/xbet/core/domain/usecases/game_info/j;->a(Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/core/domain/usecases/game_info/j;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    iput-object v0, p0, LAu/d$a;->g:Ldagger/internal/h;

    .line 43
    .line 44
    iget-object v0, p0, LAu/d$a;->b:Ldagger/internal/h;

    .line 45
    .line 46
    invoke-static {v0}, Lorg/xbet/core/domain/usecases/bonus/k;->a(Ldagger/internal/h;)Lorg/xbet/core/domain/usecases/bonus/k;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    iput-object v0, p0, LAu/d$a;->h:Ldagger/internal/h;

    .line 51
    .line 52
    new-instance v0, LAu/d$a$h;

    .line 53
    .line 54
    invoke-direct {v0, p1}, LAu/d$a$h;-><init>(LAu/c;)V

    .line 55
    .line 56
    .line 57
    iput-object v0, p0, LAu/d$a;->i:Ldagger/internal/h;

    .line 58
    .line 59
    new-instance v0, LAu/d$a$m;

    .line 60
    .line 61
    invoke-direct {v0, p1}, LAu/d$a$m;-><init>(LAu/c;)V

    .line 62
    .line 63
    .line 64
    iput-object v0, p0, LAu/d$a;->j:Ldagger/internal/h;

    .line 65
    .line 66
    new-instance v0, LAu/d$a$i;

    .line 67
    .line 68
    invoke-direct {v0, p1}, LAu/d$a$i;-><init>(LAu/c;)V

    .line 69
    .line 70
    .line 71
    iput-object v0, p0, LAu/d$a;->k:Ldagger/internal/h;

    .line 72
    .line 73
    new-instance v0, LAu/d$a$j;

    .line 74
    .line 75
    invoke-direct {v0, p1}, LAu/d$a$j;-><init>(LAu/c;)V

    .line 76
    .line 77
    .line 78
    iput-object v0, p0, LAu/d$a;->l:Ldagger/internal/h;

    .line 79
    .line 80
    iget-object v0, p0, LAu/d$a;->b:Ldagger/internal/h;

    .line 81
    .line 82
    invoke-static {v0}, Lorg/xbet/core/domain/usecases/bonus/f;->a(Ldagger/internal/h;)Lorg/xbet/core/domain/usecases/bonus/f;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    iput-object v0, p0, LAu/d$a;->m:Ldagger/internal/h;

    .line 87
    .line 88
    iget-object v1, p0, LAu/d$a;->l:Ldagger/internal/h;

    .line 89
    .line 90
    iget-object v2, p0, LAu/d$a;->f:Ldagger/internal/h;

    .line 91
    .line 92
    invoke-static {v1, v0, v2}, Lorg/xbet/core/domain/usecases/h;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/core/domain/usecases/h;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    iput-object v0, p0, LAu/d$a;->n:Ldagger/internal/h;

    .line 97
    .line 98
    invoke-static {p2}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 99
    .line 100
    .line 101
    move-result-object p2

    .line 102
    iput-object p2, p0, LAu/d$a;->o:Ldagger/internal/h;

    .line 103
    .line 104
    new-instance p2, LAu/d$a$n;

    .line 105
    .line 106
    invoke-direct {p2, p1}, LAu/d$a$n;-><init>(LAu/c;)V

    .line 107
    .line 108
    .line 109
    iput-object p2, p0, LAu/d$a;->p:Ldagger/internal/h;

    .line 110
    .line 111
    iget-object p2, p0, LAu/d$a;->b:Ldagger/internal/h;

    .line 112
    .line 113
    iget-object v0, p0, LAu/d$a;->d:Ldagger/internal/h;

    .line 114
    .line 115
    invoke-static {p2, v0}, Lorg/xbet/core/domain/usecases/o;->a(Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/core/domain/usecases/o;

    .line 116
    .line 117
    .line 118
    move-result-object p2

    .line 119
    iput-object p2, p0, LAu/d$a;->q:Ldagger/internal/h;

    .line 120
    .line 121
    iget-object v0, p0, LAu/d$a;->e:Ldagger/internal/h;

    .line 122
    .line 123
    iget-object v1, p0, LAu/d$a;->f:Ldagger/internal/h;

    .line 124
    .line 125
    invoke-static {p2, v0, v1}, Lorg/xbet/core/domain/usecases/i;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/core/domain/usecases/i;

    .line 126
    .line 127
    .line 128
    move-result-object p2

    .line 129
    iput-object p2, p0, LAu/d$a;->r:Ldagger/internal/h;

    .line 130
    .line 131
    new-instance p2, LAu/d$a$g;

    .line 132
    .line 133
    invoke-direct {p2, p1}, LAu/d$a$g;-><init>(LAu/c;)V

    .line 134
    .line 135
    .line 136
    iput-object p2, p0, LAu/d$a;->s:Ldagger/internal/h;

    .line 137
    .line 138
    new-instance p2, LAu/d$a$d;

    .line 139
    .line 140
    invoke-direct {p2, p1}, LAu/d$a$d;-><init>(LAu/c;)V

    .line 141
    .line 142
    .line 143
    iput-object p2, p0, LAu/d$a;->t:Ldagger/internal/h;

    .line 144
    .line 145
    new-instance p2, LAu/d$a$c;

    .line 146
    .line 147
    invoke-direct {p2, p1}, LAu/d$a$c;-><init>(LAu/c;)V

    .line 148
    .line 149
    .line 150
    iput-object p2, p0, LAu/d$a;->u:Ldagger/internal/h;

    .line 151
    .line 152
    new-instance p2, LAu/d$a$b;

    .line 153
    .line 154
    invoke-direct {p2, p1}, LAu/d$a$b;-><init>(LAu/c;)V

    .line 155
    .line 156
    .line 157
    iput-object p2, p0, LAu/d$a;->v:Ldagger/internal/h;

    .line 158
    .line 159
    invoke-static {p2}, LLf/d;->a(Ldagger/internal/h;)LLf/d;

    .line 160
    .line 161
    .line 162
    move-result-object p2

    .line 163
    iput-object p2, p0, LAu/d$a;->w:Ldagger/internal/h;

    .line 164
    .line 165
    new-instance p2, LAu/d$a$e;

    .line 166
    .line 167
    invoke-direct {p2, p1}, LAu/d$a$e;-><init>(LAu/c;)V

    .line 168
    .line 169
    .line 170
    iput-object p2, p0, LAu/d$a;->x:Ldagger/internal/h;

    .line 171
    .line 172
    new-instance p2, LAu/d$a$a;

    .line 173
    .line 174
    invoke-direct {p2, p1}, LAu/d$a$a;-><init>(LAu/c;)V

    .line 175
    .line 176
    .line 177
    iput-object p2, p0, LAu/d$a;->y:Ldagger/internal/h;

    .line 178
    .line 179
    new-instance p2, LAu/d$a$k;

    .line 180
    .line 181
    invoke-direct {p2, p1}, LAu/d$a$k;-><init>(LAu/c;)V

    .line 182
    .line 183
    .line 184
    iput-object p2, p0, LAu/d$a;->z:Ldagger/internal/h;

    .line 185
    .line 186
    return-void
.end method

.method public final c(LAu/c;Lcom/xbet/onexuser/domain/entity/onexgame/configs/OneXGamesType;)V
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, LAu/d$a;->c:Ldagger/internal/h;

    .line 4
    .line 5
    iget-object v2, v0, LAu/d$a;->g:Ldagger/internal/h;

    .line 6
    .line 7
    iget-object v3, v0, LAu/d$a;->h:Ldagger/internal/h;

    .line 8
    .line 9
    iget-object v4, v0, LAu/d$a;->i:Ldagger/internal/h;

    .line 10
    .line 11
    iget-object v5, v0, LAu/d$a;->j:Ldagger/internal/h;

    .line 12
    .line 13
    iget-object v6, v0, LAu/d$a;->k:Ldagger/internal/h;

    .line 14
    .line 15
    iget-object v7, v0, LAu/d$a;->n:Ldagger/internal/h;

    .line 16
    .line 17
    iget-object v8, v0, LAu/d$a;->o:Ldagger/internal/h;

    .line 18
    .line 19
    iget-object v9, v0, LAu/d$a;->p:Ldagger/internal/h;

    .line 20
    .line 21
    iget-object v10, v0, LAu/d$a;->r:Ldagger/internal/h;

    .line 22
    .line 23
    iget-object v11, v0, LAu/d$a;->s:Ldagger/internal/h;

    .line 24
    .line 25
    invoke-static {}, Lorg/xbet/core/domain/usecases/q;->a()Lorg/xbet/core/domain/usecases/q;

    .line 26
    .line 27
    .line 28
    move-result-object v12

    .line 29
    iget-object v13, v0, LAu/d$a;->t:Ldagger/internal/h;

    .line 30
    .line 31
    iget-object v14, v0, LAu/d$a;->u:Ldagger/internal/h;

    .line 32
    .line 33
    iget-object v15, v0, LAu/d$a;->w:Ldagger/internal/h;

    .line 34
    .line 35
    move-object/from16 v16, v1

    .line 36
    .line 37
    iget-object v1, v0, LAu/d$a;->x:Ldagger/internal/h;

    .line 38
    .line 39
    move-object/from16 v17, v1

    .line 40
    .line 41
    iget-object v1, v0, LAu/d$a;->y:Ldagger/internal/h;

    .line 42
    .line 43
    move-object/from16 v18, v1

    .line 44
    .line 45
    iget-object v1, v0, LAu/d$a;->z:Ldagger/internal/h;

    .line 46
    .line 47
    move-object/from16 v19, v18

    .line 48
    .line 49
    move-object/from16 v18, v1

    .line 50
    .line 51
    move-object/from16 v1, v16

    .line 52
    .line 53
    move-object/from16 v16, v17

    .line 54
    .line 55
    move-object/from16 v17, v19

    .line 56
    .line 57
    invoke-static/range {v1 .. v18}, Lorg/xbet/core/presentation/bonuses/k;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/core/presentation/bonuses/k;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    iput-object v1, v0, LAu/d$a;->A:Lorg/xbet/core/presentation/bonuses/k;

    .line 62
    .line 63
    invoke-static {v1}, LAu/b;->c(Lorg/xbet/core/presentation/bonuses/k;)Ldagger/internal/h;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    iput-object v1, v0, LAu/d$a;->B:Ldagger/internal/h;

    .line 68
    .line 69
    return-void
.end method

.method public final d(Lorg/xbet/core/presentation/bonuses/OneXGameBonusesFragment;)Lorg/xbet/core/presentation/bonuses/OneXGameBonusesFragment;
    .locals 1
    .annotation build Lcom/google/errorprone/annotations/CanIgnoreReturnValue;
    .end annotation

    .line 1
    iget-object v0, p0, LAu/d$a;->B:Ldagger/internal/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LAu/a$b;

    .line 8
    .line 9
    invoke-static {p1, v0}, Lorg/xbet/core/presentation/bonuses/e;->a(Lorg/xbet/core/presentation/bonuses/OneXGameBonusesFragment;LAu/a$b;)V

    .line 10
    .line 11
    .line 12
    return-object p1
.end method
