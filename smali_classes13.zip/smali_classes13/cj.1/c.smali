.class public final synthetic Lcj/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:Lx7/f;


# direct methods
.method public synthetic constructor <init>(Lx7/f;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcj/c;->a:Lx7/f;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lcj/c;->a:Lx7/f;

    invoke-static {v0}, Lcj/d;->b(Lx7/f;)Lgj/a;

    move-result-object v0

    return-object v0
.end method
