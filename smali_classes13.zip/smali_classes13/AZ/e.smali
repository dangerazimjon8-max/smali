.class public interface abstract LAZ/e;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\"\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008f\u0018\u00002\u00020\u0001J`\u0010\u0011\u001a\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u00100\u000f0\u000e2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u000c\u0010\u0008\u001a\u0008\u0012\u0004\u0012\u00020\u00070\u00062\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u00072\u000c\u0010\u000c\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u00062\u0006\u0010\r\u001a\u00020\u0007H\u00a6B\u00a2\u0006\u0004\u0008\u0011\u0010\u0012\u00a8\u0006\u0013\u00c0\u0006\u0003"
    }
    d2 = {
        "LAZ/e;",
        "",
        "Lorg/xbet/feed/domain/models/LineLiveScreenType;",
        "screenType",
        "",
        "countryId",
        "",
        "",
        "champIds",
        "",
        "cutCoef",
        "userId",
        "countries",
        "localTime",
        "Lkotlinx/coroutines/flow/e;",
        "",
        "LcP/c;",
        "a",
        "(Lorg/xbet/feed/domain/models/LineLiveScreenType;ILjava/util/Set;ZJLjava/util/Set;JLkotlin/coroutines/e;)Ljava/lang/Object;",
        "api_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# virtual methods
.method public abstract a(Lorg/xbet/feed/domain/models/LineLiveScreenType;ILjava/util/Set;ZJLjava/util/Set;JLkotlin/coroutines/e;)Ljava/lang/Object;
    .param p1    # Lorg/xbet/feed/domain/models/LineLiveScreenType;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3    # Ljava/util/Set;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p7    # Ljava/util/Set;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p10    # Lkotlin/coroutines/e;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/xbet/feed/domain/models/LineLiveScreenType;",
            "I",
            "Ljava/util/Set<",
            "Ljava/lang/Long;",
            ">;ZJ",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;J",
            "Lkotlin/coroutines/e<",
            "-",
            "Lkotlinx/coroutines/flow/e<",
            "+",
            "Ljava/util/List<",
            "+",
            "LcP/c;",
            ">;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method
