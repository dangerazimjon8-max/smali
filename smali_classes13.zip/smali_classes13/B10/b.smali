.class public final LB10/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a#\u0010\u0006\u001a\u00020\u0005*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0003H\u0000\u00a2\u0006\u0004\u0008\u0006\u0010\u0007\u00a8\u0006\u0008"
    }
    d2 = {
        "Lorg/xbet/finsecurity/impl/domain/b;",
        "",
        "currency",
        "",
        "limitSelected",
        "LC10/e;",
        "a",
        "(Lorg/xbet/finsecurity/impl/domain/b;Ljava/lang/String;Z)LC10/e;",
        "impl_release"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final a(Lorg/xbet/finsecurity/impl/domain/b;Ljava/lang/String;Z)LC10/e;
    .locals 6
    .param p0    # Lorg/xbet/finsecurity/impl/domain/b;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    new-instance v0, LC10/e;

    .line 2
    .line 3
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/b;->a()Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-static {v1}, LC10/c;->b(Lorg/xbet/finsecurity/impl/domain/LimitType;)Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/b;->b()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    invoke-static {v2}, LC10/d;->a(I)I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    sget-object v3, LE7/k;->a:LE7/k;

    .line 20
    .line 21
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/b;->b()I

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    int-to-double v4, p0

    .line 26
    sget-object p0, Lcom/xbet/onexcore/utils/ValueType;->AMOUNT:Lcom/xbet/onexcore/utils/ValueType;

    .line 27
    .line 28
    invoke-virtual {v3, v4, v5, p1, p0}, LE7/k;->e(DLjava/lang/String;Lcom/xbet/onexcore/utils/ValueType;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    invoke-static {p0}, LC10/b;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-static {p2}, LC10/a;->a(Z)Z

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    const/4 v5, 0x0

    .line 41
    invoke-direct/range {v0 .. v5}, LC10/e;-><init>(Lorg/xbet/finsecurity/impl/domain/LimitType;ILjava/lang/String;ZLkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 42
    .line 43
    .line 44
    return-object v0
.end method
