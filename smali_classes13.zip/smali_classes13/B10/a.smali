.class public final LB10/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a+\u0010\u0008\u001a\u00020\u0007*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0005H\u0000\u00a2\u0006\u0004\u0008\u0008\u0010\t\u00a8\u0006\n"
    }
    d2 = {
        "Lorg/xbet/finsecurity/impl/domain/LimitModel;",
        "",
        "currency",
        "LmZ0/f;",
        "resourceManager",
        "",
        "needDivider",
        "LC10/f;",
        "a",
        "(Lorg/xbet/finsecurity/impl/domain/LimitModel;Ljava/lang/String;LmZ0/f;Z)LC10/f;",
        "impl_release"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final a(Lorg/xbet/finsecurity/impl/domain/LimitModel;Ljava/lang/String;LmZ0/f;Z)LC10/f;
    .locals 15
    .param p0    # Lorg/xbet/finsecurity/impl/domain/LimitModel;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LmZ0/f;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    new-instance v1, LC10/f;

    .line 4
    .line 5
    move-object v2, v1

    .line 6
    invoke-static {p0}, LC10/f$a$b;->b(Lorg/xbet/finsecurity/impl/domain/LimitModel;)Lorg/xbet/finsecurity/impl/domain/LimitModel;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    move-object v3, v2

    .line 11
    invoke-static {v0}, LC10/f$a$a;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->f()Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    invoke-static {v4}, Lorg/xbet/finsecurity/impl/presentation/k;->a(Lorg/xbet/finsecurity/impl/domain/LimitType;)I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    const/4 v5, 0x0

    .line 24
    new-array v6, v5, [Ljava/lang/Object;

    .line 25
    .line 26
    move-object/from16 v7, p2

    .line 27
    .line 28
    invoke-interface {v7, v4, v6}, LmZ0/f;->a(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->h()Lorg/xbet/finsecurity/impl/domain/LimitModel;

    .line 33
    .line 34
    .line 35
    move-result-object v6

    .line 36
    const/4 v7, 0x1

    .line 37
    if-eqz v6, :cond_0

    .line 38
    .line 39
    move-object v6, v3

    .line 40
    move-object v3, v4

    .line 41
    const/4 v4, 0x1

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    move-object v6, v3

    .line 44
    move-object v3, v4

    .line 45
    const/4 v4, 0x0

    .line 46
    :goto_0
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->h()Lorg/xbet/finsecurity/impl/domain/LimitModel;

    .line 47
    .line 48
    .line 49
    move-result-object v8

    .line 50
    const-string v9, ""

    .line 51
    .line 52
    if-eqz v8, :cond_1

    .line 53
    .line 54
    sget-object v8, LE7/k;->a:LE7/k;

    .line 55
    .line 56
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->h()Lorg/xbet/finsecurity/impl/domain/LimitModel;

    .line 57
    .line 58
    .line 59
    move-result-object v10

    .line 60
    invoke-virtual {v10}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->g()I

    .line 61
    .line 62
    .line 63
    move-result v10

    .line 64
    int-to-double v10, v10

    .line 65
    sget-object v12, Lcom/xbet/onexcore/utils/ValueType;->AMOUNT:Lcom/xbet/onexcore/utils/ValueType;

    .line 66
    .line 67
    invoke-virtual {v8, v10, v11, v0, v12}, LE7/k;->e(DLjava/lang/String;Lcom/xbet/onexcore/utils/ValueType;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v8

    .line 71
    goto :goto_1

    .line 72
    :cond_1
    move-object v8, v9

    .line 73
    :goto_1
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->h()Lorg/xbet/finsecurity/impl/domain/LimitModel;

    .line 74
    .line 75
    .line 76
    move-result-object v10

    .line 77
    if-eqz v10, :cond_2

    .line 78
    .line 79
    move-object v10, v6

    .line 80
    const/4 v6, 0x1

    .line 81
    goto :goto_2

    .line 82
    :cond_2
    move-object v10, v6

    .line 83
    const/4 v6, 0x0

    .line 84
    :goto_2
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->e()Lorg/xbet/finsecurity/impl/domain/LimitState;

    .line 85
    .line 86
    .line 87
    move-result-object v11

    .line 88
    sget-object v12, Lorg/xbet/finsecurity/impl/domain/LimitState;->ACTIVE:Lorg/xbet/finsecurity/impl/domain/LimitState;

    .line 89
    .line 90
    if-ne v11, v12, :cond_3

    .line 91
    .line 92
    sget-object v9, LE7/k;->a:LE7/k;

    .line 93
    .line 94
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->g()I

    .line 95
    .line 96
    .line 97
    move-result v11

    .line 98
    int-to-double v13, v11

    .line 99
    sget-object v11, Lcom/xbet/onexcore/utils/ValueType;->AMOUNT:Lcom/xbet/onexcore/utils/ValueType;

    .line 100
    .line 101
    invoke-virtual {v9, v13, v14, v0, v11}, LE7/k;->e(DLjava/lang/String;Lcom/xbet/onexcore/utils/ValueType;)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v9

    .line 105
    :cond_3
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->e()Lorg/xbet/finsecurity/impl/domain/LimitState;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    sget-object v11, Lorg/xbet/finsecurity/impl/domain/LimitState;->NONE:Lorg/xbet/finsecurity/impl/domain/LimitState;

    .line 110
    .line 111
    if-eq v0, v11, :cond_4

    .line 112
    .line 113
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->e()Lorg/xbet/finsecurity/impl/domain/LimitState;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    if-eq v0, v12, :cond_4

    .line 118
    .line 119
    move-object v5, v8

    .line 120
    const/4 v0, 0x0

    .line 121
    const/4 v8, 0x1

    .line 122
    goto :goto_3

    .line 123
    :cond_4
    move-object v5, v8

    .line 124
    const/4 v0, 0x0

    .line 125
    const/4 v8, 0x0

    .line 126
    :goto_3
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->e()Lorg/xbet/finsecurity/impl/domain/LimitState;

    .line 127
    .line 128
    .line 129
    move-result-object v13

    .line 130
    if-eq v13, v11, :cond_5

    .line 131
    .line 132
    invoke-virtual {p0}, Lorg/xbet/finsecurity/impl/domain/LimitModel;->e()Lorg/xbet/finsecurity/impl/domain/LimitState;

    .line 133
    .line 134
    .line 135
    move-result-object p0

    .line 136
    if-ne p0, v12, :cond_5

    .line 137
    .line 138
    const/4 v0, 0x1

    .line 139
    :cond_5
    const/4 v11, 0x0

    .line 140
    move-object v7, v9

    .line 141
    move v9, v0

    .line 142
    move-object v0, v10

    .line 143
    move/from16 v10, p3

    .line 144
    .line 145
    invoke-direct/range {v0 .. v11}, LC10/f;-><init>(Lorg/xbet/finsecurity/impl/domain/LimitModel;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZLjava/lang/String;ZZZLkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 146
    .line 147
    .line 148
    return-object v0
.end method
