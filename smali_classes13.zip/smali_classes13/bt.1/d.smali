.class public final Lbt/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldagger/internal/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ldagger/internal/d<",
        "Lbt/c;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lg7/c;",
            ">;"
        }
    .end annotation
.end field

.field public final b:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lt7/a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ldagger/internal/h;Ldagger/internal/h;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "Lg7/c;",
            ">;",
            "Ldagger/internal/h<",
            "Lt7/a;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbt/d;->a:Ldagger/internal/h;

    .line 5
    .line 6
    iput-object p2, p0, Lbt/d;->b:Ldagger/internal/h;

    .line 7
    .line 8
    return-void
.end method

.method public static a(Ldagger/internal/h;Ldagger/internal/h;)Lbt/d;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "Lg7/c;",
            ">;",
            "Ldagger/internal/h<",
            "Lt7/a;",
            ">;)",
            "Lbt/d;"
        }
    .end annotation

    .line 1
    new-instance v0, Lbt/d;

    .line 2
    .line 3
    invoke-direct {v0, p0, p1}, Lbt/d;-><init>(Ldagger/internal/h;Ldagger/internal/h;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public static c(Lg7/c;Lt7/a;)Lbt/c;
    .locals 1

    .line 1
    new-instance v0, Lbt/c;

    .line 2
    .line 3
    invoke-direct {v0, p0, p1}, Lbt/c;-><init>(Lg7/c;Lt7/a;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method


# virtual methods
.method public b()Lbt/c;
    .locals 2

    .line 1
    iget-object v0, p0, Lbt/d;->a:Ldagger/internal/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lg7/c;

    .line 8
    .line 9
    iget-object v1, p0, Lbt/d;->b:Ldagger/internal/h;

    .line 10
    .line 11
    invoke-interface {v1}, Lib/a;->get()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lt7/a;

    .line 16
    .line 17
    invoke-static {v0, v1}, Lbt/d;->c(Lg7/c;Lt7/a;)Lbt/c;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lbt/d;->b()Lbt/c;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
