.class public final Lbt/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldagger/internal/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ldagger/internal/d<",
        "Lbt/a;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lt7/b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ldagger/internal/h;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "Lt7/b;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbt/b;->a:Ldagger/internal/h;

    .line 5
    .line 6
    return-void
.end method

.method public static a(Ldagger/internal/h;)Lbt/b;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "Lt7/b;",
            ">;)",
            "Lbt/b;"
        }
    .end annotation

    .line 1
    new-instance v0, Lbt/b;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lbt/b;-><init>(Ldagger/internal/h;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public static c(Lt7/b;)Lbt/a;
    .locals 1

    .line 1
    new-instance v0, Lbt/a;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lbt/a;-><init>(Lt7/b;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method


# virtual methods
.method public b()Lbt/a;
    .locals 1

    .line 1
    iget-object v0, p0, Lbt/b;->a:Ldagger/internal/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lt7/b;

    .line 8
    .line 9
    invoke-static {v0}, Lbt/b;->c(Lt7/b;)Lbt/a;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lbt/b;->b()Lbt/a;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
