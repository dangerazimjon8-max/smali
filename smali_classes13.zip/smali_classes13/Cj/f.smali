.class public final LCj/f;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\t\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0007\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008 \u0008\u0000\u0018\u00002\u00020\u0001B\u009f\u0001\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0008\u0010\t\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\n\u001a\u00020\u0005\u0012\u0006\u0010\u000c\u001a\u00020\u000b\u0012\u0006\u0010\u000e\u001a\u00020\r\u0012\u0006\u0010\u000f\u001a\u00020\r\u0012\u0006\u0010\u0010\u001a\u00020\r\u0012\u0006\u0010\u0011\u001a\u00020\r\u0012\u0006\u0010\u0012\u001a\u00020\u0005\u0012\u0006\u0010\u0013\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0014\u001a\u00020\u0007\u0012\u000c\u0010\u0017\u001a\u0008\u0012\u0004\u0012\u00020\u00160\u0015\u0012\u000c\u0010\u0019\u001a\u0008\u0012\u0004\u0012\u00020\u00180\u0015\u0012\u0006\u0010\u001a\u001a\u00020\r\u00a2\u0006\u0004\u0008\u001b\u0010\u001cR\u001a\u0010\u0003\u001a\u00020\u00028\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010\u001d\u001a\u0004\u0008\u001e\u0010\u001fR\u001a\u0010\u0004\u001a\u00020\u00028\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0004\u0010\u001d\u001a\u0004\u0008 \u0010\u001fR\u001a\u0010\u0006\u001a\u00020\u00058\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0006\u0010!\u001a\u0004\u0008\"\u0010#R\u001a\u0010\u0008\u001a\u00020\u00078\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0008\u0010$\u001a\u0004\u0008\u0008\u0010%R\u001c\u0010\t\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\t\u0010!\u001a\u0004\u0008&\u0010#R\u001a\u0010\n\u001a\u00020\u00058\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\n\u0010!\u001a\u0004\u0008\'\u0010#R\u001a\u0010\u000c\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u000c\u0010(\u001a\u0004\u0008)\u0010*R\u001a\u0010\u000e\u001a\u00020\r8\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u000e\u0010+\u001a\u0004\u0008,\u0010-R\u001a\u0010\u000f\u001a\u00020\r8\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u000f\u0010+\u001a\u0004\u0008.\u0010-R\u001a\u0010\u0010\u001a\u00020\r8\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0010\u0010+\u001a\u0004\u0008/\u0010-R\u001a\u0010\u0011\u001a\u00020\r8\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0011\u0010+\u001a\u0004\u00080\u0010-R\u001a\u0010\u0012\u001a\u00020\u00058\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0012\u0010!\u001a\u0004\u00081\u0010#R\u001a\u0010\u0013\u001a\u00020\u00028\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0013\u0010\u001d\u001a\u0004\u00082\u0010\u001fR\u001a\u0010\u0014\u001a\u00020\u00078\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0014\u0010$\u001a\u0004\u0008\u0014\u0010%R \u0010\u0017\u001a\u0008\u0012\u0004\u0012\u00020\u00160\u00158\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0017\u00103\u001a\u0004\u00084\u00105R \u0010\u0019\u001a\u0008\u0012\u0004\u0012\u00020\u00180\u00158\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0019\u00103\u001a\u0004\u00086\u00105R\u001a\u0010\u001a\u001a\u00020\r8\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u001a\u0010+\u001a\u0004\u00087\u0010-\u00a8\u00068"
    }
    d2 = {
        "LCj/f;",
        "",
        "",
        "userId",
        "userBonusId",
        "",
        "appGUID",
        "",
        "isApprovedBet",
        "promo",
        "vid",
        "",
        "sum",
        "",
        "source",
        "partner",
        "checkCf",
        "cfView",
        "lng",
        "sport",
        "isNewAlterBuilder",
        "",
        "LCj/i;",
        "groups",
        "LCj/a;",
        "events",
        "oneClickBet",
        "<init>",
        "(JJLjava/lang/String;ZLjava/lang/String;Ljava/lang/String;DIIIILjava/lang/String;JZLjava/util/List;Ljava/util/List;I)V",
        "J",
        "getUserId",
        "()J",
        "getUserBonusId",
        "Ljava/lang/String;",
        "getAppGUID",
        "()Ljava/lang/String;",
        "Z",
        "()Z",
        "getPromo",
        "getVid",
        "D",
        "getSum",
        "()D",
        "I",
        "getSource",
        "()I",
        "getPartner",
        "getCheckCf",
        "getCfView",
        "getLng",
        "getSport",
        "Ljava/util/List;",
        "getGroups",
        "()Ljava/util/List;",
        "getEvents",
        "getOneClickBet",
        "impl_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final appGUID:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "AppGuid"
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final cfView:I
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "CfView"
    .end annotation
.end field

.field private final checkCf:I
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "CheckCf"
    .end annotation
.end field

.field private final events:Ljava/util/List;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "Events"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCj/a;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final groups:Ljava/util/List;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "Groups"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCj/i;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final isApprovedBet:Z
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "ApprovedBet"
    .end annotation
.end field

.field private final isNewAlterBuilder:Z
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "IsNewAlterBuilder"
    .end annotation
.end field

.field private final lng:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "Lng"
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final oneClickBet:I
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "OneClickBet"
    .end annotation
.end field

.field private final partner:I
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "partner"
    .end annotation
.end field

.field private final promo:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "promo"
    .end annotation
.end field

.field private final source:I
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "Source"
    .end annotation
.end field

.field private final sport:J
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "Sport"
    .end annotation
.end field

.field private final sum:D
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "Summ"
    .end annotation
.end field

.field private final userBonusId:J
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "UserIdBonus"
    .end annotation
.end field

.field private final userId:J
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "UserId"
    .end annotation
.end field

.field private final vid:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "Vid"
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public constructor <init>(JJLjava/lang/String;ZLjava/lang/String;Ljava/lang/String;DIIIILjava/lang/String;JZLjava/util/List;Ljava/util/List;I)V
    .locals 0
    .param p5    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p8    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p15    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p19    # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p20    # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JJ",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "DIIII",
            "Ljava/lang/String;",
            "JZ",
            "Ljava/util/List<",
            "LCj/i;",
            ">;",
            "Ljava/util/List<",
            "LCj/a;",
            ">;I)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-wide p1, p0, LCj/f;->userId:J

    .line 3
    iput-wide p3, p0, LCj/f;->userBonusId:J

    .line 4
    iput-object p5, p0, LCj/f;->appGUID:Ljava/lang/String;

    .line 5
    iput-boolean p6, p0, LCj/f;->isApprovedBet:Z

    .line 6
    iput-object p7, p0, LCj/f;->promo:Ljava/lang/String;

    .line 7
    iput-object p8, p0, LCj/f;->vid:Ljava/lang/String;

    .line 8
    iput-wide p9, p0, LCj/f;->sum:D

    .line 9
    iput p11, p0, LCj/f;->source:I

    .line 10
    iput p12, p0, LCj/f;->partner:I

    .line 11
    iput p13, p0, LCj/f;->checkCf:I

    .line 12
    iput p14, p0, LCj/f;->cfView:I

    .line 13
    iput-object p15, p0, LCj/f;->lng:Ljava/lang/String;

    move-wide/from16 p1, p16

    .line 14
    iput-wide p1, p0, LCj/f;->sport:J

    move/from16 p1, p18

    .line 15
    iput-boolean p1, p0, LCj/f;->isNewAlterBuilder:Z

    move-object/from16 p1, p19

    .line 16
    iput-object p1, p0, LCj/f;->groups:Ljava/util/List;

    move-object/from16 p1, p20

    .line 17
    iput-object p1, p0, LCj/f;->events:Ljava/util/List;

    move/from16 p1, p21

    .line 18
    iput p1, p0, LCj/f;->oneClickBet:I

    return-void
.end method

.method public synthetic constructor <init>(JJLjava/lang/String;ZLjava/lang/String;Ljava/lang/String;DIIIILjava/lang/String;JZLjava/util/List;Ljava/util/List;IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 23

    move/from16 v0, p22

    and-int/lit16 v0, v0, 0x2000

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    const/16 v19, 0x1

    :goto_0
    move-object/from16 v1, p0

    move-wide/from16 v2, p1

    move-wide/from16 v4, p3

    move-object/from16 v6, p5

    move/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v9, p8

    move-wide/from16 v10, p9

    move/from16 v12, p11

    move/from16 v13, p12

    move/from16 v14, p13

    move/from16 v15, p14

    move-object/from16 v16, p15

    move-wide/from16 v17, p16

    move-object/from16 v20, p19

    move-object/from16 v21, p20

    move/from16 v22, p21

    goto :goto_1

    :cond_0
    move/from16 v19, p18

    goto :goto_0

    .line 19
    :goto_1
    invoke-direct/range {v1 .. v22}, LCj/f;-><init>(JJLjava/lang/String;ZLjava/lang/String;Ljava/lang/String;DIIIILjava/lang/String;JZLjava/util/List;Ljava/util/List;I)V

    return-void
.end method
