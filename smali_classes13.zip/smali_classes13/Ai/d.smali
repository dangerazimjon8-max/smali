.class public final LAi/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LY2/a;


# instance fields
.field public final a:Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final b:Lorg/xbet/uikit/components/toolbar/base/DsNavigationBarBasic;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final c:Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final d:Landroidx/appcompat/widget/AppCompatImageView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;Lorg/xbet/uikit/components/toolbar/base/DsNavigationBarBasic;Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;Landroidx/appcompat/widget/AppCompatImageView;)V
    .locals 0
    .param p1    # Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Lorg/xbet/uikit/components/toolbar/base/DsNavigationBarBasic;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p3    # Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p4    # Landroidx/appcompat/widget/AppCompatImageView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAi/d;->a:Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;

    .line 5
    .line 6
    iput-object p2, p0, LAi/d;->b:Lorg/xbet/uikit/components/toolbar/base/DsNavigationBarBasic;

    .line 7
    .line 8
    iput-object p3, p0, LAi/d;->c:Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;

    .line 9
    .line 10
    iput-object p4, p0, LAi/d;->d:Landroidx/appcompat/widget/AppCompatImageView;

    .line 11
    .line 12
    return-void
.end method

.method public static a(Landroid/view/View;)LAi/d;
    .locals 4
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 1
    sget v0, Lzi/a;->navigationBar:I

    .line 2
    .line 3
    invoke-static {p0, v0}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Lorg/xbet/uikit/components/toolbar/base/DsNavigationBarBasic;

    .line 8
    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    move-object v0, p0

    .line 12
    check-cast v0, Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;

    .line 13
    .line 14
    sget v2, Lzi/a;->qrScannerMask:I

    .line 15
    .line 16
    invoke-static {p0, v2}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    check-cast v3, Landroidx/appcompat/widget/AppCompatImageView;

    .line 21
    .line 22
    if-eqz v3, :cond_0

    .line 23
    .line 24
    new-instance p0, LAi/d;

    .line 25
    .line 26
    invoke-direct {p0, v0, v1, v0, v3}, LAi/d;-><init>(Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;Lorg/xbet/uikit/components/toolbar/base/DsNavigationBarBasic;Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;Landroidx/appcompat/widget/AppCompatImageView;)V

    .line 27
    .line 28
    .line 29
    return-object p0

    .line 30
    :cond_0
    move v0, v2

    .line 31
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    new-instance v0, Ljava/lang/NullPointerException;

    .line 40
    .line 41
    const-string v1, "Missing required view with ID: "

    .line 42
    .line 43
    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    invoke-direct {v0, p0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    throw v0
.end method


# virtual methods
.method public b()Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;
    .locals 1
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 1
    iget-object v0, p0, LAi/d;->a:Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;

    .line 2
    .line 3
    return-object v0
.end method

.method public bridge synthetic getRoot()Landroid/view/View;
    .locals 1
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 1
    invoke-virtual {p0}, LAi/d;->b()Lcom/journeyapps/barcodescanner/DecoratedBarcodeView;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
