.class public final LBp/a;
.super Ljava/lang/Object;


# static fields
.field public static bonus_agreements_fragment:I = 0x7f0d00a0


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
