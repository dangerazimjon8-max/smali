.class public final Lap/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LLo/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lap/a$a;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000r\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u001f\u0008\u0086\u0008\u0018\u00002\u00020\u0001:\u0001(BG\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\u0008\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u0006\u0010\r\u001a\u00020\u000c\u0012\u0006\u0010\u000f\u001a\u00020\u000e\u0012\u0006\u0010\u0011\u001a\u00020\u0010\u00a2\u0006\u0004\u0008\u0012\u0010\u0013J-\u0010\u001b\u001a\u00020\u001a2\u000c\u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\u00150\u00142\u0006\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0019\u001a\u00020\u0017H\u0016\u00a2\u0006\u0004\u0008\u001b\u0010\u001cJ\u0010\u0010\u001e\u001a\u00020\u001dH\u00d6\u0001\u00a2\u0006\u0004\u0008\u001e\u0010\u001fJ\u0010\u0010!\u001a\u00020 H\u00d6\u0001\u00a2\u0006\u0004\u0008!\u0010\"J\u001a\u0010&\u001a\u00020%2\u0008\u0010$\u001a\u0004\u0018\u00010#H\u00d6\u0003\u00a2\u0006\u0004\u0008&\u0010\'R\u001a\u0010\u0003\u001a\u00020\u00028\u0016X\u0096\u0004\u00a2\u0006\u000c\n\u0004\u0008(\u0010)\u001a\u0004\u0008*\u0010+R\u001a\u0010\u0005\u001a\u00020\u00048\u0016X\u0096\u0004\u00a2\u0006\u000c\n\u0004\u0008*\u0010,\u001a\u0004\u0008-\u0010.R\u001a\u0010\u0007\u001a\u00020\u00068\u0016X\u0096\u0004\u00a2\u0006\u000c\n\u0004\u0008/\u00100\u001a\u0004\u00081\u00102R\u0017\u0010\t\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u00083\u00104\u001a\u0004\u00085\u0010\u001fR\u0017\u0010\u000b\u001a\u00020\n8\u0006\u00a2\u0006\u000c\n\u0004\u00086\u00107\u001a\u0004\u00088\u00109R\u0017\u0010\r\u001a\u00020\u000c8\u0006\u00a2\u0006\u000c\n\u0004\u0008:\u0010;\u001a\u0004\u0008:\u0010<R\u0017\u0010\u000f\u001a\u00020\u000e8\u0006\u00a2\u0006\u000c\n\u0004\u00085\u0010=\u001a\u0004\u0008>\u0010?R\u0017\u0010\u0011\u001a\u00020\u00108\u0006\u00a2\u0006\u000c\n\u0004\u0008@\u0010A\u001a\u0004\u0008B\u0010C\u00a8\u0006D"
    }
    d2 = {
        "Lap/a;",
        "LLo/c;",
        "",
        "gameId",
        "LRo/a;",
        "header",
        "LPo/e;",
        "footer",
        "Lap/a$a$a;",
        "information",
        "Lap/a$a$d;",
        "score",
        "Lap/a$a$b;",
        "firstPlayer",
        "Lap/a$a$c;",
        "secondPlayer",
        "Lap/a$a$e;",
        "subtitle",
        "<init>",
        "(JLRo/a;LPo/e;Ljava/lang/String;Lap/a$a$d;Lap/a$a$b;Lap/a$a$c;Lap/a$a$e;Lkotlin/jvm/internal/DefaultConstructorMarker;)V",
        "",
        "LLo/a;",
        "payloads",
        "LxZ0/i;",
        "oldItem",
        "newItem",
        "",
        "j",
        "(Ljava/util/List;LxZ0/i;LxZ0/i;)V",
        "",
        "toString",
        "()Ljava/lang/String;",
        "",
        "hashCode",
        "()I",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "a",
        "J",
        "b",
        "()J",
        "LRo/a;",
        "getHeader",
        "()LRo/a;",
        "c",
        "LPo/e;",
        "x",
        "()LPo/e;",
        "d",
        "Ljava/lang/String;",
        "g",
        "e",
        "Lap/a$a$d;",
        "A",
        "()Lap/a$a$d;",
        "f",
        "Lap/a$a$b;",
        "()Lap/a$a$b;",
        "Lap/a$a$c;",
        "B",
        "()Lap/a$a$c;",
        "h",
        "Lap/a$a$e;",
        "E",
        "()Lap/a$a$e;",
        "event_card_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field public final a:J

.field public final b:LRo/a;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final c:LPo/e;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final d:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final e:Lap/a$a$d;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final f:Lap/a$a$b;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final g:Lap/a$a$c;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final h:Lap/a$a$e;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public constructor <init>(JLRo/a;LPo/e;Ljava/lang/String;Lap/a$a$d;Lap/a$a$b;Lap/a$a$c;Lap/a$a$e;)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-wide p1, p0, Lap/a;->a:J

    .line 4
    iput-object p3, p0, Lap/a;->b:LRo/a;

    .line 5
    iput-object p4, p0, Lap/a;->c:LPo/e;

    .line 6
    iput-object p5, p0, Lap/a;->d:Ljava/lang/String;

    .line 7
    iput-object p6, p0, Lap/a;->e:Lap/a$a$d;

    .line 8
    iput-object p7, p0, Lap/a;->f:Lap/a$a$b;

    .line 9
    iput-object p8, p0, Lap/a;->g:Lap/a$a$c;

    .line 10
    iput-object p9, p0, Lap/a;->h:Lap/a$a$e;

    return-void
.end method

.method public synthetic constructor <init>(JLRo/a;LPo/e;Ljava/lang/String;Lap/a$a$d;Lap/a$a$b;Lap/a$a$c;Lap/a$a$e;Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct/range {p0 .. p9}, Lap/a;-><init>(JLRo/a;LPo/e;Ljava/lang/String;Lap/a$a$d;Lap/a$a$b;Lap/a$a$c;Lap/a$a$e;)V

    return-void
.end method


# virtual methods
.method public final A()Lap/a$a$d;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lap/a;->e:Lap/a$a$d;

    .line 2
    .line 3
    return-object v0
.end method

.method public final B()Lap/a$a$c;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lap/a;->g:Lap/a$a$c;

    .line 2
    .line 3
    return-object v0
.end method

.method public final E()Lap/a$a$e;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lap/a;->h:Lap/a$a$e;

    .line 2
    .line 3
    return-object v0
.end method

.method public areContentsTheSame(LxZ0/i;LxZ0/i;)Z
    .locals 0
    .param p1    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-static {p0, p1, p2}, LLo/b;->a(LLo/c;LxZ0/i;LxZ0/i;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public areItemsTheSame(LxZ0/i;LxZ0/i;)Z
    .locals 0
    .param p1    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-static {p0, p1, p2}, LLo/b;->b(LLo/c;LxZ0/i;LxZ0/i;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public b()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lap/a;->a:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public e(LxZ0/i;LxZ0/i;)Ljava/util/List;
    .locals 0
    .param p1    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LxZ0/i;",
            "LxZ0/i;",
            ")",
            "Ljava/util/List<",
            "LxZ0/k;",
            ">;"
        }
    .end annotation

    .line 1
    invoke-static {p0, p1, p2}, LLo/b;->c(LLo/c;LxZ0/i;LxZ0/i;)Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lap/a;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lap/a;

    .line 12
    .line 13
    iget-wide v3, p0, Lap/a;->a:J

    .line 14
    .line 15
    iget-wide v5, p1, Lap/a;->a:J

    .line 16
    .line 17
    cmp-long v1, v3, v5

    .line 18
    .line 19
    if-eqz v1, :cond_2

    .line 20
    .line 21
    return v2

    .line 22
    :cond_2
    iget-object v1, p0, Lap/a;->b:LRo/a;

    .line 23
    .line 24
    iget-object v3, p1, Lap/a;->b:LRo/a;

    .line 25
    .line 26
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-nez v1, :cond_3

    .line 31
    .line 32
    return v2

    .line 33
    :cond_3
    iget-object v1, p0, Lap/a;->c:LPo/e;

    .line 34
    .line 35
    iget-object v3, p1, Lap/a;->c:LPo/e;

    .line 36
    .line 37
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-nez v1, :cond_4

    .line 42
    .line 43
    return v2

    .line 44
    :cond_4
    iget-object v1, p0, Lap/a;->d:Ljava/lang/String;

    .line 45
    .line 46
    iget-object v3, p1, Lap/a;->d:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {v1, v3}, Lap/a$a$a;->d(Ljava/lang/String;Ljava/lang/String;)Z

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    if-nez v1, :cond_5

    .line 53
    .line 54
    return v2

    .line 55
    :cond_5
    iget-object v1, p0, Lap/a;->e:Lap/a$a$d;

    .line 56
    .line 57
    iget-object v3, p1, Lap/a;->e:Lap/a$a$d;

    .line 58
    .line 59
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    if-nez v1, :cond_6

    .line 64
    .line 65
    return v2

    .line 66
    :cond_6
    iget-object v1, p0, Lap/a;->f:Lap/a$a$b;

    .line 67
    .line 68
    iget-object v3, p1, Lap/a;->f:Lap/a$a$b;

    .line 69
    .line 70
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    if-nez v1, :cond_7

    .line 75
    .line 76
    return v2

    .line 77
    :cond_7
    iget-object v1, p0, Lap/a;->g:Lap/a$a$c;

    .line 78
    .line 79
    iget-object v3, p1, Lap/a;->g:Lap/a$a$c;

    .line 80
    .line 81
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v1

    .line 85
    if-nez v1, :cond_8

    .line 86
    .line 87
    return v2

    .line 88
    :cond_8
    iget-object v1, p0, Lap/a;->h:Lap/a$a$e;

    .line 89
    .line 90
    iget-object p1, p1, Lap/a;->h:Lap/a$a$e;

    .line 91
    .line 92
    invoke-static {v1, p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result p1

    .line 96
    if-nez p1, :cond_9

    .line 97
    .line 98
    return v2

    .line 99
    :cond_9
    return v0
.end method

.method public final f()Lap/a$a$b;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lap/a;->f:Lap/a$a$b;

    .line 2
    .line 3
    return-object v0
.end method

.method public final g()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lap/a;->d:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public bridge synthetic getChangePayload(LxZ0/i;LxZ0/i;)Ljava/util/Collection;
    .locals 0

    .line 1
    invoke-virtual {p0, p1, p2}, Lap/a;->e(LxZ0/i;LxZ0/i;)Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public getHeader()LRo/a;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lap/a;->b:LRo/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public getKey()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    invoke-static {p0}, LxZ0/h;->d(LxZ0/i;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public hashCode()I
    .locals 2

    .line 1
    iget-wide v0, p0, Lap/a;->a:J

    .line 2
    .line 3
    invoke-static {v0, v1}, Lx/k;->a(J)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, Lap/a;->b:LRo/a;

    .line 10
    .line 11
    invoke-virtual {v1}, LRo/a;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v0, v1

    .line 16
    mul-int/lit8 v0, v0, 0x1f

    .line 17
    .line 18
    iget-object v1, p0, Lap/a;->c:LPo/e;

    .line 19
    .line 20
    invoke-virtual {v1}, LPo/e;->hashCode()I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    add-int/2addr v0, v1

    .line 25
    mul-int/lit8 v0, v0, 0x1f

    .line 26
    .line 27
    iget-object v1, p0, Lap/a;->d:Ljava/lang/String;

    .line 28
    .line 29
    invoke-static {v1}, Lap/a$a$a;->e(Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    add-int/2addr v0, v1

    .line 34
    mul-int/lit8 v0, v0, 0x1f

    .line 35
    .line 36
    iget-object v1, p0, Lap/a;->e:Lap/a$a$d;

    .line 37
    .line 38
    invoke-virtual {v1}, Lap/a$a$d;->hashCode()I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    add-int/2addr v0, v1

    .line 43
    mul-int/lit8 v0, v0, 0x1f

    .line 44
    .line 45
    iget-object v1, p0, Lap/a;->f:Lap/a$a$b;

    .line 46
    .line 47
    invoke-virtual {v1}, Lap/a$a$b;->hashCode()I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    add-int/2addr v0, v1

    .line 52
    mul-int/lit8 v0, v0, 0x1f

    .line 53
    .line 54
    iget-object v1, p0, Lap/a;->g:Lap/a$a$c;

    .line 55
    .line 56
    invoke-virtual {v1}, Lap/a$a$c;->hashCode()I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    add-int/2addr v0, v1

    .line 61
    mul-int/lit8 v0, v0, 0x1f

    .line 62
    .line 63
    iget-object v1, p0, Lap/a;->h:Lap/a$a$e;

    .line 64
    .line 65
    invoke-virtual {v1}, Lap/a$a$e;->hashCode()I

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    add-int/2addr v0, v1

    .line 70
    return v0
.end method

.method public j(Ljava/util/List;LxZ0/i;LxZ0/i;)V
    .locals 2
    .param p1    # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LLo/a;",
            ">;",
            "LxZ0/i;",
            "LxZ0/i;",
            ")V"
        }
    .end annotation

    .line 1
    instance-of v0, p2, Lap/a;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    instance-of v0, p3, Lap/a;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    check-cast p2, Lap/a;

    .line 10
    .line 11
    iget-object v0, p2, Lap/a;->d:Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {v0}, Lap/a$a$a;->a(Ljava/lang/String;)Lap/a$a$a;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast p3, Lap/a;

    .line 18
    .line 19
    iget-object v1, p3, Lap/a;->d:Ljava/lang/String;

    .line 20
    .line 21
    invoke-static {v1}, Lap/a$a$a;->a(Ljava/lang/String;)Lap/a$a$a;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    iget-object v0, p2, Lap/a;->e:Lap/a$a$d;

    .line 29
    .line 30
    iget-object v1, p3, Lap/a;->e:Lap/a$a$d;

    .line 31
    .line 32
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p2, Lap/a;->f:Lap/a$a$b;

    .line 36
    .line 37
    iget-object v1, p3, Lap/a;->f:Lap/a$a$b;

    .line 38
    .line 39
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    iget-object v0, p2, Lap/a;->g:Lap/a$a$c;

    .line 43
    .line 44
    iget-object v1, p3, Lap/a;->g:Lap/a$a$c;

    .line 45
    .line 46
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object p2, p2, Lap/a;->h:Lap/a$a$e;

    .line 50
    .line 51
    iget-object p3, p3, Lap/a;->h:Lap/a$a$e;

    .line 52
    .line 53
    invoke-static {p1, p2, p3}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    :cond_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 11
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-wide v0, p0, Lap/a;->a:J

    .line 2
    .line 3
    iget-object v2, p0, Lap/a;->b:LRo/a;

    .line 4
    .line 5
    iget-object v3, p0, Lap/a;->c:LPo/e;

    .line 6
    .line 7
    iget-object v4, p0, Lap/a;->d:Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {v4}, Lap/a$a$a;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v4

    .line 13
    iget-object v5, p0, Lap/a;->e:Lap/a$a$d;

    .line 14
    .line 15
    iget-object v6, p0, Lap/a;->f:Lap/a$a$b;

    .line 16
    .line 17
    iget-object v7, p0, Lap/a;->g:Lap/a$a$c;

    .line 18
    .line 19
    iget-object v8, p0, Lap/a;->h:Lap/a$a$e;

    .line 20
    .line 21
    new-instance v9, Ljava/lang/StringBuilder;

    .line 22
    .line 23
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 24
    .line 25
    .line 26
    const-string v10, "GameCardType13UiModel(gameId="

    .line 27
    .line 28
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    invoke-virtual {v9, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    const-string v0, ", header="

    .line 35
    .line 36
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    const-string v0, ", footer="

    .line 43
    .line 44
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    invoke-virtual {v9, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    const-string v0, ", information="

    .line 51
    .line 52
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    const-string v0, ", score="

    .line 59
    .line 60
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    const-string v0, ", firstPlayer="

    .line 67
    .line 68
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    const-string v0, ", secondPlayer="

    .line 75
    .line 76
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 77
    .line 78
    .line 79
    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    const-string v0, ", subtitle="

    .line 83
    .line 84
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    const-string v0, ")"

    .line 91
    .line 92
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    return-object v0
.end method

.method public x()LPo/e;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lap/a;->c:LPo/e;

    .line 2
    .line 3
    return-object v0
.end method
