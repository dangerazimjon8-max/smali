.class public final Lap/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lap/b$a;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\\\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0006\u001aw\u0010\u0014\u001a\u00020\u0013*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u000c\u0010\u0005\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u00032\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\u000c\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00062\u0006\u0010\u0012\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u0014\u0010\u0015\u001a\u001b\u0010\u0017\u001a\u00020\u0016*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\u0002\u00a2\u0006\u0004\u0008\u0017\u0010\u0018\u001a\u001b\u0010\u001a\u001a\u00020\u0019*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\u0002\u00a2\u0006\u0004\u0008\u001a\u0010\u001b\u001a\u001b\u0010\u001d\u001a\u00020\u001c*\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u000eH\u0002\u00a2\u0006\u0004\u0008\u001d\u0010\u001e\u001a\u001b\u0010 \u001a\u00020\n*\u00020\u001f2\u0006\u0010\u0002\u001a\u00020\u0001H\u0002\u00a2\u0006\u0004\u0008 \u0010!\u001a\u0013\u0010#\u001a\u00020\"*\u00020\u0000H\u0002\u00a2\u0006\u0004\u0008#\u0010$\u001a!\u0010&\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0003*\u00020\"2\u0006\u0010%\u001a\u00020\u0006H\u0002\u00a2\u0006\u0004\u0008&\u0010\'\u00a8\u0006("
    }
    d2 = {
        "LQn/k;",
        "LmZ0/f;",
        "resourceManager",
        "",
        "",
        "specialEventList",
        "",
        "bettingDisabled",
        "hasStream",
        "hasZone",
        "",
        "champImage",
        "betGroupMultiline",
        "betGroupBlocked",
        "LfP/b;",
        "gameUtilsProvider",
        "addAnyInfo",
        "customSportIcon",
        "topIcon",
        "Lap/a;",
        "b",
        "(LQn/k;LmZ0/f;Ljava/util/List;ZZZLjava/lang/String;ZZLfP/b;ZZZ)Lap/a;",
        "Lap/a$a$b;",
        "a",
        "(LQn/k;LmZ0/f;)Lap/a$a$b;",
        "Lap/a$a$c;",
        "e",
        "(LQn/k;LmZ0/f;)Lap/a$a$c;",
        "Lap/a$a$e;",
        "c",
        "(LQn/k;LfP/b;)Lap/a$a$e;",
        "Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;",
        "f",
        "(Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;LmZ0/f;)Ljava/lang/String;",
        "LQn/n;",
        "g",
        "(LQn/k;)LQn/n;",
        "first",
        "d",
        "(LQn/n;Z)Ljava/util/List;",
        "event_card_release"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final a(LQn/k;LmZ0/f;)Lap/a$a$b;
    .locals 10

    .line 1
    invoke-static {p0}, Lap/b;->g(LQn/k;)LQn/n;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-static {v0, v1}, Lap/b;->d(LQn/n;Z)Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    new-instance v2, Lap/a$a$b;

    .line 11
    .line 12
    invoke-virtual {p0}, LQn/k;->G()J

    .line 13
    .line 14
    .line 15
    move-result-wide v3

    .line 16
    invoke-static {p0}, LJn/c;->e(LQn/k;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v5

    .line 20
    invoke-static {p0}, Lap/b;->g(LQn/k;)LQn/n;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    invoke-virtual {p0}, LQn/n;->a()Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    invoke-static {p0, p1}, Lap/b;->f(Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;LmZ0/f;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v6

    .line 32
    const/4 p0, 0x0

    .line 33
    invoke-interface {v0, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    move-object v7, p0

    .line 38
    check-cast v7, Ljava/lang/String;

    .line 39
    .line 40
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    move-object v8, p0

    .line 45
    check-cast v8, Ljava/lang/String;

    .line 46
    .line 47
    const/4 p0, 0x2

    .line 48
    invoke-interface {v0, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    move-object v9, p0

    .line 53
    check-cast v9, Ljava/lang/String;

    .line 54
    .line 55
    invoke-direct/range {v2 .. v9}, Lap/a$a$b;-><init>(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    return-object v2
.end method

.method public static final b(LQn/k;LmZ0/f;Ljava/util/List;ZZZLjava/lang/String;ZZLfP/b;ZZZ)Lap/a;
    .locals 12
    .param p0    # LQn/k;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p1    # LmZ0/f;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p6    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p9    # LfP/b;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LQn/k;",
            "LmZ0/f;",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;ZZZ",
            "Ljava/lang/String;",
            "ZZ",
            "LfP/b;",
            "ZZZ)",
            "Lap/a;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    invoke-virtual {p0}, LQn/k;->q()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    const/4 v9, 0x0

    .line 6
    move-object v2, p0

    .line 7
    move-object v8, p2

    .line 8
    move v3, p3

    .line 9
    move/from16 v4, p4

    .line 10
    .line 11
    move/from16 v5, p5

    .line 12
    .line 13
    move-object/from16 v6, p6

    .line 14
    .line 15
    move/from16 v7, p10

    .line 16
    .line 17
    move/from16 v10, p11

    .line 18
    .line 19
    move/from16 v11, p12

    .line 20
    .line 21
    invoke-static/range {v2 .. v11}, LRo/c;->c(LQn/k;ZZZLjava/lang/String;ZLjava/util/List;LVY0/e;ZZ)LRo/a;

    .line 22
    .line 23
    .line 24
    move-result-object p2

    .line 25
    const/16 v9, 0x3c

    .line 26
    .line 27
    const/4 v10, 0x0

    .line 28
    const/4 v5, 0x0

    .line 29
    const/4 v6, 0x0

    .line 30
    const/4 v7, 0x0

    .line 31
    const/4 v8, 0x0

    .line 32
    move/from16 v3, p7

    .line 33
    .line 34
    move/from16 v4, p8

    .line 35
    .line 36
    invoke-static/range {v2 .. v10}, LPo/f;->c(LQn/k;ZZIZZZILjava/lang/Object;)LPo/e;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    invoke-static/range {p0 .. p1}, Lap/b;->a(LQn/k;LmZ0/f;)Lap/a$a$b;

    .line 41
    .line 42
    .line 43
    move-result-object v4

    .line 44
    invoke-static/range {p0 .. p1}, Lap/b;->e(LQn/k;LmZ0/f;)Lap/a$a$c;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    sget v6, LjY0/J;->number_of_round_dice:I

    .line 49
    .line 50
    invoke-virtual {p0}, LQn/k;->c()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v7

    .line 54
    const/4 v8, 0x1

    .line 55
    new-array v8, v8, [Ljava/lang/Object;

    .line 56
    .line 57
    const/4 v9, 0x0

    .line 58
    aput-object v7, v8, v9

    .line 59
    .line 60
    invoke-interface {p1, v6, v8}, LmZ0/f;->a(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    invoke-static {p1}, Lap/a$a$a;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    new-instance v6, Lap/a$a$d;

    .line 69
    .line 70
    invoke-static {p0}, LVo/a;->a(LQn/k;)Lorg/xbet/uikit_sport/score/a;

    .line 71
    .line 72
    .line 73
    move-result-object v7

    .line 74
    invoke-direct {v6, v7}, Lap/a$a$d;-><init>(Lorg/xbet/uikit_sport/score/a;)V

    .line 75
    .line 76
    .line 77
    move-object/from16 v7, p9

    .line 78
    .line 79
    invoke-static {p0, v7}, Lap/b;->c(LQn/k;LfP/b;)Lap/a$a$e;

    .line 80
    .line 81
    .line 82
    move-result-object p0

    .line 83
    new-instance v2, Lap/a;

    .line 84
    .line 85
    const/4 v7, 0x0

    .line 86
    move-object/from16 p9, p0

    .line 87
    .line 88
    move-object/from16 p5, p1

    .line 89
    .line 90
    move-object p3, p2

    .line 91
    move-wide p1, v0

    .line 92
    move-object p0, v2

    .line 93
    move-object/from16 p4, v3

    .line 94
    .line 95
    move-object/from16 p7, v4

    .line 96
    .line 97
    move-object/from16 p8, v5

    .line 98
    .line 99
    move-object/from16 p6, v6

    .line 100
    .line 101
    move-object/from16 p10, v7

    .line 102
    .line 103
    invoke-direct/range {p0 .. p10}, Lap/a;-><init>(JLRo/a;LPo/e;Ljava/lang/String;Lap/a$a$d;Lap/a$a$b;Lap/a$a$c;Lap/a$a$e;Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 104
    .line 105
    .line 106
    return-object p0
.end method

.method public static final c(LQn/k;LfP/b;)Lap/a$a$e;
    .locals 11

    .line 1
    invoke-static {p0}, LJn/c;->y(LQn/k;)Z

    .line 2
    .line 3
    .line 4
    move-result v4

    .line 5
    new-instance v0, Lap/a$a$e;

    .line 6
    .line 7
    invoke-static {p0}, LJn/c;->y(LQn/k;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x1

    .line 12
    xor-int/lit8 v7, v1, 0x1

    .line 13
    .line 14
    const/4 v9, 0x4

    .line 15
    const/4 v10, 0x0

    .line 16
    const/4 v8, 0x0

    .line 17
    move-object v6, p0

    .line 18
    move-object v5, p1

    .line 19
    invoke-static/range {v5 .. v10}, LfP/a;->a(LfP/b;LQn/k;ZZILjava/lang/Object;)Ljava/lang/CharSequence;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    invoke-virtual {v6}, LQn/k;->P()J

    .line 28
    .line 29
    .line 30
    move-result-wide p0

    .line 31
    if-eqz v4, :cond_0

    .line 32
    .line 33
    const/4 v5, 0x1

    .line 34
    :goto_0
    move-wide v2, p0

    .line 35
    goto :goto_1

    .line 36
    :cond_0
    const/4 v2, 0x2

    .line 37
    const/4 v5, 0x2

    .line 38
    goto :goto_0

    .line 39
    :goto_1
    invoke-direct/range {v0 .. v5}, Lap/a$a$e;-><init>(Ljava/lang/String;JZI)V

    .line 40
    .line 41
    .line 42
    return-object v0
.end method

.method public static final d(LQn/n;Z)Ljava/util/List;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LQn/n;",
            "Z)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    invoke-virtual {p0}, LQn/n;->b()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    :goto_0
    move-object v0, p0

    .line 8
    goto :goto_1

    .line 9
    :cond_0
    invoke-virtual {p0}, LQn/n;->d()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    goto :goto_0

    .line 14
    :goto_1
    const/4 v4, 0x4

    .line 15
    const/4 v5, 0x0

    .line 16
    const-string v1, "["

    .line 17
    .line 18
    const-string v2, ""

    .line 19
    .line 20
    const/4 v3, 0x0

    .line 21
    invoke-static/range {v0 .. v5}, Lkotlin/text/x;->U(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v6

    .line 25
    const/4 v10, 0x4

    .line 26
    const/4 v11, 0x0

    .line 27
    const-string v7, "]"

    .line 28
    .line 29
    const-string v8, ""

    .line 30
    .line 31
    const/4 v9, 0x0

    .line 32
    invoke-static/range {v6 .. v11}, Lkotlin/text/x;->U(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    const-string p0, ","

    .line 37
    .line 38
    filled-new-array {p0}, [Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    const/4 v4, 0x6

    .line 43
    const/4 v2, 0x0

    .line 44
    invoke-static/range {v0 .. v5}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    invoke-static {p0}, Lkotlin/collections/CollectionsKt;->D1(Ljava/util/Collection;)Ljava/util/List;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 53
    .line 54
    .line 55
    move-result p1

    .line 56
    const/4 v0, 0x3

    .line 57
    if-ge p1, v0, :cond_1

    .line 58
    .line 59
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    sub-int/2addr v0, p1

    .line 64
    const/4 p1, 0x0

    .line 65
    :goto_2
    if-ge p1, v0, :cond_1

    .line 66
    .line 67
    const-string v1, ""

    .line 68
    .line 69
    invoke-interface {p0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    add-int/lit8 p1, p1, 0x1

    .line 73
    .line 74
    goto :goto_2

    .line 75
    :cond_1
    return-object p0
.end method

.method public static final e(LQn/k;LmZ0/f;)Lap/a$a$c;
    .locals 10

    .line 1
    invoke-static {p0}, Lap/b;->g(LQn/k;)LQn/n;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-static {v0, v1}, Lap/b;->d(LQn/n;Z)Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    new-instance v2, Lap/a$a$c;

    .line 11
    .line 12
    invoke-virtual {p0}, LQn/k;->K()J

    .line 13
    .line 14
    .line 15
    move-result-wide v3

    .line 16
    invoke-static {p0}, LJn/c;->o(LQn/k;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v5

    .line 20
    invoke-static {p0}, Lap/b;->g(LQn/k;)LQn/n;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    invoke-virtual {p0}, LQn/n;->c()Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    invoke-static {p0, p1}, Lap/b;->f(Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;LmZ0/f;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v6

    .line 32
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    move-object v7, p0

    .line 37
    check-cast v7, Ljava/lang/String;

    .line 38
    .line 39
    const/4 p0, 0x1

    .line 40
    invoke-interface {v0, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    move-object v8, p0

    .line 45
    check-cast v8, Ljava/lang/String;

    .line 46
    .line 47
    const/4 p0, 0x2

    .line 48
    invoke-interface {v0, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    move-object v9, p0

    .line 53
    check-cast v9, Ljava/lang/String;

    .line 54
    .line 55
    invoke-direct/range {v2 .. v9}, Lap/a$a$c;-><init>(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    return-object v2
.end method

.method public static final f(Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;LmZ0/f;)Ljava/lang/String;
    .locals 2

    .line 1
    sget-object v0, Lap/b$a;->a:[I

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    aget p0, v0, p0

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    const/4 v1, 0x0

    .line 11
    if-eq p0, v0, :cond_4

    .line 12
    .line 13
    const/4 v0, 0x2

    .line 14
    if-eq p0, v0, :cond_3

    .line 15
    .line 16
    const/4 v0, 0x3

    .line 17
    if-eq p0, v0, :cond_2

    .line 18
    .line 19
    const/4 v0, 0x4

    .line 20
    if-eq p0, v0, :cond_1

    .line 21
    .line 22
    const/4 v0, 0x5

    .line 23
    if-ne p0, v0, :cond_0

    .line 24
    .line 25
    sget p0, LjY0/J;->empty_str:I

    .line 26
    .line 27
    new-array v0, v1, [Ljava/lang/Object;

    .line 28
    .line 29
    invoke-interface {p1, p0, v0}, LmZ0/f;->a(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    :cond_0
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 35
    .line 36
    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    .line 37
    .line 38
    .line 39
    throw p0

    .line 40
    :cond_1
    sget p0, LjY0/J;->mult_mult_victory_formula:I

    .line 41
    .line 42
    new-array v0, v1, [Ljava/lang/Object;

    .line 43
    .line 44
    invoke-interface {p1, p0, v0}, LmZ0/f;->a(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    return-object p0

    .line 49
    :cond_2
    sget p0, LjY0/J;->mult_sum_victory_formula:I

    .line 50
    .line 51
    new-array v0, v1, [Ljava/lang/Object;

    .line 52
    .line 53
    invoke-interface {p1, p0, v0}, LmZ0/f;->a(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    return-object p0

    .line 58
    :cond_3
    sget p0, LjY0/J;->sum_mult_victory_formula:I

    .line 59
    .line 60
    new-array v0, v1, [Ljava/lang/Object;

    .line 61
    .line 62
    invoke-interface {p1, p0, v0}, LmZ0/f;->a(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p0

    .line 66
    return-object p0

    .line 67
    :cond_4
    sget p0, LjY0/J;->sum_sum_victory_formula:I

    .line 68
    .line 69
    new-array v0, v1, [Ljava/lang/Object;

    .line 70
    .line 71
    invoke-interface {p1, p0, v0}, LmZ0/f;->a(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object p0

    .line 75
    return-object p0
.end method

.method public static final g(LQn/k;)LQn/n;
    .locals 8

    .line 1
    invoke-virtual {p0}, LQn/k;->x()LQn/i;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, LQn/i;->b()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    const/4 v2, 0x0

    .line 18
    if-eqz v1, :cond_1

    .line 19
    .line 20
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    move-object v3, v1

    .line 25
    check-cast v3, LQn/f;

    .line 26
    .line 27
    invoke-virtual {v3}, LQn/f;->a()Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    sget-object v4, Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;->FIRST_PLAYER_FORMULA:Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 32
    .line 33
    if-ne v3, v4, :cond_0

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    move-object v1, v2

    .line 37
    :goto_0
    check-cast v1, LQn/f;

    .line 38
    .line 39
    if-eqz v1, :cond_2

    .line 40
    .line 41
    invoke-virtual {v1}, LQn/f;->b()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    goto :goto_1

    .line 46
    :cond_2
    move-object v0, v2

    .line 47
    :goto_1
    const-string v1, ""

    .line 48
    .line 49
    if-nez v0, :cond_3

    .line 50
    .line 51
    move-object v0, v1

    .line 52
    :cond_3
    invoke-virtual {p0}, LQn/k;->x()LQn/i;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    invoke-virtual {v3}, LQn/i;->b()Ljava/util/List;

    .line 57
    .line 58
    .line 59
    move-result-object v3

    .line 60
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 61
    .line 62
    .line 63
    move-result-object v3

    .line 64
    :cond_4
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 65
    .line 66
    .line 67
    move-result v4

    .line 68
    if-eqz v4, :cond_5

    .line 69
    .line 70
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v4

    .line 74
    move-object v5, v4

    .line 75
    check-cast v5, LQn/f;

    .line 76
    .line 77
    invoke-virtual {v5}, LQn/f;->a()Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 78
    .line 79
    .line 80
    move-result-object v5

    .line 81
    sget-object v6, Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;->SECOND_PLAYER_FORMULA:Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 82
    .line 83
    if-ne v5, v6, :cond_4

    .line 84
    .line 85
    goto :goto_2

    .line 86
    :cond_5
    move-object v4, v2

    .line 87
    :goto_2
    check-cast v4, LQn/f;

    .line 88
    .line 89
    if-eqz v4, :cond_6

    .line 90
    .line 91
    invoke-virtual {v4}, LQn/f;->b()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    goto :goto_3

    .line 96
    :cond_6
    move-object v3, v2

    .line 97
    :goto_3
    if-nez v3, :cond_7

    .line 98
    .line 99
    move-object v3, v1

    .line 100
    :cond_7
    invoke-virtual {p0}, LQn/k;->x()LQn/i;

    .line 101
    .line 102
    .line 103
    move-result-object v4

    .line 104
    invoke-virtual {v4}, LQn/i;->b()Ljava/util/List;

    .line 105
    .line 106
    .line 107
    move-result-object v4

    .line 108
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    :cond_8
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 113
    .line 114
    .line 115
    move-result v5

    .line 116
    if-eqz v5, :cond_9

    .line 117
    .line 118
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v5

    .line 122
    move-object v6, v5

    .line 123
    check-cast v6, LQn/f;

    .line 124
    .line 125
    invoke-virtual {v6}, LQn/f;->a()Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 126
    .line 127
    .line 128
    move-result-object v6

    .line 129
    sget-object v7, Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;->FIRST_TEAM_CARDS:Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 130
    .line 131
    if-ne v6, v7, :cond_8

    .line 132
    .line 133
    goto :goto_4

    .line 134
    :cond_9
    move-object v5, v2

    .line 135
    :goto_4
    check-cast v5, LQn/f;

    .line 136
    .line 137
    if-eqz v5, :cond_a

    .line 138
    .line 139
    invoke-virtual {v5}, LQn/f;->b()Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object v4

    .line 143
    goto :goto_5

    .line 144
    :cond_a
    move-object v4, v2

    .line 145
    :goto_5
    if-nez v4, :cond_b

    .line 146
    .line 147
    move-object v4, v1

    .line 148
    :cond_b
    invoke-virtual {p0}, LQn/k;->x()LQn/i;

    .line 149
    .line 150
    .line 151
    move-result-object p0

    .line 152
    invoke-virtual {p0}, LQn/i;->b()Ljava/util/List;

    .line 153
    .line 154
    .line 155
    move-result-object p0

    .line 156
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 157
    .line 158
    .line 159
    move-result-object p0

    .line 160
    :cond_c
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 161
    .line 162
    .line 163
    move-result v5

    .line 164
    if-eqz v5, :cond_d

    .line 165
    .line 166
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    move-result-object v5

    .line 170
    move-object v6, v5

    .line 171
    check-cast v6, LQn/f;

    .line 172
    .line 173
    invoke-virtual {v6}, LQn/f;->a()Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 174
    .line 175
    .line 176
    move-result-object v6

    .line 177
    sget-object v7, Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;->SECOND_TEAM_CARDS:Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 178
    .line 179
    if-ne v6, v7, :cond_c

    .line 180
    .line 181
    goto :goto_6

    .line 182
    :cond_d
    move-object v5, v2

    .line 183
    :goto_6
    check-cast v5, LQn/f;

    .line 184
    .line 185
    if-eqz v5, :cond_e

    .line 186
    .line 187
    invoke-virtual {v5}, LQn/f;->b()Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v2

    .line 191
    :cond_e
    if-nez v2, :cond_f

    .line 192
    .line 193
    goto :goto_7

    .line 194
    :cond_f
    move-object v1, v2

    .line 195
    :goto_7
    new-instance p0, Lcom/google/gson/Gson;

    .line 196
    .line 197
    invoke-direct {p0}, Lcom/google/gson/Gson;-><init>()V

    .line 198
    .line 199
    .line 200
    new-instance v2, Lap/b$b;

    .line 201
    .line 202
    invoke-direct {v2}, Lap/b$b;-><init>()V

    .line 203
    .line 204
    .line 205
    invoke-virtual {v2}, Lcom/google/gson/reflect/TypeToken;->e()Ljava/lang/reflect/Type;

    .line 206
    .line 207
    .line 208
    move-result-object v2

    .line 209
    new-instance v5, LQn/n;

    .line 210
    .line 211
    invoke-virtual {p0, v0, v2}, Lcom/google/gson/Gson;->o(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    move-result-object v0

    .line 215
    check-cast v0, Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;

    .line 216
    .line 217
    if-nez v0, :cond_10

    .line 218
    .line 219
    sget-object v0, Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;->UNKNOWN:Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;

    .line 220
    .line 221
    :cond_10
    invoke-virtual {p0, v3, v2}, Lcom/google/gson/Gson;->o(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object p0

    .line 225
    check-cast p0, Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;

    .line 226
    .line 227
    if-nez p0, :cond_11

    .line 228
    .line 229
    sget-object p0, Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;->UNKNOWN:Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;

    .line 230
    .line 231
    :cond_11
    invoke-direct {v5, v0, p0, v4, v1}, LQn/n;-><init>(Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;Lorg/xbet/betting/core/zip/model/zip/game/VictoryFormulaResponseEnum;Ljava/lang/String;Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    return-object v5
.end method
