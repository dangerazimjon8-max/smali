.class public final LBs/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldagger/internal/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ldagger/internal/d<",
        "LPd1/j;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LNd1/a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ldagger/internal/h;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "LNd1/a;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LBs/k;->a:Ldagger/internal/h;

    .line 5
    .line 6
    return-void
.end method

.method public static a(Ldagger/internal/h;)LBs/k;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "LNd1/a;",
            ">;)",
            "LBs/k;"
        }
    .end annotation

    .line 1
    new-instance v0, LBs/k;

    .line 2
    .line 3
    invoke-direct {v0, p0}, LBs/k;-><init>(Ldagger/internal/h;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public static c(LNd1/a;)LPd1/j;
    .locals 1

    .line 1
    sget-object v0, LBs/a;->a:LBs/a$a;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, LBs/a$a;->j(LNd1/a;)LPd1/j;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-static {p0}, Ldagger/internal/g;->e(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    check-cast p0, LPd1/j;

    .line 12
    .line 13
    return-object p0
.end method


# virtual methods
.method public b()LPd1/j;
    .locals 1

    .line 1
    iget-object v0, p0, LBs/k;->a:Ldagger/internal/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LNd1/a;

    .line 8
    .line 9
    invoke-static {v0}, LBs/k;->c(LNd1/a;)LPd1/j;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, LBs/k;->b()LPd1/j;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
