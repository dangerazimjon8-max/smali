.class public final LBs/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldagger/internal/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ldagger/internal/d<",
        "LPd1/a;",
        ">;"
    }
.end annotation


# direct methods
.method public static a(LNd1/a;)LPd1/a;
    .locals 1

    .line 1
    sget-object v0, LBs/a;->a:LBs/a$a;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, LBs/a$a;->e(LNd1/a;)LPd1/a;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-static {p0}, Ldagger/internal/g;->e(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    check-cast p0, LPd1/a;

    .line 12
    .line 13
    return-object p0
.end method
