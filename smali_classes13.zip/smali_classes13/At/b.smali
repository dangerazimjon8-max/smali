.class public final LAt/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a\u0011\u0010\u0002\u001a\u00020\u0001*\u00020\u0000\u00a2\u0006\u0004\u0008\u0002\u0010\u0003\u00a8\u0006\u0004"
    }
    d2 = {
        "LCt/b;",
        "LIt/b;",
        "a",
        "(LCt/b;)LIt/b;",
        "impl_release"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final a(LCt/b;)LIt/b;
    .locals 11
    .param p0    # LCt/b;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    invoke-virtual {p0}, LCt/b;->a()Ljava/lang/Long;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x1

    .line 6
    const/4 v2, 0x0

    .line 7
    if-eqz v0, :cond_3

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 10
    .line 11
    .line 12
    move-result-wide v4

    .line 13
    invoke-virtual {p0}, LCt/b;->b()Ljava/lang/Long;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 20
    .line 21
    .line 22
    move-result-wide v6

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const-wide/16 v6, 0x0

    .line 25
    .line 26
    :goto_0
    invoke-virtual {p0}, LCt/b;->c()Ljava/lang/Double;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    if-eqz v0, :cond_2

    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    .line 33
    .line 34
    .line 35
    move-result-wide v8

    .line 36
    invoke-virtual {p0}, LCt/b;->d()Ljava/lang/Integer;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    if-eqz p0, :cond_1

    .line 41
    .line 42
    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    sget-object v0, Lorg/xbet/coinplay_sport_cashback_impl/domain/models/TypeTransactionEnum;->Companion:Lorg/xbet/coinplay_sport_cashback_impl/domain/models/TypeTransactionEnum$a;

    .line 47
    .line 48
    invoke-virtual {v0, p0}, Lorg/xbet/coinplay_sport_cashback_impl/domain/models/TypeTransactionEnum$a;->a(I)Lorg/xbet/coinplay_sport_cashback_impl/domain/models/TypeTransactionEnum;

    .line 49
    .line 50
    .line 51
    move-result-object v10

    .line 52
    if-eqz v10, :cond_1

    .line 53
    .line 54
    new-instance v3, LIt/b;

    .line 55
    .line 56
    invoke-direct/range {v3 .. v10}, LIt/b;-><init>(JJDLorg/xbet/coinplay_sport_cashback_impl/domain/models/TypeTransactionEnum;)V

    .line 57
    .line 58
    .line 59
    return-object v3

    .line 60
    :cond_1
    new-instance p0, Lcom/xbet/onexcore/BadDataResponseException;

    .line 61
    .line 62
    invoke-direct {p0, v2, v1, v2}, Lcom/xbet/onexcore/BadDataResponseException;-><init>(Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 63
    .line 64
    .line 65
    throw p0

    .line 66
    :cond_2
    new-instance p0, Lcom/xbet/onexcore/BadDataResponseException;

    .line 67
    .line 68
    invoke-direct {p0, v2, v1, v2}, Lcom/xbet/onexcore/BadDataResponseException;-><init>(Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 69
    .line 70
    .line 71
    throw p0

    .line 72
    :cond_3
    new-instance p0, Lcom/xbet/onexcore/BadDataResponseException;

    .line 73
    .line 74
    invoke-direct {p0, v2, v1, v2}, Lcom/xbet/onexcore/BadDataResponseException;-><init>(Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 75
    .line 76
    .line 77
    throw p0
.end method
