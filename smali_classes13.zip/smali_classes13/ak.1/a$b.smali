.class public final Lak/a$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lak/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lak/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lak/a$b$f;,
        Lak/a$b$d;,
        Lak/a$b$r;,
        Lak/a$b$j;,
        Lak/a$b$s;,
        Lak/a$b$c;,
        Lak/a$b$k;,
        Lak/a$b$a;,
        Lak/a$b$e;,
        Lak/a$b$o;,
        Lak/a$b$t;,
        Lak/a$b$n;,
        Lak/a$b$g;,
        Lak/a$b$i;,
        Lak/a$b$h;,
        Lak/a$b$b;,
        Lak/a$b$m;,
        Lak/a$b$l;,
        Lak/a$b$p;,
        Lak/a$b$q;
    }
.end annotation


# instance fields
.field public A:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/b;",
            ">;"
        }
    .end annotation
.end field

.field public B:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LAk/g;",
            ">;"
        }
    .end annotation
.end field

.field public C:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/makebet/domain/scenario/MakeBetScenario;",
            ">;"
        }
    .end annotation
.end field

.field public D:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/analytics/domain/TargetStatsUseCaseImpl;",
            ">;"
        }
    .end annotation
.end field

.field public E:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/games/data/d;",
            ">;"
        }
    .end annotation
.end field

.field public F:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/games/data/BetConstructorGamesRepositoryImpl;",
            ">;"
        }
    .end annotation
.end field

.field public G:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/games/domain/usecases/u;",
            ">;"
        }
    .end annotation
.end field

.field public H:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/bets/domain/usecases/g;",
            ">;"
        }
    .end annotation
.end field

.field public I:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LFf/c;",
            ">;"
        }
    .end annotation
.end field

.field public J:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/L;",
            ">;"
        }
    .end annotation
.end field

.field public K:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LGQ/a;",
            ">;"
        }
    .end annotation
.end field

.field public L:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/y;",
            ">;"
        }
    .end annotation
.end field

.field public M:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/internet/a;",
            ">;"
        }
    .end annotation
.end field

.field public N:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/MakeBetPromoViewModel;",
            ">;"
        }
    .end annotation
.end field

.field public O:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lqj/h;",
            ">;"
        }
    .end annotation
.end field

.field public P:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lcom/xbet/onexuser/domain/profile/ProfileInteractor;",
            ">;"
        }
    .end annotation
.end field

.field public Q:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LXY0/b;",
            ">;"
        }
    .end annotation
.end field

.field public R:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LWY0/c;",
            ">;"
        }
    .end annotation
.end field

.field public S:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/betting/core/tax/domain/usecase/g;",
            ">;"
        }
    .end annotation
.end field

.field public T:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LSs/j;",
            ">;"
        }
    .end annotation
.end field

.field public U:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lcom/xbet/onexuser/domain/usecases/GetProfileUseCase;",
            ">;"
        }
    .end annotation
.end field

.field public V:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/makebet/domain/scenario/GetTaxModelScenario;",
            ">;"
        }
    .end annotation
.end field

.field public W:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LYj/b;",
            ">;"
        }
    .end annotation
.end field

.field public X:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/makebet/data/repository/MakeBetRepositoryImpl;",
            ">;"
        }
    .end annotation
.end field

.field public Y:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lck/a;",
            ">;"
        }
    .end annotation
.end field

.field public Z:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/makebet/domain/scenario/UpdateInputLimitsScenario;",
            ">;"
        }
    .end annotation
.end field

.field public final a:LZY0/k;

.field public a0:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lsj/b;",
            ">;"
        }
    .end annotation
.end field

.field public final b:Ly11/a;

.field public b0:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/betting/core/make_bet/domain/usecases/n;",
            ">;"
        }
    .end annotation
.end field

.field public final c:Lmj/b;

.field public c0:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/betting/core/make_bet/domain/usecases/b;",
            ">;"
        }
    .end annotation
.end field

.field public final d:LaZ0/b;

.field public d0:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/i;",
            ">;"
        }
    .end annotation
.end field

.field public final e:Lak/a$b;

.field public e0:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/betting/core/tax/domain/usecase/e;",
            ">;"
        }
    .end annotation
.end field

.field public f:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lx7/f;",
            ">;"
        }
    .end annotation
.end field

.field public f0:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/betting/core/tax/domain/usecase/c;",
            ">;"
        }
    .end annotation
.end field

.field public g:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/bets/data/c;",
            ">;"
        }
    .end annotation
.end field

.field public g0:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/betting/core/tax/domain/usecase/i;",
            ">;"
        }
    .end annotation
.end field

.field public h:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LNj/a;",
            ">;"
        }
    .end annotation
.end field

.field public h0:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/u;",
            ">;"
        }
    .end annotation
.end field

.field public i:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lt7/h;",
            ">;"
        }
    .end annotation
.end field

.field public i0:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/betting/core/make_bet/domain/usecases/d;",
            ">;"
        }
    .end annotation
.end field

.field public j:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lcom/google/gson/Gson;",
            ">;"
        }
    .end annotation
.end field

.field public j0:Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;

.field public k:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LF7/a;",
            ">;"
        }
    .end annotation
.end field

.field public k0:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lak/f;",
            ">;"
        }
    .end annotation
.end field

.field public l:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lw8/b;",
            ">;"
        }
    .end annotation
.end field

.field public m:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/bets/data/BetConstructorBetsRepositoryImpl;",
            ">;"
        }
    .end annotation
.end field

.field public n:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lck/c;",
            ">;"
        }
    .end annotation
.end field

.field public o:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LmZ0/f;",
            ">;"
        }
    .end annotation
.end field

.field public p:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/MakeBetBottomSheetViewModel;",
            ">;"
        }
    .end annotation
.end field

.field public q:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lx80/b;",
            ">;"
        }
    .end annotation
.end field

.field public r:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LG8/a;",
            ">;"
        }
    .end annotation
.end field

.field public s:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LC7/i;",
            ">;"
        }
    .end annotation
.end field

.field public t:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lcom/xbet/onexuser/data/repositories/a;",
            ">;"
        }
    .end annotation
.end field

.field public u:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LA8/a;",
            ">;"
        }
    .end annotation
.end field

.field public v:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/feed/subscriptions/domain/usecases/A;",
            ">;"
        }
    .end annotation
.end field

.field public w:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/p;",
            ">;"
        }
    .end annotation
.end field

.field public x:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/E;",
            ">;"
        }
    .end annotation
.end field

.field public y:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/l;",
            ">;"
        }
    .end annotation
.end field

.field public z:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lqj/f;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LtY0/c;Lzn/f;LnZ/n;Lmj/a;Lpn/d;Lmj/b;Lyk/a;Lw80/a;LWY0/c;LmZ0/f;LGQ/a;LaZ0/b;Lx7/f;LNj/a;Lt7/h;LXY0/b;Lw8/b;LG8/a;Lcom/google/gson/Gson;Ly11/a;Lorg/xbet/betting/core/make_bet/domain/usecases/d;Lorg/xbet/ui_core/utils/L;Lorg/xbet/analytics/domain/TargetStatsUseCaseImpl;LFf/c;Lcom/xbet/onexuser/domain/profile/ProfileInteractor;Lorg/xbet/ui_core/utils/internet/a;LC7/i;Lorg/xbet/remoteconfig/domain/usecases/i;LVh0/d;LZY0/k;LTW/b;LSs/j;Lcom/xbet/onexuser/domain/usecases/GetProfileUseCase;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p0, p0, Lak/a$b;->e:Lak/a$b;

    .line 5
    .line 6
    move-object/from16 v0, p30

    .line 7
    .line 8
    iput-object v0, p0, Lak/a$b;->a:LZY0/k;

    .line 9
    .line 10
    move-object/from16 v1, p20

    .line 11
    .line 12
    iput-object v1, p0, Lak/a$b;->b:Ly11/a;

    .line 13
    .line 14
    iput-object p6, p0, Lak/a$b;->c:Lmj/b;

    .line 15
    .line 16
    iput-object p12, p0, Lak/a$b;->d:LaZ0/b;

    .line 17
    .line 18
    invoke-virtual/range {p0 .. p33}, Lak/a$b;->d(LtY0/c;Lzn/f;LnZ/n;Lmj/a;Lpn/d;Lmj/b;Lyk/a;Lw80/a;LWY0/c;LmZ0/f;LGQ/a;LaZ0/b;Lx7/f;LNj/a;Lt7/h;LXY0/b;Lw8/b;LG8/a;Lcom/google/gson/Gson;Ly11/a;Lorg/xbet/betting/core/make_bet/domain/usecases/d;Lorg/xbet/ui_core/utils/L;Lorg/xbet/analytics/domain/TargetStatsUseCaseImpl;LFf/c;Lcom/xbet/onexuser/domain/profile/ProfileInteractor;Lorg/xbet/ui_core/utils/internet/a;LC7/i;Lorg/xbet/remoteconfig/domain/usecases/i;LVh0/d;LZY0/k;LTW/b;LSs/j;Lcom/xbet/onexuser/domain/usecases/GetProfileUseCase;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual/range {p0 .. p33}, Lak/a$b;->e(LtY0/c;Lzn/f;LnZ/n;Lmj/a;Lpn/d;Lmj/b;Lyk/a;Lw80/a;LWY0/c;LmZ0/f;LGQ/a;LaZ0/b;Lx7/f;LNj/a;Lt7/h;LXY0/b;Lw8/b;LG8/a;Lcom/google/gson/Gson;Ly11/a;Lorg/xbet/betting/core/make_bet/domain/usecases/d;Lorg/xbet/ui_core/utils/L;Lorg/xbet/analytics/domain/TargetStatsUseCaseImpl;LFf/c;Lcom/xbet/onexuser/domain/profile/ProfileInteractor;Lorg/xbet/ui_core/utils/internet/a;LC7/i;Lorg/xbet/remoteconfig/domain/usecases/i;LVh0/d;LZY0/k;LTW/b;LSs/j;Lcom/xbet/onexuser/domain/usecases/GetProfileUseCase;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual/range {p0 .. p33}, Lak/a$b;->f(LtY0/c;Lzn/f;LnZ/n;Lmj/a;Lpn/d;Lmj/b;Lyk/a;Lw80/a;LWY0/c;LmZ0/f;LGQ/a;LaZ0/b;Lx7/f;LNj/a;Lt7/h;LXY0/b;Lw8/b;LG8/a;Lcom/google/gson/Gson;Ly11/a;Lorg/xbet/betting/core/make_bet/domain/usecases/d;Lorg/xbet/ui_core/utils/L;Lorg/xbet/analytics/domain/TargetStatsUseCaseImpl;LFf/c;Lcom/xbet/onexuser/domain/profile/ProfileInteractor;Lorg/xbet/ui_core/utils/internet/a;LC7/i;Lorg/xbet/remoteconfig/domain/usecases/i;LVh0/d;LZY0/k;LTW/b;LSs/j;Lcom/xbet/onexuser/domain/usecases/GetProfileUseCase;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public a(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lak/a$b;->i(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;)Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public b(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lak/a$b;->h(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;)Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public c(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lak/a$b;->g(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;)Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final d(LtY0/c;Lzn/f;LnZ/n;Lmj/a;Lpn/d;Lmj/b;Lyk/a;Lw80/a;LWY0/c;LmZ0/f;LGQ/a;LaZ0/b;Lx7/f;LNj/a;Lt7/h;LXY0/b;Lw8/b;LG8/a;Lcom/google/gson/Gson;Ly11/a;Lorg/xbet/betting/core/make_bet/domain/usecases/d;Lorg/xbet/ui_core/utils/L;Lorg/xbet/analytics/domain/TargetStatsUseCaseImpl;LFf/c;Lcom/xbet/onexuser/domain/profile/ProfileInteractor;Lorg/xbet/ui_core/utils/internet/a;LC7/i;Lorg/xbet/remoteconfig/domain/usecases/i;LVh0/d;LZY0/k;LTW/b;LSs/j;Lcom/xbet/onexuser/domain/usecases/GetProfileUseCase;)V
    .locals 7

    .line 1
    invoke-static/range {p13 .. p13}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    iput-object p2, p0, Lak/a$b;->f:Ldagger/internal/h;

    .line 6
    .line 7
    invoke-static {p2}, Lorg/xbet/bet_constructor/impl/bets/data/d;->a(Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/bets/data/d;

    .line 8
    .line 9
    .line 10
    move-result-object p2

    .line 11
    iput-object p2, p0, Lak/a$b;->g:Ldagger/internal/h;

    .line 12
    .line 13
    invoke-static/range {p14 .. p14}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    iput-object p2, p0, Lak/a$b;->h:Ldagger/internal/h;

    .line 18
    .line 19
    invoke-static/range {p15 .. p15}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    iput-object p2, p0, Lak/a$b;->i:Ldagger/internal/h;

    .line 24
    .line 25
    invoke-static/range {p19 .. p19}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 26
    .line 27
    .line 28
    move-result-object p2

    .line 29
    iput-object p2, p0, Lak/a$b;->j:Ldagger/internal/h;

    .line 30
    .line 31
    new-instance p2, Lak/a$b$f;

    .line 32
    .line 33
    invoke-direct {p2, p1}, Lak/a$b$f;-><init>(LtY0/c;)V

    .line 34
    .line 35
    .line 36
    iput-object p2, p0, Lak/a$b;->k:Ldagger/internal/h;

    .line 37
    .line 38
    invoke-static/range {p17 .. p17}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    iput-object p1, p0, Lak/a$b;->l:Ldagger/internal/h;

    .line 43
    .line 44
    iget-object p2, p0, Lak/a$b;->g:Ldagger/internal/h;

    .line 45
    .line 46
    iget-object v0, p0, Lak/a$b;->h:Ldagger/internal/h;

    .line 47
    .line 48
    iget-object v1, p0, Lak/a$b;->i:Ldagger/internal/h;

    .line 49
    .line 50
    iget-object v2, p0, Lak/a$b;->j:Ldagger/internal/h;

    .line 51
    .line 52
    iget-object v3, p0, Lak/a$b;->k:Ldagger/internal/h;

    .line 53
    .line 54
    move-object/from16 p16, p1

    .line 55
    .line 56
    move-object/from16 p11, p2

    .line 57
    .line 58
    move-object/from16 p12, v0

    .line 59
    .line 60
    move-object/from16 p13, v1

    .line 61
    .line 62
    move-object/from16 p14, v2

    .line 63
    .line 64
    move-object/from16 p15, v3

    .line 65
    .line 66
    invoke-static/range {p11 .. p16}, Lorg/xbet/bet_constructor/impl/bets/data/e;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/bets/data/e;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    iput-object p1, p0, Lak/a$b;->m:Ldagger/internal/h;

    .line 71
    .line 72
    invoke-static {p1}, Lck/d;->a(Ldagger/internal/h;)Lck/d;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    iput-object p1, p0, Lak/a$b;->n:Ldagger/internal/h;

    .line 77
    .line 78
    invoke-static/range {p10 .. p10}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    iput-object p1, p0, Lak/a$b;->o:Ldagger/internal/h;

    .line 83
    .line 84
    iget-object p2, p0, Lak/a$b;->n:Ldagger/internal/h;

    .line 85
    .line 86
    invoke-static {p2, p1}, Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/a;->a(Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/a;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    iput-object p1, p0, Lak/a$b;->p:Ldagger/internal/h;

    .line 91
    .line 92
    new-instance p1, Lak/a$b$d;

    .line 93
    .line 94
    invoke-direct {p1, p8}, Lak/a$b$d;-><init>(Lw80/a;)V

    .line 95
    .line 96
    .line 97
    iput-object p1, p0, Lak/a$b;->q:Ldagger/internal/h;

    .line 98
    .line 99
    invoke-static/range {p18 .. p18}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    iput-object p1, p0, Lak/a$b;->r:Ldagger/internal/h;

    .line 104
    .line 105
    invoke-static/range {p27 .. p27}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    iput-object p1, p0, Lak/a$b;->s:Ldagger/internal/h;

    .line 110
    .line 111
    invoke-static {p1}, Lcom/xbet/onexuser/data/repositories/b;->a(Ldagger/internal/h;)Lcom/xbet/onexuser/data/repositories/b;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    iput-object p1, p0, Lak/a$b;->t:Ldagger/internal/h;

    .line 116
    .line 117
    invoke-static {p1}, LA8/b;->a(Ldagger/internal/h;)LA8/b;

    .line 118
    .line 119
    .line 120
    move-result-object p1

    .line 121
    iput-object p1, p0, Lak/a$b;->u:Ldagger/internal/h;

    .line 122
    .line 123
    new-instance p1, Lak/a$b$r;

    .line 124
    .line 125
    invoke-direct {p1, p3}, Lak/a$b$r;-><init>(LnZ/n;)V

    .line 126
    .line 127
    .line 128
    iput-object p1, p0, Lak/a$b;->v:Ldagger/internal/h;

    .line 129
    .line 130
    new-instance p1, Lak/a$b$j;

    .line 131
    .line 132
    invoke-direct {p1, p4}, Lak/a$b$j;-><init>(Lmj/a;)V

    .line 133
    .line 134
    .line 135
    iput-object p1, p0, Lak/a$b;->w:Ldagger/internal/h;

    .line 136
    .line 137
    new-instance p1, Lak/a$b$s;

    .line 138
    .line 139
    invoke-direct {p1, p4}, Lak/a$b$s;-><init>(Lmj/a;)V

    .line 140
    .line 141
    .line 142
    iput-object p1, p0, Lak/a$b;->x:Ldagger/internal/h;

    .line 143
    .line 144
    new-instance p1, Lak/a$b$c;

    .line 145
    .line 146
    invoke-direct {p1, p4}, Lak/a$b$c;-><init>(Lmj/a;)V

    .line 147
    .line 148
    .line 149
    iput-object p1, p0, Lak/a$b;->y:Ldagger/internal/h;

    .line 150
    .line 151
    new-instance p1, Lak/a$b$k;

    .line 152
    .line 153
    invoke-direct {p1, p4}, Lak/a$b$k;-><init>(Lmj/a;)V

    .line 154
    .line 155
    .line 156
    iput-object p1, p0, Lak/a$b;->z:Ldagger/internal/h;

    .line 157
    .line 158
    new-instance p1, Lak/a$b$a;

    .line 159
    .line 160
    invoke-direct {p1, p4}, Lak/a$b$a;-><init>(Lmj/a;)V

    .line 161
    .line 162
    .line 163
    iput-object p1, p0, Lak/a$b;->A:Ldagger/internal/h;

    .line 164
    .line 165
    new-instance p1, Lak/a$b$e;

    .line 166
    .line 167
    invoke-direct {p1, p7}, Lak/a$b$e;-><init>(Lyk/a;)V

    .line 168
    .line 169
    .line 170
    iput-object p1, p0, Lak/a$b;->B:Ldagger/internal/h;

    .line 171
    .line 172
    iget-object p2, p0, Lak/a$b;->m:Ldagger/internal/h;

    .line 173
    .line 174
    iget-object p3, p0, Lak/a$b;->q:Ldagger/internal/h;

    .line 175
    .line 176
    iget-object p4, p0, Lak/a$b;->r:Ldagger/internal/h;

    .line 177
    .line 178
    iget-object v0, p0, Lak/a$b;->u:Ldagger/internal/h;

    .line 179
    .line 180
    iget-object v1, p0, Lak/a$b;->v:Ldagger/internal/h;

    .line 181
    .line 182
    iget-object v2, p0, Lak/a$b;->w:Ldagger/internal/h;

    .line 183
    .line 184
    iget-object v3, p0, Lak/a$b;->x:Ldagger/internal/h;

    .line 185
    .line 186
    iget-object v4, p0, Lak/a$b;->y:Ldagger/internal/h;

    .line 187
    .line 188
    iget-object v5, p0, Lak/a$b;->z:Ldagger/internal/h;

    .line 189
    .line 190
    iget-object v6, p0, Lak/a$b;->A:Ldagger/internal/h;

    .line 191
    .line 192
    move-object/from16 p12, p1

    .line 193
    .line 194
    move-object p5, v0

    .line 195
    move-object p6, v1

    .line 196
    move-object p7, v2

    .line 197
    move-object p8, v3

    .line 198
    move-object/from16 p9, v4

    .line 199
    .line 200
    move-object/from16 p10, v5

    .line 201
    .line 202
    move-object/from16 p11, v6

    .line 203
    .line 204
    invoke-static/range {p2 .. p12}, Lorg/xbet/bet_constructor/impl/makebet/domain/scenario/b;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/makebet/domain/scenario/b;

    .line 205
    .line 206
    .line 207
    move-result-object p1

    .line 208
    iput-object p1, p0, Lak/a$b;->C:Ldagger/internal/h;

    .line 209
    .line 210
    invoke-static/range {p23 .. p23}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 211
    .line 212
    .line 213
    move-result-object p1

    .line 214
    iput-object p1, p0, Lak/a$b;->D:Ldagger/internal/h;

    .line 215
    .line 216
    return-void
.end method

.method public final e(LtY0/c;Lzn/f;LnZ/n;Lmj/a;Lpn/d;Lmj/b;Lyk/a;Lw80/a;LWY0/c;LmZ0/f;LGQ/a;LaZ0/b;Lx7/f;LNj/a;Lt7/h;LXY0/b;Lw8/b;LG8/a;Lcom/google/gson/Gson;Ly11/a;Lorg/xbet/betting/core/make_bet/domain/usecases/d;Lorg/xbet/ui_core/utils/L;Lorg/xbet/analytics/domain/TargetStatsUseCaseImpl;LFf/c;Lcom/xbet/onexuser/domain/profile/ProfileInteractor;Lorg/xbet/ui_core/utils/internet/a;LC7/i;Lorg/xbet/remoteconfig/domain/usecases/i;LVh0/d;LZY0/k;LTW/b;LSs/j;Lcom/xbet/onexuser/domain/usecases/GetProfileUseCase;)V
    .locals 13

    .line 1
    move-object/from16 p1, p4

    .line 2
    .line 3
    move-object/from16 v0, p5

    .line 4
    .line 5
    iget-object v1, p0, Lak/a$b;->f:Ldagger/internal/h;

    .line 6
    .line 7
    invoke-static {v1}, Lorg/xbet/bet_constructor/impl/games/data/e;->a(Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/games/data/e;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    iput-object v1, p0, Lak/a$b;->E:Ldagger/internal/h;

    .line 12
    .line 13
    iget-object v2, p0, Lak/a$b;->h:Ldagger/internal/h;

    .line 14
    .line 15
    iget-object v3, p0, Lak/a$b;->k:Ldagger/internal/h;

    .line 16
    .line 17
    iget-object v4, p0, Lak/a$b;->i:Ldagger/internal/h;

    .line 18
    .line 19
    invoke-static {v1, v2, v3, v4}, Lorg/xbet/bet_constructor/impl/games/data/f;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/games/data/f;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    iput-object v1, p0, Lak/a$b;->F:Ldagger/internal/h;

    .line 24
    .line 25
    invoke-static {v1}, Lorg/xbet/bet_constructor/impl/games/domain/usecases/v;->a(Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/games/domain/usecases/v;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    iput-object v1, p0, Lak/a$b;->G:Ldagger/internal/h;

    .line 30
    .line 31
    invoke-static {v1}, Lorg/xbet/bet_constructor/impl/bets/domain/usecases/h;->a(Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/bets/domain/usecases/h;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    iput-object v1, p0, Lak/a$b;->H:Ldagger/internal/h;

    .line 36
    .line 37
    invoke-static/range {p24 .. p24}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    iput-object v1, p0, Lak/a$b;->I:Ldagger/internal/h;

    .line 42
    .line 43
    invoke-static/range {p22 .. p22}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    iput-object v1, p0, Lak/a$b;->J:Ldagger/internal/h;

    .line 48
    .line 49
    invoke-static/range {p11 .. p11}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    iput-object v1, p0, Lak/a$b;->K:Ldagger/internal/h;

    .line 54
    .line 55
    new-instance v1, Lak/a$b$o;

    .line 56
    .line 57
    invoke-direct {v1, p1}, Lak/a$b$o;-><init>(Lmj/a;)V

    .line 58
    .line 59
    .line 60
    iput-object v1, p0, Lak/a$b;->L:Ldagger/internal/h;

    .line 61
    .line 62
    invoke-static/range {p26 .. p26}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 63
    .line 64
    .line 65
    move-result-object v12

    .line 66
    iput-object v12, p0, Lak/a$b;->M:Ldagger/internal/h;

    .line 67
    .line 68
    iget-object v2, p0, Lak/a$b;->C:Ldagger/internal/h;

    .line 69
    .line 70
    iget-object v3, p0, Lak/a$b;->n:Ldagger/internal/h;

    .line 71
    .line 72
    iget-object v4, p0, Lak/a$b;->D:Ldagger/internal/h;

    .line 73
    .line 74
    iget-object v5, p0, Lak/a$b;->H:Ldagger/internal/h;

    .line 75
    .line 76
    iget-object v6, p0, Lak/a$b;->I:Ldagger/internal/h;

    .line 77
    .line 78
    iget-object v7, p0, Lak/a$b;->J:Ldagger/internal/h;

    .line 79
    .line 80
    iget-object v8, p0, Lak/a$b;->K:Ldagger/internal/h;

    .line 81
    .line 82
    iget-object v9, p0, Lak/a$b;->k:Ldagger/internal/h;

    .line 83
    .line 84
    iget-object v10, p0, Lak/a$b;->L:Ldagger/internal/h;

    .line 85
    .line 86
    iget-object v11, p0, Lak/a$b;->o:Ldagger/internal/h;

    .line 87
    .line 88
    invoke-static/range {v2 .. v12}, Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/g;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/g;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    iput-object v1, p0, Lak/a$b;->N:Ldagger/internal/h;

    .line 93
    .line 94
    new-instance v1, Lak/a$b$t;

    .line 95
    .line 96
    invoke-direct {v1, p1}, Lak/a$b$t;-><init>(Lmj/a;)V

    .line 97
    .line 98
    .line 99
    iput-object v1, p0, Lak/a$b;->O:Ldagger/internal/h;

    .line 100
    .line 101
    invoke-static/range {p25 .. p25}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    iput-object v1, p0, Lak/a$b;->P:Ldagger/internal/h;

    .line 106
    .line 107
    invoke-static/range {p16 .. p16}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    iput-object v1, p0, Lak/a$b;->Q:Ldagger/internal/h;

    .line 112
    .line 113
    invoke-static/range {p9 .. p9}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    iput-object v1, p0, Lak/a$b;->R:Ldagger/internal/h;

    .line 118
    .line 119
    new-instance v1, Lak/a$b$n;

    .line 120
    .line 121
    invoke-direct {v1, p2}, Lak/a$b$n;-><init>(Lzn/f;)V

    .line 122
    .line 123
    .line 124
    iput-object v1, p0, Lak/a$b;->S:Ldagger/internal/h;

    .line 125
    .line 126
    invoke-static/range {p32 .. p32}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    iput-object v1, p0, Lak/a$b;->T:Ldagger/internal/h;

    .line 131
    .line 132
    invoke-static/range {p33 .. p33}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    iput-object v1, p0, Lak/a$b;->U:Ldagger/internal/h;

    .line 137
    .line 138
    iget-object v2, p0, Lak/a$b;->S:Ldagger/internal/h;

    .line 139
    .line 140
    iget-object v3, p0, Lak/a$b;->z:Ldagger/internal/h;

    .line 141
    .line 142
    iget-object v4, p0, Lak/a$b;->A:Ldagger/internal/h;

    .line 143
    .line 144
    iget-object v5, p0, Lak/a$b;->T:Ldagger/internal/h;

    .line 145
    .line 146
    invoke-static {v2, v3, v4, v5, v1}, Lorg/xbet/bet_constructor/impl/makebet/domain/scenario/a;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/makebet/domain/scenario/a;

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    iput-object v1, p0, Lak/a$b;->V:Ldagger/internal/h;

    .line 151
    .line 152
    iget-object v1, p0, Lak/a$b;->f:Ldagger/internal/h;

    .line 153
    .line 154
    invoke-static {v1}, LYj/c;->a(Ldagger/internal/h;)LYj/c;

    .line 155
    .line 156
    .line 157
    move-result-object v1

    .line 158
    iput-object v1, p0, Lak/a$b;->W:Ldagger/internal/h;

    .line 159
    .line 160
    iget-object v2, p0, Lak/a$b;->i:Ldagger/internal/h;

    .line 161
    .line 162
    iget-object v3, p0, Lak/a$b;->l:Ldagger/internal/h;

    .line 163
    .line 164
    iget-object v4, p0, Lak/a$b;->k:Ldagger/internal/h;

    .line 165
    .line 166
    invoke-static {v1, v2, v3, v4}, Lorg/xbet/bet_constructor/impl/makebet/data/repository/a;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/makebet/data/repository/a;

    .line 167
    .line 168
    .line 169
    move-result-object v1

    .line 170
    iput-object v1, p0, Lak/a$b;->X:Ldagger/internal/h;

    .line 171
    .line 172
    iget-object v2, p0, Lak/a$b;->B:Ldagger/internal/h;

    .line 173
    .line 174
    invoke-static {v1, v2}, Lck/b;->a(Ldagger/internal/h;Ldagger/internal/h;)Lck/b;

    .line 175
    .line 176
    .line 177
    move-result-object v1

    .line 178
    iput-object v1, p0, Lak/a$b;->Y:Ldagger/internal/h;

    .line 179
    .line 180
    iget-object v2, p0, Lak/a$b;->r:Ldagger/internal/h;

    .line 181
    .line 182
    iget-object v3, p0, Lak/a$b;->q:Ldagger/internal/h;

    .line 183
    .line 184
    iget-object v4, p0, Lak/a$b;->H:Ldagger/internal/h;

    .line 185
    .line 186
    invoke-static {v1, v2, v3, v4}, Lorg/xbet/bet_constructor/impl/makebet/domain/scenario/c;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/makebet/domain/scenario/c;

    .line 187
    .line 188
    .line 189
    move-result-object v1

    .line 190
    iput-object v1, p0, Lak/a$b;->Z:Ldagger/internal/h;

    .line 191
    .line 192
    new-instance v1, Lak/a$b$g;

    .line 193
    .line 194
    invoke-direct {v1, p1}, Lak/a$b$g;-><init>(Lmj/a;)V

    .line 195
    .line 196
    .line 197
    iput-object v1, p0, Lak/a$b;->a0:Ldagger/internal/h;

    .line 198
    .line 199
    new-instance p1, Lak/a$b$i;

    .line 200
    .line 201
    invoke-direct {p1, v0}, Lak/a$b$i;-><init>(Lpn/d;)V

    .line 202
    .line 203
    .line 204
    iput-object p1, p0, Lak/a$b;->b0:Ldagger/internal/h;

    .line 205
    .line 206
    new-instance p1, Lak/a$b$h;

    .line 207
    .line 208
    invoke-direct {p1, v0}, Lak/a$b$h;-><init>(Lpn/d;)V

    .line 209
    .line 210
    .line 211
    iput-object p1, p0, Lak/a$b;->c0:Ldagger/internal/h;

    .line 212
    .line 213
    return-void
.end method

.method public final f(LtY0/c;Lzn/f;LnZ/n;Lmj/a;Lpn/d;Lmj/b;Lyk/a;Lw80/a;LWY0/c;LmZ0/f;LGQ/a;LaZ0/b;Lx7/f;LNj/a;Lt7/h;LXY0/b;Lw8/b;LG8/a;Lcom/google/gson/Gson;Ly11/a;Lorg/xbet/betting/core/make_bet/domain/usecases/d;Lorg/xbet/ui_core/utils/L;Lorg/xbet/analytics/domain/TargetStatsUseCaseImpl;LFf/c;Lcom/xbet/onexuser/domain/profile/ProfileInteractor;Lorg/xbet/ui_core/utils/internet/a;LC7/i;Lorg/xbet/remoteconfig/domain/usecases/i;LVh0/d;LZY0/k;LTW/b;LSs/j;Lcom/xbet/onexuser/domain/usecases/GetProfileUseCase;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p4

    .line 6
    .line 7
    new-instance v3, Lak/a$b$b;

    .line 8
    .line 9
    invoke-direct {v3, v2}, Lak/a$b$b;-><init>(Lmj/a;)V

    .line 10
    .line 11
    .line 12
    iput-object v3, v0, Lak/a$b;->d0:Ldagger/internal/h;

    .line 13
    .line 14
    new-instance v3, Lak/a$b$m;

    .line 15
    .line 16
    invoke-direct {v3, v1}, Lak/a$b$m;-><init>(Lzn/f;)V

    .line 17
    .line 18
    .line 19
    iput-object v3, v0, Lak/a$b;->e0:Ldagger/internal/h;

    .line 20
    .line 21
    new-instance v3, Lak/a$b$l;

    .line 22
    .line 23
    invoke-direct {v3, v1}, Lak/a$b$l;-><init>(Lzn/f;)V

    .line 24
    .line 25
    .line 26
    iput-object v3, v0, Lak/a$b;->f0:Ldagger/internal/h;

    .line 27
    .line 28
    new-instance v3, Lak/a$b$p;

    .line 29
    .line 30
    invoke-direct {v3, v1}, Lak/a$b$p;-><init>(Lzn/f;)V

    .line 31
    .line 32
    .line 33
    iput-object v3, v0, Lak/a$b;->g0:Ldagger/internal/h;

    .line 34
    .line 35
    new-instance v1, Lak/a$b$q;

    .line 36
    .line 37
    invoke-direct {v1, v2}, Lak/a$b$q;-><init>(Lmj/a;)V

    .line 38
    .line 39
    .line 40
    iput-object v1, v0, Lak/a$b;->h0:Ldagger/internal/h;

    .line 41
    .line 42
    invoke-static/range {p21 .. p21}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    iput-object v1, v0, Lak/a$b;->i0:Ldagger/internal/h;

    .line 47
    .line 48
    iget-object v2, v0, Lak/a$b;->z:Ldagger/internal/h;

    .line 49
    .line 50
    iget-object v3, v0, Lak/a$b;->O:Ldagger/internal/h;

    .line 51
    .line 52
    iget-object v4, v0, Lak/a$b;->L:Ldagger/internal/h;

    .line 53
    .line 54
    iget-object v5, v0, Lak/a$b;->P:Ldagger/internal/h;

    .line 55
    .line 56
    iget-object v6, v0, Lak/a$b;->o:Ldagger/internal/h;

    .line 57
    .line 58
    iget-object v7, v0, Lak/a$b;->Q:Ldagger/internal/h;

    .line 59
    .line 60
    iget-object v8, v0, Lak/a$b;->R:Ldagger/internal/h;

    .line 61
    .line 62
    iget-object v9, v0, Lak/a$b;->C:Ldagger/internal/h;

    .line 63
    .line 64
    iget-object v10, v0, Lak/a$b;->V:Ldagger/internal/h;

    .line 65
    .line 66
    iget-object v11, v0, Lak/a$b;->n:Ldagger/internal/h;

    .line 67
    .line 68
    iget-object v12, v0, Lak/a$b;->H:Ldagger/internal/h;

    .line 69
    .line 70
    iget-object v13, v0, Lak/a$b;->Z:Ldagger/internal/h;

    .line 71
    .line 72
    iget-object v14, v0, Lak/a$b;->a0:Ldagger/internal/h;

    .line 73
    .line 74
    iget-object v15, v0, Lak/a$b;->k:Ldagger/internal/h;

    .line 75
    .line 76
    move-object/from16 p27, v1

    .line 77
    .line 78
    iget-object v1, v0, Lak/a$b;->J:Ldagger/internal/h;

    .line 79
    .line 80
    move-object/from16 p15, v1

    .line 81
    .line 82
    iget-object v1, v0, Lak/a$b;->K:Ldagger/internal/h;

    .line 83
    .line 84
    move-object/from16 p16, v1

    .line 85
    .line 86
    iget-object v1, v0, Lak/a$b;->D:Ldagger/internal/h;

    .line 87
    .line 88
    move-object/from16 p17, v1

    .line 89
    .line 90
    iget-object v1, v0, Lak/a$b;->I:Ldagger/internal/h;

    .line 91
    .line 92
    move-object/from16 p18, v1

    .line 93
    .line 94
    iget-object v1, v0, Lak/a$b;->M:Ldagger/internal/h;

    .line 95
    .line 96
    move-object/from16 p19, v1

    .line 97
    .line 98
    iget-object v1, v0, Lak/a$b;->b0:Ldagger/internal/h;

    .line 99
    .line 100
    move-object/from16 p20, v1

    .line 101
    .line 102
    iget-object v1, v0, Lak/a$b;->c0:Ldagger/internal/h;

    .line 103
    .line 104
    move-object/from16 p21, v1

    .line 105
    .line 106
    iget-object v1, v0, Lak/a$b;->d0:Ldagger/internal/h;

    .line 107
    .line 108
    move-object/from16 p22, v1

    .line 109
    .line 110
    iget-object v1, v0, Lak/a$b;->e0:Ldagger/internal/h;

    .line 111
    .line 112
    move-object/from16 p23, v1

    .line 113
    .line 114
    iget-object v1, v0, Lak/a$b;->f0:Ldagger/internal/h;

    .line 115
    .line 116
    move-object/from16 p24, v1

    .line 117
    .line 118
    iget-object v1, v0, Lak/a$b;->g0:Ldagger/internal/h;

    .line 119
    .line 120
    move-object/from16 p25, v1

    .line 121
    .line 122
    iget-object v1, v0, Lak/a$b;->h0:Ldagger/internal/h;

    .line 123
    .line 124
    move-object/from16 p26, v1

    .line 125
    .line 126
    iget-object v1, v0, Lak/a$b;->u:Ldagger/internal/h;

    .line 127
    .line 128
    move-object/from16 p28, v1

    .line 129
    .line 130
    move-object/from16 p1, v2

    .line 131
    .line 132
    move-object/from16 p2, v3

    .line 133
    .line 134
    move-object/from16 p3, v4

    .line 135
    .line 136
    move-object/from16 p4, v5

    .line 137
    .line 138
    move-object/from16 p5, v6

    .line 139
    .line 140
    move-object/from16 p6, v7

    .line 141
    .line 142
    move-object/from16 p7, v8

    .line 143
    .line 144
    move-object/from16 p8, v9

    .line 145
    .line 146
    move-object/from16 p9, v10

    .line 147
    .line 148
    move-object/from16 p10, v11

    .line 149
    .line 150
    move-object/from16 p11, v12

    .line 151
    .line 152
    move-object/from16 p12, v13

    .line 153
    .line 154
    move-object/from16 p13, v14

    .line 155
    .line 156
    move-object/from16 p14, v15

    .line 157
    .line 158
    invoke-static/range {p1 .. p28}, Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;

    .line 159
    .line 160
    .line 161
    move-result-object v1

    .line 162
    iput-object v1, v0, Lak/a$b;->j0:Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;

    .line 163
    .line 164
    invoke-static {v1}, Lak/g;->c(Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;)Ldagger/internal/h;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    iput-object v1, v0, Lak/a$b;->k0:Ldagger/internal/h;

    .line 169
    .line 170
    return-void
.end method

.method public final g(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;)Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;
    .locals 1
    .annotation build Lcom/google/errorprone/annotations/CanIgnoreReturnValue;
    .end annotation

    .line 1
    invoke-virtual {p0}, Lak/a$b;->k()Lorg/xbet/ui_core/viewmodel/core/l;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/c;->b(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;Lorg/xbet/ui_core/viewmodel/core/l;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lak/a$b;->a:LZY0/k;

    .line 9
    .line 10
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/c;->a(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;LZY0/k;)V

    .line 11
    .line 12
    .line 13
    return-object p1
.end method

.method public final h(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;)Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;
    .locals 1
    .annotation build Lcom/google/errorprone/annotations/CanIgnoreReturnValue;
    .end annotation

    .line 1
    invoke-virtual {p0}, Lak/a$b;->k()Lorg/xbet/ui_core/viewmodel/core/l;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/g;->d(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;Lorg/xbet/ui_core/viewmodel/core/l;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lak/a$b;->b:Ly11/a;

    .line 9
    .line 10
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/g;->a(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;Ly11/a;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lak/a$b;->a:LZY0/k;

    .line 14
    .line 15
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/g;->b(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;LZY0/k;)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Lak/a$b;->d:LaZ0/b;

    .line 19
    .line 20
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/g;->c(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;LaZ0/b;)V

    .line 21
    .line 22
    .line 23
    return-object p1
.end method

.method public final i(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;)Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;
    .locals 1
    .annotation build Lcom/google/errorprone/annotations/CanIgnoreReturnValue;
    .end annotation

    .line 1
    iget-object v0, p0, Lak/a$b;->k0:Ldagger/internal/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lak/f;

    .line 8
    .line 9
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/r;->e(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;Lak/f;)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, Lak/a$b;->b:Ly11/a;

    .line 13
    .line 14
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/r;->a(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;Ly11/a;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lak/a$b;->c:Lmj/b;

    .line 18
    .line 19
    invoke-interface {v0}, Lmj/b;->a()Loj/b;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-static {v0}, Ldagger/internal/g;->d(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Loj/b;

    .line 28
    .line 29
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/r;->b(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;Loj/b;)V

    .line 30
    .line 31
    .line 32
    iget-object v0, p0, Lak/a$b;->a:LZY0/k;

    .line 33
    .line 34
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/r;->c(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;LZY0/k;)V

    .line 35
    .line 36
    .line 37
    iget-object v0, p0, Lak/a$b;->d:LaZ0/b;

    .line 38
    .line 39
    invoke-static {p1, v0}, Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/r;->d(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;LaZ0/b;)V

    .line 40
    .line 41
    .line 42
    return-object p1
.end method

.method public j()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "+",
            "Landroidx/lifecycle/f0;",
            ">;",
            "Lib/a<",
            "Landroidx/lifecycle/f0;",
            ">;>;"
        }
    .end annotation

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-static {v0}, Ldagger/internal/f;->b(I)Ldagger/internal/f;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    const-class v1, Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/MakeBetBottomSheetViewModel;

    .line 7
    .line 8
    iget-object v2, p0, Lak/a$b;->p:Ldagger/internal/h;

    .line 9
    .line 10
    invoke-virtual {v0, v1, v2}, Ldagger/internal/f;->c(Ljava/lang/Object;Ljava/lang/Object;)Ldagger/internal/f;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const-class v1, Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/MakeBetPromoViewModel;

    .line 15
    .line 16
    iget-object v2, p0, Lak/a$b;->N:Ldagger/internal/h;

    .line 17
    .line 18
    invoke-virtual {v0, v1, v2}, Ldagger/internal/f;->c(Ljava/lang/Object;Ljava/lang/Object;)Ldagger/internal/f;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v0}, Ldagger/internal/f;->a()Ljava/util/Map;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    return-object v0
.end method

.method public k()Lorg/xbet/ui_core/viewmodel/core/l;
    .locals 2

    .line 1
    new-instance v0, Lorg/xbet/ui_core/viewmodel/core/l;

    .line 2
    .line 3
    invoke-virtual {p0}, Lak/a$b;->j()Ljava/util/Map;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, Lorg/xbet/ui_core/viewmodel/core/l;-><init>(Ljava/util/Map;)V

    .line 8
    .line 9
    .line 10
    return-object v0
.end method
