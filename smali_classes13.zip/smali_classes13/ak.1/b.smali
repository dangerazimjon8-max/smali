.class public final synthetic Lak/b;
.super Ljava/lang/Object;
.source "SourceFile"
