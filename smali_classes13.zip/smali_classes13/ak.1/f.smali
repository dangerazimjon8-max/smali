.class public interface abstract Lak/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lorg/xbet/ui_core/viewmodel/core/e;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lorg/xbet/ui_core/viewmodel/core/e<",
        "Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/MakeBetSimpleViewModel;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0008a\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00020\u0001\u00a8\u0006\u0003\u00c0\u0006\u0003"
    }
    d2 = {
        "Lak/f;",
        "Lorg/xbet/ui_core/viewmodel/core/e;",
        "Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/MakeBetSimpleViewModel;",
        "impl_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation
