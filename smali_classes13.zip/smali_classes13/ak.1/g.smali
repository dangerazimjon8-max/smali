.class public final Lak/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lak/f;


# instance fields
.field public final a:Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;


# direct methods
.method public constructor <init>(Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lak/g;->a:Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;

    .line 5
    .line 6
    return-void
.end method

.method public static c(Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;)Ldagger/internal/h;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;",
            ")",
            "Ldagger/internal/h<",
            "Lak/f;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Lak/g;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lak/g;-><init>(Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;)V

    .line 4
    .line 5
    .line 6
    invoke-static {v0}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method


# virtual methods
.method public bridge synthetic a(Landroidx/lifecycle/T;)Landroidx/lifecycle/f0;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lak/g;->b(Landroidx/lifecycle/T;)Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/MakeBetSimpleViewModel;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public b(Landroidx/lifecycle/T;)Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/MakeBetSimpleViewModel;
    .locals 1

    .line 1
    iget-object v0, p0, Lak/g;->a:Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/z;->b(Landroidx/lifecycle/T;)Lorg/xbet/bet_constructor/impl/makebet/presentation/viewmodel/MakeBetSimpleViewModel;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method
