.class public interface abstract Lak/c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lak/c$a;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008a\u0018\u00002\u00020\u0001:\u0001\u0008J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H&\u00a2\u0006\u0004\u0008\u0005\u0010\u0006J\u0017\u0010\u0008\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0007H&\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\u0017\u0010\u000b\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\nH&\u00a2\u0006\u0004\u0008\u000b\u0010\u000c\u00a8\u0006\r\u00c0\u0006\u0003"
    }
    d2 = {
        "Lak/c;",
        "",
        "Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;",
        "fragment",
        "",
        "c",
        "(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;)V",
        "Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;",
        "a",
        "(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;)V",
        "Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;",
        "b",
        "(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;)V",
        "impl_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# virtual methods
.method public abstract a(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;)V
    .param p1    # Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorSimpleBetFragment;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
.end method

.method public abstract b(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;)V
    .param p1    # Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorPromoFragment;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
.end method

.method public abstract c(Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;)V
    .param p1    # Lorg/xbet/bet_constructor/impl/makebet/presentation/fragment/BetConstructorBottomSheet;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
.end method
