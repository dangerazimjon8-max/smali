.class public final LBj/c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a\u0013\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u0000\u00a2\u0006\u0004\u0008\u0002\u0010\u0003\u00a8\u0006\u0004"
    }
    d2 = {
        "LCj/g$a;",
        "LGj/b;",
        "a",
        "(LCj/g$a;)LGj/b;",
        "impl_release"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final a(LCj/g$a;)LGj/b;
    .locals 14
    .param p0    # LCj/g$a;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    new-instance v0, LGj/b;

    .line 2
    .line 3
    invoke-virtual {p0}, LCj/g$a;->c()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    const-string v2, ""

    .line 8
    .line 9
    if-nez v1, :cond_0

    .line 10
    .line 11
    move-object v1, v2

    .line 12
    :cond_0
    invoke-virtual {p0}, LCj/g$a;->b()LCj/d;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    if-eqz v3, :cond_1

    .line 17
    .line 18
    invoke-virtual {v3}, LCj/d;->d()Ljava/lang/Long;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    if-eqz v3, :cond_1

    .line 23
    .line 24
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 25
    .line 26
    .line 27
    move-result-wide v3

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    const-wide/16 v3, -0x1

    .line 30
    .line 31
    :goto_0
    invoke-virtual {p0}, LCj/g$a;->a()Ljava/lang/Double;

    .line 32
    .line 33
    .line 34
    move-result-object v5

    .line 35
    const-wide/16 v6, 0x0

    .line 36
    .line 37
    if-eqz v5, :cond_2

    .line 38
    .line 39
    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    .line 40
    .line 41
    .line 42
    move-result-wide v8

    .line 43
    goto :goto_1

    .line 44
    :cond_2
    move-wide v8, v6

    .line 45
    :goto_1
    invoke-virtual {p0}, LCj/g$a;->b()LCj/d;

    .line 46
    .line 47
    .line 48
    move-result-object v5

    .line 49
    if-eqz v5, :cond_3

    .line 50
    .line 51
    invoke-virtual {v5}, LCj/d;->b()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    goto :goto_2

    .line 56
    :cond_3
    const/4 v5, 0x0

    .line 57
    :goto_2
    if-nez v5, :cond_4

    .line 58
    .line 59
    goto :goto_3

    .line 60
    :cond_4
    move-object v2, v5

    .line 61
    :goto_3
    invoke-virtual {p0}, LCj/g$a;->b()LCj/d;

    .line 62
    .line 63
    .line 64
    move-result-object v5

    .line 65
    if-eqz v5, :cond_5

    .line 66
    .line 67
    invoke-virtual {v5}, LCj/d;->a()Ljava/lang/Double;

    .line 68
    .line 69
    .line 70
    move-result-object v5

    .line 71
    if-eqz v5, :cond_5

    .line 72
    .line 73
    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    .line 74
    .line 75
    .line 76
    move-result-wide v10

    .line 77
    goto :goto_4

    .line 78
    :cond_5
    move-wide v10, v6

    .line 79
    :goto_4
    invoke-virtual {p0}, LCj/g$a;->b()LCj/d;

    .line 80
    .line 81
    .line 82
    move-result-object p0

    .line 83
    if-eqz p0, :cond_6

    .line 84
    .line 85
    invoke-virtual {p0}, LCj/d;->c()Ljava/lang/Double;

    .line 86
    .line 87
    .line 88
    move-result-object p0

    .line 89
    if-eqz p0, :cond_6

    .line 90
    .line 91
    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    .line 92
    .line 93
    .line 94
    move-result-wide v6

    .line 95
    :cond_6
    move-wide v12, v6

    .line 96
    move-object v6, v2

    .line 97
    move-wide v2, v3

    .line 98
    move-wide v4, v8

    .line 99
    move-wide v7, v10

    .line 100
    move-wide v9, v12

    .line 101
    invoke-direct/range {v0 .. v10}, LGj/b;-><init>(Ljava/lang/String;JDLjava/lang/String;DD)V

    .line 102
    .line 103
    .line 104
    return-object v0
.end method
