.class public final LBj/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a\u001b\u0010\u0004\u001a\u00020\u0003*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\u0000\u00a2\u0006\u0004\u0008\u0004\u0010\u0005\u00a8\u0006\u0006"
    }
    d2 = {
        "LCj/b;",
        "",
        "shortGroupNumber",
        "Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;",
        "a",
        "(LCj/b;J)Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;",
        "impl_release"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final a(LCj/b;J)Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;
    .locals 14
    .param p0    # LCj/b;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    new-instance v0, Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;

    .line 2
    .line 3
    invoke-virtual {p0}, LCj/b;->a()Ljava/lang/Double;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    const-wide/16 v2, 0x0

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    .line 12
    .line 13
    .line 14
    move-result-wide v4

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    move-wide v4, v2

    .line 17
    :goto_0
    invoke-virtual {p0}, LCj/b;->b()Ljava/lang/Double;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    .line 24
    .line 25
    .line 26
    move-result-wide v2

    .line 27
    :cond_1
    invoke-virtual {p0}, LCj/b;->c()Ljava/lang/Boolean;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 32
    .line 33
    invoke-static {v1, v6}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v7

    .line 37
    invoke-virtual {p0}, LCj/b;->d()Ljava/lang/Long;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    if-eqz v1, :cond_2

    .line 42
    .line 43
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 44
    .line 45
    .line 46
    move-result-wide v8

    .line 47
    goto :goto_1

    .line 48
    :cond_2
    const-wide/16 v8, 0x0

    .line 49
    .line 50
    :goto_1
    invoke-virtual {p0}, LCj/b;->e()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    if-nez v1, :cond_4

    .line 55
    .line 56
    invoke-virtual {p0}, LCj/b;->a()Ljava/lang/Double;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    if-eqz p0, :cond_3

    .line 61
    .line 62
    invoke-virtual {p0}, Ljava/lang/Double;->toString()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p0

    .line 66
    :goto_2
    move-object v1, p0

    .line 67
    goto :goto_3

    .line 68
    :cond_3
    const/4 p0, 0x0

    .line 69
    goto :goto_2

    .line 70
    :goto_3
    if-nez v1, :cond_4

    .line 71
    .line 72
    const-string v1, ""

    .line 73
    .line 74
    :cond_4
    move-object v10, v1

    .line 75
    const-string v11, ""

    .line 76
    .line 77
    move-wide v12, v4

    .line 78
    move-wide v5, v2

    .line 79
    move-wide v1, v12

    .line 80
    move-wide v3, p1

    .line 81
    invoke-direct/range {v0 .. v11}, Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;-><init>(DJDZJLjava/lang/String;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    return-object v0
.end method
