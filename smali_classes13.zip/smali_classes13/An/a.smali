.class public interface abstract LAn/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0006\n\u0002\u0008\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u000f\u0008f\u0018\u00002\u00020\u0001J@\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0004\u001a\u00020\u00022\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0008\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u0007H\u00a6@\u00a2\u0006\u0004\u0008\r\u0010\u000eJ \u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0008\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u0007H\u00a6@\u00a2\u0006\u0004\u0008\u0010\u0010\u0011J\u0015\u0010\u0014\u001a\u0008\u0012\u0004\u0012\u00020\u00130\u0012H&\u00a2\u0006\u0004\u0008\u0014\u0010\u0015J\u000f\u0010\u0017\u001a\u00020\u0016H&\u00a2\u0006\u0004\u0008\u0017\u0010\u0018J\u000f\u0010\u0019\u001a\u00020\u0013H&\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0017\u0010\u001c\u001a\u00020\u00162\u0006\u0010\u001b\u001a\u00020\u0013H&\u00a2\u0006\u0004\u0008\u001c\u0010\u001dJ\u000f\u0010\u001e\u001a\u00020\u000fH&\u00a2\u0006\u0004\u0008\u001e\u0010\u001fJ\u0017\u0010!\u001a\u00020\u00162\u0006\u0010 \u001a\u00020\u000fH&\u00a2\u0006\u0004\u0008!\u0010\"J\u000f\u0010#\u001a\u00020\u0013H&\u00a2\u0006\u0004\u0008#\u0010\u001aJ\u000f\u0010$\u001a\u00020\u0016H&\u00a2\u0006\u0004\u0008$\u0010\u0018\u00a8\u0006%\u00c0\u0006\u0003"
    }
    d2 = {
        "LAn/a;",
        "",
        "",
        "sum",
        "coef",
        "",
        "currencyId",
        "",
        "countryId",
        "Lorg/xbet/betting/core/tax/domain/models/TaxMode;",
        "taxMode",
        "docType",
        "Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;",
        "j",
        "(DDJILorg/xbet/betting/core/tax/domain/models/TaxMode;ILkotlin/coroutines/e;)Ljava/lang/Object;",
        "LCn/b;",
        "a",
        "(IILkotlin/coroutines/e;)Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/e;",
        "",
        "d",
        "()Lkotlinx/coroutines/flow/e;",
        "",
        "i",
        "()V",
        "g",
        "()Z",
        "isAllowedRequestTax",
        "f",
        "(Z)V",
        "h",
        "()LCn/b;",
        "taxStatusModel",
        "b",
        "(LCn/b;)V",
        "e",
        "c",
        "core_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# virtual methods
.method public abstract a(IILkotlin/coroutines/e;)Ljava/lang/Object;
    .param p3    # Lkotlin/coroutines/e;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Lkotlin/coroutines/e<",
            "-",
            "LCn/b;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method

.method public abstract b(LCn/b;)V
    .param p1    # LCn/b;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
.end method

.method public abstract c()V
.end method

.method public abstract d()Lkotlinx/coroutines/flow/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/e<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end method

.method public abstract e()Z
.end method

.method public abstract f(Z)V
.end method

.method public abstract g()Z
.end method

.method public abstract h()LCn/b;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end method

.method public abstract i()V
.end method

.method public abstract j(DDJILorg/xbet/betting/core/tax/domain/models/TaxMode;ILkotlin/coroutines/e;)Ljava/lang/Object;
    .param p8    # Lorg/xbet/betting/core/tax/domain/models/TaxMode;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p10    # Lkotlin/coroutines/e;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(DDJI",
            "Lorg/xbet/betting/core/tax/domain/models/TaxMode;",
            "I",
            "Lkotlin/coroutines/e<",
            "-",
            "Lorg/xbet/betting/core/tax/domain/models/GetTaxModel;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method
