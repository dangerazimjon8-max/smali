.class public final synthetic Lat/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:Lat/e;


# direct methods
.method public synthetic constructor <init>(Lat/e;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lat/d;->a:Lat/e;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lat/d;->a:Lat/e;

    invoke-static {v0}, Lat/e;->u(Lat/e;)LV4/b;

    move-result-object v0

    return-object v0
.end method
