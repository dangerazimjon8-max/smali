.class public final synthetic LAm/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:Lkotlin/jvm/functions/Function1;

.field public final synthetic b:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LAm/c;->a:Lkotlin/jvm/functions/Function1;

    iput-object p2, p0, LAm/c;->b:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LAm/c;->a:Lkotlin/jvm/functions/Function1;

    iget-object v1, p0, LAm/c;->b:Lkotlin/jvm/functions/Function1;

    check-cast p1, LQ4/a;

    invoke-static {v0, v1, p1}, Lorg/xbet/bethistory_champ/history_info/presentation/adapter/BetInfoAdapterDelegateKt;->b(Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;LQ4/a;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
