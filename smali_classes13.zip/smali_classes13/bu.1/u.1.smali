.class public final synthetic Lbu/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:LZt/d;


# direct methods
.method public synthetic constructor <init>(LZt/d;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbu/u;->a:LZt/d;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 1
    iget-object v0, p0, Lbu/u;->a:LZt/d;

    invoke-static {v0}, Lorg/xbet/consultantchat/presentation/consultantchat/adapters/delegates/FileSendMessageDelegateKt;->c(LZt/d;)V

    return-void
.end method
