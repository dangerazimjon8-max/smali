.class public final synthetic Lbu/I;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:LQ4/a;

.field public final synthetic b:LRa/e;

.field public final synthetic c:Lau/b;


# direct methods
.method public synthetic constructor <init>(LQ4/a;LRa/e;Lau/b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbu/I;->a:LQ4/a;

    iput-object p2, p0, Lbu/I;->b:LRa/e;

    iput-object p3, p0, Lbu/I;->c:Lau/b;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Lbu/I;->a:LQ4/a;

    iget-object v1, p0, Lbu/I;->b:LRa/e;

    iget-object v2, p0, Lbu/I;->c:Lau/b;

    check-cast p1, Ljava/util/List;

    invoke-static {v0, v1, v2, p1}, Lorg/xbet/consultantchat/presentation/consultantchat/adapters/delegates/ImagesReceiveMessageDelegateKt;->b(LQ4/a;LRa/e;Lau/b;Ljava/util/List;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
