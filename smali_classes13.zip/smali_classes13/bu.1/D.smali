.class public final synthetic Lbu/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:LQ4/a;

.field public final synthetic b:LRa/e;

.field public final synthetic c:Lkotlin/jvm/functions/Function1;

.field public final synthetic d:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(LQ4/a;LRa/e;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbu/D;->a:LQ4/a;

    iput-object p2, p0, Lbu/D;->b:LRa/e;

    iput-object p3, p0, Lbu/D;->c:Lkotlin/jvm/functions/Function1;

    iput-object p4, p0, Lbu/D;->d:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, Lbu/D;->a:LQ4/a;

    iget-object v1, p0, Lbu/D;->b:LRa/e;

    iget-object v2, p0, Lbu/D;->c:Lkotlin/jvm/functions/Function1;

    iget-object v3, p0, Lbu/D;->d:Lkotlin/jvm/functions/Function1;

    check-cast p1, Ljava/util/List;

    invoke-static {v0, v1, v2, v3, p1}, Lorg/xbet/consultantchat/presentation/consultantchat/adapters/delegates/ImageSendMessageDelegateKt;->b(LQ4/a;LRa/e;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Ljava/util/List;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
