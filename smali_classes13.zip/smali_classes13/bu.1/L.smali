.class public final synthetic Lbu/L;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:LQ4/a;

.field public final synthetic b:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(LQ4/a;Lkotlin/jvm/functions/Function1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbu/L;->a:LQ4/a;

    iput-object p2, p0, Lbu/L;->b:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lbu/L;->a:LQ4/a;

    iget-object v1, p0, Lbu/L;->b:Lkotlin/jvm/functions/Function1;

    invoke-static {v0, v1, p1}, Lorg/xbet/consultantchat/presentation/consultantchat/adapters/delegates/ImagesSendMessageDelegateKt;->d(LQ4/a;Lkotlin/jvm/functions/Function1;Landroid/view/View;)V

    return-void
.end method
