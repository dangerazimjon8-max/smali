.class public final synthetic Lbu/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:LQ4/a;

.field public final synthetic b:LRa/e;


# direct methods
.method public synthetic constructor <init>(LQ4/a;LRa/e;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbu/n;->a:LQ4/a;

    iput-object p2, p0, Lbu/n;->b:LRa/e;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lbu/n;->a:LQ4/a;

    iget-object v1, p0, Lbu/n;->b:LRa/e;

    check-cast p1, Ljava/util/List;

    invoke-static {v0, v1, p1}, Lorg/xbet/consultantchat/presentation/consultantchat/adapters/delegates/FileReceiveMessageDelegateKt;->b(LQ4/a;LRa/e;Ljava/util/List;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
