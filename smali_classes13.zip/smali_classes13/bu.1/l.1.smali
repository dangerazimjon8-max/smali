.class public final synthetic Lbu/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lkotlin/jvm/functions/Function1;

.field public final synthetic b:LQ4/a;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;LQ4/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbu/l;->a:Lkotlin/jvm/functions/Function1;

    iput-object p2, p0, Lbu/l;->b:LQ4/a;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lbu/l;->a:Lkotlin/jvm/functions/Function1;

    iget-object v1, p0, Lbu/l;->b:LQ4/a;

    invoke-static {v0, v1, p1}, Lorg/xbet/consultantchat/presentation/consultantchat/adapters/delegates/FileReceiveMessageDelegateKt;->f(Lkotlin/jvm/functions/Function1;LQ4/a;Landroid/view/View;)V

    return-void
.end method
