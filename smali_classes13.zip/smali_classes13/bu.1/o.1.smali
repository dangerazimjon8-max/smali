.class public final synthetic Lbu/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:LZt/c;


# direct methods
.method public synthetic constructor <init>(LZt/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbu/o;->a:LZt/c;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 1
    iget-object v0, p0, Lbu/o;->a:LZt/c;

    invoke-static {v0}, Lorg/xbet/consultantchat/presentation/consultantchat/adapters/delegates/FileReceiveMessageDelegateKt;->e(LZt/c;)V

    return-void
.end method
