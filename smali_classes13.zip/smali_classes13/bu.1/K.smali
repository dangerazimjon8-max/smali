.class public final synthetic Lbu/K;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:Lkotlin/jvm/functions/Function1;

.field public final synthetic b:Lkotlin/jvm/functions/Function1;

.field public final synthetic c:Landroidx/recyclerview/widget/RecyclerView$t;

.field public final synthetic d:Lkotlin/jvm/functions/Function1;

.field public final synthetic e:LRa/e;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Landroidx/recyclerview/widget/RecyclerView$t;Lkotlin/jvm/functions/Function1;LRa/e;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbu/K;->a:Lkotlin/jvm/functions/Function1;

    iput-object p2, p0, Lbu/K;->b:Lkotlin/jvm/functions/Function1;

    iput-object p3, p0, Lbu/K;->c:Landroidx/recyclerview/widget/RecyclerView$t;

    iput-object p4, p0, Lbu/K;->d:Lkotlin/jvm/functions/Function1;

    iput-object p5, p0, Lbu/K;->e:LRa/e;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget-object v0, p0, Lbu/K;->a:Lkotlin/jvm/functions/Function1;

    iget-object v1, p0, Lbu/K;->b:Lkotlin/jvm/functions/Function1;

    iget-object v2, p0, Lbu/K;->c:Landroidx/recyclerview/widget/RecyclerView$t;

    iget-object v3, p0, Lbu/K;->d:Lkotlin/jvm/functions/Function1;

    iget-object v4, p0, Lbu/K;->e:LRa/e;

    move-object v5, p1

    check-cast v5, LQ4/a;

    invoke-static/range {v0 .. v5}, Lorg/xbet/consultantchat/presentation/consultantchat/adapters/delegates/ImagesSendMessageDelegateKt;->b(Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Landroidx/recyclerview/widget/RecyclerView$t;Lkotlin/jvm/functions/Function1;LRa/e;LQ4/a;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
