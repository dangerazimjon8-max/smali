.class public final Lbs/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LY2/a;


# instance fields
.field public final a:Landroidx/constraintlayout/widget/ConstraintLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final b:Landroid/view/View;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final c:Lcom/google/android/material/appbar/MaterialToolbar;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final d:Landroid/view/View;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final e:Landroid/widget/ImageView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final f:Lorg/xbet/uikit/components/lottie/LottieView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final g:Landroid/widget/FrameLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final h:Landroidx/recyclerview/widget/RecyclerView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final i:Landroidx/constraintlayout/widget/Group;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final j:Lorg/xbet/ui_core/viewcomponents/swiperefreshlayout/SwipeRefreshLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final k:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final l:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final m:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final n:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroid/view/View;Lcom/google/android/material/appbar/MaterialToolbar;Landroid/view/View;Landroid/widget/ImageView;Lorg/xbet/uikit/components/lottie/LottieView;Landroid/widget/FrameLayout;Landroidx/recyclerview/widget/RecyclerView;Landroidx/constraintlayout/widget/Group;Lorg/xbet/ui_core/viewcomponents/swiperefreshlayout/SwipeRefreshLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .locals 0
    .param p1    # Landroidx/constraintlayout/widget/ConstraintLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/appbar/MaterialToolbar;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p4    # Landroid/view/View;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p5    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p6    # Lorg/xbet/uikit/components/lottie/LottieView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p7    # Landroid/widget/FrameLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p8    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p9    # Landroidx/constraintlayout/widget/Group;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p10    # Lorg/xbet/ui_core/viewcomponents/swiperefreshlayout/SwipeRefreshLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p11    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p12    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p13    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p14    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbs/b;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 5
    .line 6
    iput-object p2, p0, Lbs/b;->b:Landroid/view/View;

    .line 7
    .line 8
    iput-object p3, p0, Lbs/b;->c:Lcom/google/android/material/appbar/MaterialToolbar;

    .line 9
    .line 10
    iput-object p4, p0, Lbs/b;->d:Landroid/view/View;

    .line 11
    .line 12
    iput-object p5, p0, Lbs/b;->e:Landroid/widget/ImageView;

    .line 13
    .line 14
    iput-object p6, p0, Lbs/b;->f:Lorg/xbet/uikit/components/lottie/LottieView;

    .line 15
    .line 16
    iput-object p7, p0, Lbs/b;->g:Landroid/widget/FrameLayout;

    .line 17
    .line 18
    iput-object p8, p0, Lbs/b;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 19
    .line 20
    iput-object p9, p0, Lbs/b;->i:Landroidx/constraintlayout/widget/Group;

    .line 21
    .line 22
    iput-object p10, p0, Lbs/b;->j:Lorg/xbet/ui_core/viewcomponents/swiperefreshlayout/SwipeRefreshLayout;

    .line 23
    .line 24
    iput-object p11, p0, Lbs/b;->k:Landroid/widget/TextView;

    .line 25
    .line 26
    iput-object p12, p0, Lbs/b;->l:Landroid/widget/TextView;

    .line 27
    .line 28
    iput-object p13, p0, Lbs/b;->m:Landroid/widget/TextView;

    .line 29
    .line 30
    iput-object p14, p0, Lbs/b;->n:Landroid/widget/TextView;

    .line 31
    .line 32
    return-void
.end method

.method public static a(Landroid/view/View;)Lbs/b;
    .locals 17
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    sget v1, Las/a;->cashbackTitleBackground:I

    .line 4
    .line 5
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    if-eqz v4, :cond_0

    .line 10
    .line 11
    sget v1, Las/a;->cashbackToolbar:I

    .line 12
    .line 13
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    move-object v5, v2

    .line 18
    check-cast v5, Lcom/google/android/material/appbar/MaterialToolbar;

    .line 19
    .line 20
    if-eqz v5, :cond_0

    .line 21
    .line 22
    sget v1, Las/a;->contentBackground:I

    .line 23
    .line 24
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 25
    .line 26
    .line 27
    move-result-object v6

    .line 28
    if-eqz v6, :cond_0

    .line 29
    .line 30
    sget v1, Las/a;->ivMoney:I

    .line 31
    .line 32
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    move-object v7, v2

    .line 37
    check-cast v7, Landroid/widget/ImageView;

    .line 38
    .line 39
    if-eqz v7, :cond_0

    .line 40
    .line 41
    sget v1, Las/a;->lottieEmptyView:I

    .line 42
    .line 43
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    move-object v8, v2

    .line 48
    check-cast v8, Lorg/xbet/uikit/components/lottie/LottieView;

    .line 49
    .line 50
    if-eqz v8, :cond_0

    .line 51
    .line 52
    sget v1, Las/a;->progressBar:I

    .line 53
    .line 54
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    move-object v9, v2

    .line 59
    check-cast v9, Landroid/widget/FrameLayout;

    .line 60
    .line 61
    if-eqz v9, :cond_0

    .line 62
    .line 63
    sget v1, Las/a;->rvCashback:I

    .line 64
    .line 65
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    move-object v10, v2

    .line 70
    check-cast v10, Landroidx/recyclerview/widget/RecyclerView;

    .line 71
    .line 72
    if-eqz v10, :cond_0

    .line 73
    .line 74
    sget v1, Las/a;->screenContent:I

    .line 75
    .line 76
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    move-object v11, v2

    .line 81
    check-cast v11, Landroidx/constraintlayout/widget/Group;

    .line 82
    .line 83
    if-eqz v11, :cond_0

    .line 84
    .line 85
    sget v1, Las/a;->swipeRefresh:I

    .line 86
    .line 87
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    move-object v12, v2

    .line 92
    check-cast v12, Lorg/xbet/ui_core/viewcomponents/swiperefreshlayout/SwipeRefreshLayout;

    .line 93
    .line 94
    if-eqz v12, :cond_0

    .line 95
    .line 96
    sget v1, Las/a;->tvAvailableTitle:I

    .line 97
    .line 98
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    move-object v13, v2

    .line 103
    check-cast v13, Landroid/widget/TextView;

    .line 104
    .line 105
    if-eqz v13, :cond_0

    .line 106
    .line 107
    sget v1, Las/a;->tvPointTitle:I

    .line 108
    .line 109
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    move-object v14, v2

    .line 114
    check-cast v14, Landroid/widget/TextView;

    .line 115
    .line 116
    if-eqz v14, :cond_0

    .line 117
    .line 118
    sget v1, Las/a;->tvRules:I

    .line 119
    .line 120
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    move-object v15, v2

    .line 125
    check-cast v15, Landroid/widget/TextView;

    .line 126
    .line 127
    if-eqz v15, :cond_0

    .line 128
    .line 129
    sget v1, Las/a;->tvRulesMessage:I

    .line 130
    .line 131
    invoke-static {v0, v1}, LY2/b;->a(Landroid/view/View;I)Landroid/view/View;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    move-object/from16 v16, v2

    .line 136
    .line 137
    check-cast v16, Landroid/widget/TextView;

    .line 138
    .line 139
    if-eqz v16, :cond_0

    .line 140
    .line 141
    new-instance v2, Lbs/b;

    .line 142
    .line 143
    move-object v3, v0

    .line 144
    check-cast v3, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 145
    .line 146
    invoke-direct/range {v2 .. v16}, Lbs/b;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroid/view/View;Lcom/google/android/material/appbar/MaterialToolbar;Landroid/view/View;Landroid/widget/ImageView;Lorg/xbet/uikit/components/lottie/LottieView;Landroid/widget/FrameLayout;Landroidx/recyclerview/widget/RecyclerView;Landroidx/constraintlayout/widget/Group;Lorg/xbet/ui_core/viewcomponents/swiperefreshlayout/SwipeRefreshLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V

    .line 147
    .line 148
    .line 149
    return-object v2

    .line 150
    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    new-instance v1, Ljava/lang/NullPointerException;

    .line 159
    .line 160
    const-string v2, "Missing required view with ID: "

    .line 161
    .line 162
    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    invoke-direct {v1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    throw v1
.end method


# virtual methods
.method public b()Landroidx/constraintlayout/widget/ConstraintLayout;
    .locals 1
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbs/b;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2
    .line 3
    return-object v0
.end method

.method public bridge synthetic getRoot()Landroid/view/View;
    .locals 1
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 1
    invoke-virtual {p0}, Lbs/b;->b()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
