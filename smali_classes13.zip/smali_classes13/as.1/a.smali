.class public final Las/a;
.super Ljava/lang/Object;


# static fields
.field public static activatedGroup:I = 0x7f0a0094

.field public static cashbackTitleBackground:I = 0x7f0a033f

.field public static cashbackToolbar:I = 0x7f0a0340

.field public static contentBackground:I = 0x7f0a04da

.field public static ivActivated:I = 0x7f0a0a77

.field public static ivActivatedBackground:I = 0x7f0a0a78

.field public static ivCashback:I = 0x7f0a0a90

.field public static ivMoney:I = 0x7f0a0b1d

.field public static lottieEmptyView:I = 0x7f0a0d24

.field public static progressBar:I = 0x7f0a0f40

.field public static rvCashback:I = 0x7f0a106e

.field public static screenContent:I = 0x7f0a110f

.field public static swipeRefresh:I = 0x7f0a1435

.field public static tvActivate:I = 0x7f0a16ce

.field public static tvAvailableTitle:I = 0x7f0a16f3

.field public static tvPointTitle:I = 0x7f0a18f9

.field public static tvRules:I = 0x7f0a1937

.field public static tvRulesMessage:I = 0x7f0a1938

.field public static tvTitle:I = 0x7f0a19e8


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
