.class public final Las/b;
.super Ljava/lang/Object;


# static fields
.field public static cashback_item:I = 0x7f0d00b9

.field public static fragment_select_cashback:I = 0x7f0d0460

.field public static info_item:I = 0x7f0d0521


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
