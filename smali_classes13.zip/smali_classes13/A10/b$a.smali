.class public final LA10/b$a;
.super LWY0/B;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LA10/b;->a(Lorg/xbet/finsecurity/impl/domain/LimitModel;)LWY0/B;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0003*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016\u00a2\u0006\u0004\u0008\u0005\u0010\u0006J\u000f\u0010\u0008\u001a\u00020\u0007H\u0016\u00a2\u0006\u0004\u0008\u0008\u0010\t\u00a8\u0006\n"
    }
    d2 = {
        "A10/b$a",
        "LWY0/B;",
        "Landroidx/fragment/app/u;",
        "factory",
        "Landroidx/fragment/app/Fragment;",
        "createFragment",
        "(Landroidx/fragment/app/u;)Landroidx/fragment/app/Fragment;",
        "",
        "needAuth",
        "()Z",
        "impl_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field public final synthetic a:Lorg/xbet/finsecurity/impl/domain/LimitModel;


# direct methods
.method public constructor <init>(Lorg/xbet/finsecurity/impl/domain/LimitModel;)V
    .locals 0

    .line 1
    iput-object p1, p0, LA10/b$a;->a:Lorg/xbet/finsecurity/impl/domain/LimitModel;

    .line 2
    .line 3
    invoke-direct {p0}, LWY0/B;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public createFragment(Landroidx/fragment/app/u;)Landroidx/fragment/app/Fragment;
    .locals 1

    .line 1
    sget-object p1, Lorg/xbet/finsecurity/impl/presentation/set_limit/SetLimitFragment;->i1:Lorg/xbet/finsecurity/impl/presentation/set_limit/SetLimitFragment$a;

    .line 2
    .line 3
    iget-object v0, p0, LA10/b$a;->a:Lorg/xbet/finsecurity/impl/domain/LimitModel;

    .line 4
    .line 5
    invoke-virtual {p1, v0}, Lorg/xbet/finsecurity/impl/presentation/set_limit/SetLimitFragment$a;->a(Lorg/xbet/finsecurity/impl/domain/LimitModel;)Lorg/xbet/finsecurity/impl/presentation/set_limit/SetLimitFragment;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public needAuth()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method
