.class public final synthetic LBo/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:Lorg/xbet/betting/event_card/presentation/delegates/a;

.field public final synthetic b:LQ4/a;


# direct methods
.method public synthetic constructor <init>(Lorg/xbet/betting/event_card/presentation/delegates/a;LQ4/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LBo/c;->a:Lorg/xbet/betting/event_card/presentation/delegates/a;

    iput-object p2, p0, LBo/c;->b:LQ4/a;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LBo/c;->a:Lorg/xbet/betting/event_card/presentation/delegates/a;

    iget-object v1, p0, LBo/c;->b:LQ4/a;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, v1, p1}, Lorg/xbet/betting/event_card/presentation/linelive/gamecard/type15/GameCardType15ViewHolderKt;->a(Lorg/xbet/betting/event_card/presentation/delegates/a;LQ4/a;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
