.class public final Lcl/c$b$m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldagger/internal/h;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcl/c$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "m"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ldagger/internal/h<",
        "Lorg/xbet/feed/subscriptions/domain/usecases/i;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:LnZ/n;


# direct methods
.method public constructor <init>(LnZ/n;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcl/c$b$m;->a:LnZ/n;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public a()Lorg/xbet/feed/subscriptions/domain/usecases/i;
    .locals 1

    .line 1
    iget-object v0, p0, Lcl/c$b$m;->a:LnZ/n;

    .line 2
    .line 3
    invoke-interface {v0}, LnZ/n;->D()Lorg/xbet/feed/subscriptions/domain/usecases/i;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, Ldagger/internal/g;->d(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Lorg/xbet/feed/subscriptions/domain/usecases/i;

    .line 12
    .line 13
    return-object v0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcl/c$b$m;->a()Lorg/xbet/feed/subscriptions/domain/usecases/i;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
