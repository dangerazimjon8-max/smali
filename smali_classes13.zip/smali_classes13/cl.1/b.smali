.class public final synthetic Lcl/b;
.super Ljava/lang/Object;
.source "SourceFile"
