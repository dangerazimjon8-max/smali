.class public final Lcl/a$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcl/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:Ly11/a;

.field public final b:Lcl/a$b;


# direct methods
.method public constructor <init>(Ly11/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p0, p0, Lcl/a$b;->b:Lcl/a$b;

    .line 5
    .line 6
    iput-object p1, p0, Lcl/a$b;->a:Ly11/a;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(Lorg/xbet/bethistory/history/presentation/dialog/HideHistoryDialog;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcl/a$b;->b(Lorg/xbet/bethistory/history/presentation/dialog/HideHistoryDialog;)Lorg/xbet/bethistory/history/presentation/dialog/HideHistoryDialog;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final b(Lorg/xbet/bethistory/history/presentation/dialog/HideHistoryDialog;)Lorg/xbet/bethistory/history/presentation/dialog/HideHistoryDialog;
    .locals 1
    .annotation build Lcom/google/errorprone/annotations/CanIgnoreReturnValue;
    .end annotation

    .line 1
    iget-object v0, p0, Lcl/a$b;->a:Ly11/a;

    .line 2
    .line 3
    invoke-static {p1, v0}, Lorg/xbet/bethistory/history/presentation/dialog/f;->a(Lorg/xbet/bethistory/history/presentation/dialog/HideHistoryDialog;Ly11/a;)V

    .line 4
    .line 5
    .line 6
    return-object p1
.end method
