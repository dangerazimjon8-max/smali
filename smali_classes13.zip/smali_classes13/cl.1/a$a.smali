.class public final Lcl/a$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcl/e$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lcl/b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcl/a$a;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ly11/a;)Lcl/e;
    .locals 1

    .line 1
    invoke-static {p1}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    new-instance v0, Lcl/a$b;

    .line 5
    .line 6
    invoke-direct {v0, p1}, Lcl/a$b;-><init>(Ly11/a;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method
