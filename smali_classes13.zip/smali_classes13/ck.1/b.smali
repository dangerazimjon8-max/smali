.class public final Lck/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldagger/internal/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ldagger/internal/d<",
        "Lck/a;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lbk/a;",
            ">;"
        }
    .end annotation
.end field

.field public final b:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LAk/g;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ldagger/internal/h;Ldagger/internal/h;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "Lbk/a;",
            ">;",
            "Ldagger/internal/h<",
            "LAk/g;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lck/b;->a:Ldagger/internal/h;

    .line 5
    .line 6
    iput-object p2, p0, Lck/b;->b:Ldagger/internal/h;

    .line 7
    .line 8
    return-void
.end method

.method public static a(Ldagger/internal/h;Ldagger/internal/h;)Lck/b;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "Lbk/a;",
            ">;",
            "Ldagger/internal/h<",
            "LAk/g;",
            ">;)",
            "Lck/b;"
        }
    .end annotation

    .line 1
    new-instance v0, Lck/b;

    .line 2
    .line 3
    invoke-direct {v0, p0, p1}, Lck/b;-><init>(Ldagger/internal/h;Ldagger/internal/h;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public static c(Lbk/a;LAk/g;)Lck/a;
    .locals 1

    .line 1
    new-instance v0, Lck/a;

    .line 2
    .line 3
    invoke-direct {v0, p0, p1}, Lck/a;-><init>(Lbk/a;LAk/g;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method


# virtual methods
.method public b()Lck/a;
    .locals 2

    .line 1
    iget-object v0, p0, Lck/b;->a:Ldagger/internal/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lbk/a;

    .line 8
    .line 9
    iget-object v1, p0, Lck/b;->b:Ldagger/internal/h;

    .line 10
    .line 11
    invoke-interface {v1}, Lib/a;->get()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, LAk/g;

    .line 16
    .line 17
    invoke-static {v0, v1}, Lck/b;->c(Lbk/a;LAk/g;)Lck/a;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lck/b;->b()Lck/a;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
