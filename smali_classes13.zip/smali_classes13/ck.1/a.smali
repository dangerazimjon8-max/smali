.class public final Lck/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0002\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0007\u0008\u0000\u0018\u00002\u00020\u0001B\u0019\u0008\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\u0008\u0006\u0010\u0007JN\u0010\u0016\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u00082\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\u000c\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u00112\u000c\u0010\u0015\u001a\u0008\u0012\u0004\u0012\u00020\u00140\u0013H\u0086@\u00a2\u0006\u0004\u0008\u0016\u0010\u0017R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u0016\u0010\u0018R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u0019\u0010\u001a\u00a8\u0006\u001b"
    }
    d2 = {
        "Lck/a;",
        "",
        "Lbk/a;",
        "makeBetRepository",
        "LAk/g;",
        "getCoefViewTypeUseCase",
        "<init>",
        "(Lbk/a;LAk/g;)V",
        "Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;",
        "betModel",
        "",
        "userId",
        "balanceId",
        "",
        "sum",
        "",
        "promocode",
        "",
        "checkCf",
        "",
        "LPj/a;",
        "playerList",
        "a",
        "(Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;JJDLjava/lang/String;ILjava/util/List;Lkotlin/coroutines/e;)Ljava/lang/Object;",
        "Lbk/a;",
        "b",
        "LAk/g;",
        "impl_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field public final a:Lbk/a;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final b:LAk/g;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lbk/a;LAk/g;)V
    .locals 0
    .param p1    # Lbk/a;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LAk/g;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lck/a;->a:Lbk/a;

    .line 5
    .line 6
    iput-object p2, p0, Lck/a;->b:LAk/g;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;JJDLjava/lang/String;ILjava/util/List;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 16
    .param p1    # Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p8    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p10    # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p11    # Lkotlin/coroutines/e;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;",
            "JJD",
            "Ljava/lang/String;",
            "I",
            "Ljava/util/List<",
            "LPj/a;",
            ">;",
            "Lkotlin/coroutines/e<",
            "-",
            "Ljava/lang/Double;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lck/a;->a:Lbk/a;

    .line 4
    .line 5
    iget-object v2, v0, Lck/a;->b:LAk/g;

    .line 6
    .line 7
    invoke-interface {v2}, LAk/g;->invoke()I

    .line 8
    .line 9
    .line 10
    move-result v14

    .line 11
    const-wide/16 v7, 0x5f

    .line 12
    .line 13
    move-object/from16 v2, p1

    .line 14
    .line 15
    move-wide/from16 v3, p2

    .line 16
    .line 17
    move-wide/from16 v5, p4

    .line 18
    .line 19
    move-wide/from16 v9, p6

    .line 20
    .line 21
    move-object/from16 v11, p8

    .line 22
    .line 23
    move/from16 v12, p9

    .line 24
    .line 25
    move-object/from16 v13, p10

    .line 26
    .line 27
    move-object/from16 v15, p11

    .line 28
    .line 29
    invoke-interface/range {v1 .. v15}, Lbk/a;->a(Lorg/xbet/bet_constructor/impl/bets/domain/models/BetModel;JJJDLjava/lang/String;ILjava/util/List;ILkotlin/coroutines/e;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    return-object v1
.end method
