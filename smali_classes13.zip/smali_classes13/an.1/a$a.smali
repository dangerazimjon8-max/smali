.class public final Lan/a$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lan/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\r\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\u0008\u0005\u0010\u0006\u00a8\u0006\u0007"
    }
    d2 = {
        "Lan/a$a;",
        "",
        "<init>",
        "()V",
        "Lan/a;",
        "a",
        "()Lan/a;",
        "core_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lan/a$a;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Lan/a;
    .locals 35
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    new-instance v0, Lan/b;

    .line 2
    .line 3
    const-string v5, ""

    .line 4
    .line 5
    const-string v6, ""

    .line 6
    .line 7
    const-wide/16 v1, 0x0

    .line 8
    .line 9
    const-string v3, ""

    .line 10
    .line 11
    const-string v4, ""

    .line 12
    .line 13
    invoke-direct/range {v0 .. v6}, Lan/b;-><init>(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    sget-object v29, Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;->UNKNOWN:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;

    .line 17
    .line 18
    sget-object v32, Lcom/xbet/onexuser/domain/betting/PlayersDuelModel$GameWithoutDuel;->INSTANCE:Lcom/xbet/onexuser/domain/betting/PlayersDuelModel$GameWithoutDuel;

    .line 19
    .line 20
    sget-object v33, Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;->DEFAULT:Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;

    .line 21
    .line 22
    move-object/from16 v27, v0

    .line 23
    .line 24
    new-instance v0, Lan/a;

    .line 25
    .line 26
    const-wide/16 v30, 0x0

    .line 27
    .line 28
    const/16 v34, 0x0

    .line 29
    .line 30
    const-wide/16 v1, -0x1

    .line 31
    .line 32
    const-wide/16 v3, 0x0

    .line 33
    .line 34
    const-wide/16 v5, 0x0

    .line 35
    .line 36
    const-wide/16 v7, 0x0

    .line 37
    .line 38
    const-wide/16 v9, 0x0

    .line 39
    .line 40
    const-string v11, ""

    .line 41
    .line 42
    const-string v12, ""

    .line 43
    .line 44
    const-string v13, ""

    .line 45
    .line 46
    const-string v14, ""

    .line 47
    .line 48
    const-string v15, ""

    .line 49
    .line 50
    const-string v16, ""

    .line 51
    .line 52
    const-string v17, ""

    .line 53
    .line 54
    const-string v18, ""

    .line 55
    .line 56
    const-string v19, ""

    .line 57
    .line 58
    const-string v20, ""

    .line 59
    .line 60
    const-string v21, ""

    .line 61
    .line 62
    const-wide/16 v22, 0x0

    .line 63
    .line 64
    const-string v24, ""

    .line 65
    .line 66
    const-wide/16 v25, 0x0

    .line 67
    .line 68
    const-string v28, ""

    .line 69
    .line 70
    invoke-direct/range {v0 .. v34}, Lan/a;-><init>(JJJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;DLan/b;Ljava/lang/String;Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;JLcom/xbet/onexuser/domain/betting/PlayersDuelModel;Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;I)V

    .line 71
    .line 72
    .line 73
    return-object v0
.end method
