.class public final Lan/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lan/a$a;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\t\n\u0002\u0008\u0005\n\u0002\u0010\u000e\n\u0002\u0008\r\n\u0002\u0010\u0006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\n\n\u0002\u0010\u000b\n\u0002\u0008,\u0008\u0087\u0008\u0018\u0000 G2\u00020\u0001:\u0001&B\u00d7\u0001\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0002\u0012\u0006\u0010\u0007\u001a\u00020\u0002\u0012\u0006\u0010\t\u001a\u00020\u0008\u0012\u0006\u0010\n\u001a\u00020\u0008\u0012\u0006\u0010\u000b\u001a\u00020\u0008\u0012\u0006\u0010\u000c\u001a\u00020\u0008\u0012\u0006\u0010\r\u001a\u00020\u0008\u0012\u0006\u0010\u000e\u001a\u00020\u0008\u0012\u0006\u0010\u000f\u001a\u00020\u0008\u0012\u0006\u0010\u0010\u001a\u00020\u0008\u0012\u0006\u0010\u0011\u001a\u00020\u0008\u0012\u0006\u0010\u0012\u001a\u00020\u0008\u0012\u0006\u0010\u0013\u001a\u00020\u0008\u0012\u0006\u0010\u0014\u001a\u00020\u0002\u0012\u0006\u0010\u0015\u001a\u00020\u0008\u0012\u0006\u0010\u0017\u001a\u00020\u0016\u0012\u0006\u0010\u0019\u001a\u00020\u0018\u0012\u0006\u0010\u001a\u001a\u00020\u0008\u0012\u0006\u0010\u001c\u001a\u00020\u001b\u0012\u0006\u0010\u001d\u001a\u00020\u0002\u0012\u0006\u0010\u001f\u001a\u00020\u001e\u0012\u0006\u0010!\u001a\u00020 \u0012\u0006\u0010#\u001a\u00020\"\u00a2\u0006\u0004\u0008$\u0010%J\u0094\u0002\u0010&\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u00022\u0008\u0008\u0002\u0010\t\u001a\u00020\u00082\u0008\u0008\u0002\u0010\n\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u000b\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u000c\u001a\u00020\u00082\u0008\u0008\u0002\u0010\r\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u000e\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u000f\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u0010\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u0011\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u0012\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u0013\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u0014\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0015\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u0017\u001a\u00020\u00162\u0008\u0008\u0002\u0010\u0019\u001a\u00020\u00182\u0008\u0008\u0002\u0010\u001a\u001a\u00020\u00082\u0008\u0008\u0002\u0010\u001c\u001a\u00020\u001b2\u0008\u0008\u0002\u0010\u001d\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u001f\u001a\u00020\u001e2\u0008\u0008\u0002\u0010!\u001a\u00020 2\u0008\u0008\u0002\u0010#\u001a\u00020\"H\u00c6\u0001\u00a2\u0006\u0004\u0008&\u0010\'J\u0010\u0010(\u001a\u00020\u0008H\u00d6\u0001\u00a2\u0006\u0004\u0008(\u0010)J\u0010\u0010*\u001a\u00020\"H\u00d6\u0001\u00a2\u0006\u0004\u0008*\u0010+J\u001a\u0010.\u001a\u00020-2\u0008\u0010,\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003\u00a2\u0006\u0004\u0008.\u0010/R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008&\u00100\u001a\u0004\u00081\u00102R\u0017\u0010\u0004\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u00083\u00100\u001a\u0004\u00084\u00102R\u0017\u0010\u0005\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u00085\u00100\u001a\u0004\u00086\u00102R\u0017\u0010\u0006\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u00087\u00100\u001a\u0004\u00088\u00102R\u0017\u0010\u0007\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u00089\u00100\u001a\u0004\u0008:\u00102R\u0017\u0010\t\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008;\u0010<\u001a\u0004\u0008=\u0010)R\u0017\u0010\n\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008>\u0010<\u001a\u0004\u0008?\u0010)R\u0017\u0010\u000b\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008@\u0010<\u001a\u0004\u0008>\u0010)R\u0017\u0010\u000c\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008A\u0010<\u001a\u0004\u0008A\u0010)R\u0017\u0010\r\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u00084\u0010<\u001a\u0004\u0008@\u0010)R\u0017\u0010\u000e\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008?\u0010<\u001a\u0004\u0008B\u0010)R\u0017\u0010\u000f\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008C\u0010<\u001a\u0004\u0008D\u0010)R\u0017\u0010\u0010\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u00081\u0010<\u001a\u0004\u0008E\u0010)R\u0017\u0010\u0011\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008F\u0010<\u001a\u0004\u0008G\u0010)R\u0017\u0010\u0012\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u00086\u0010<\u001a\u0004\u0008C\u0010)R\u0017\u0010\u0013\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008H\u0010<\u001a\u0004\u00085\u0010)R\u0017\u0010\u0014\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008I\u00100\u001a\u0004\u0008;\u00102R\u0017\u0010\u0015\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u00088\u0010<\u001a\u0004\u00087\u0010)R\u0017\u0010\u0017\u001a\u00020\u00168\u0006\u00a2\u0006\u000c\n\u0004\u0008=\u0010J\u001a\u0004\u0008I\u0010KR\u0017\u0010\u0019\u001a\u00020\u00188\u0006\u00a2\u0006\u000c\n\u0004\u0008L\u0010M\u001a\u0004\u0008N\u0010OR\u0017\u0010\u001a\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008P\u0010<\u001a\u0004\u0008H\u0010)R\u0017\u0010\u001c\u001a\u00020\u001b8\u0006\u00a2\u0006\u000c\n\u0004\u0008B\u0010Q\u001a\u0004\u0008F\u0010RR\u0017\u0010\u001d\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008E\u00100\u001a\u0004\u0008S\u00102R\u0017\u0010\u001f\u001a\u00020\u001e8\u0006\u00a2\u0006\u000c\n\u0004\u0008D\u0010T\u001a\u0004\u0008L\u0010UR\u0017\u0010!\u001a\u00020 8\u0006\u00a2\u0006\u000c\n\u0004\u0008:\u0010V\u001a\u0004\u00089\u0010WR\u0017\u0010#\u001a\u00020\"8\u0006\u00a2\u0006\u000c\n\u0004\u0008N\u0010X\u001a\u0004\u0008P\u0010+\u00a8\u0006Y"
    }
    d2 = {
        "Lan/a;",
        "",
        "",
        "id",
        "gameId",
        "mainGameId",
        "playerId",
        "sportId",
        "",
        "playerName",
        "gameMatchName",
        "firstOpponentFirstImg",
        "firstOpponentSecondImg",
        "firstOpponentName",
        "secondOpponentFirstImg",
        "secondOpponentSecondImg",
        "secondOpponentName",
        "tournamentStage",
        "groupName",
        "champName",
        "expressNumber",
        "coefficient",
        "",
        "param",
        "Lan/b;",
        "subtitle",
        "name",
        "Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;",
        "kind",
        "type",
        "Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;",
        "playersDuel",
        "Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;",
        "couponEntryFeature",
        "",
        "playersNumber",
        "<init>",
        "(JJJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;DLan/b;Ljava/lang/String;Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;JLcom/xbet/onexuser/domain/betting/PlayersDuelModel;Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;I)V",
        "a",
        "(JJJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;DLan/b;Ljava/lang/String;Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;JLcom/xbet/onexuser/domain/betting/PlayersDuelModel;Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;I)Lan/a;",
        "toString",
        "()Ljava/lang/String;",
        "hashCode",
        "()I",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "J",
        "m",
        "()J",
        "b",
        "j",
        "c",
        "o",
        "d",
        "r",
        "e",
        "y",
        "f",
        "Ljava/lang/String;",
        "s",
        "g",
        "k",
        "h",
        "i",
        "v",
        "l",
        "x",
        "w",
        "n",
        "A",
        "p",
        "q",
        "D",
        "()D",
        "t",
        "Lan/b;",
        "z",
        "()Lan/b;",
        "u",
        "Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;",
        "()Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;",
        "B",
        "Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;",
        "()Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;",
        "Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;",
        "()Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;",
        "I",
        "core_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final A:Lan/a$a;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public static final B:I


# instance fields
.field public final a:J

.field public final b:J

.field public final c:J

.field public final d:J

.field public final e:J

.field public final f:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final g:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final h:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final i:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final j:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final k:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final l:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final m:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final n:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final o:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final p:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final q:J

.field public final r:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final s:D

.field public final t:Lan/b;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final u:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final v:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final w:J

.field public final x:Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final y:Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final z:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lan/a$a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lan/a$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lan/a;->A:Lan/a$a;

    .line 8
    .line 9
    const/16 v0, 0x8

    .line 10
    .line 11
    sput v0, Lan/a;->B:I

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>(JJJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;DLan/b;Ljava/lang/String;Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;JLcom/xbet/onexuser/domain/betting/PlayersDuelModel;Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;I)V
    .locals 0
    .param p11    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p12    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p13    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p14    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p15    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p16    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p17    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p18    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p19    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p20    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p21    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p24    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p27    # Lan/b;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p28    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p29    # Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p32    # Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p33    # Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Lan/a;->a:J

    .line 5
    .line 6
    iput-wide p3, p0, Lan/a;->b:J

    .line 7
    .line 8
    iput-wide p5, p0, Lan/a;->c:J

    .line 9
    .line 10
    iput-wide p7, p0, Lan/a;->d:J

    .line 11
    .line 12
    iput-wide p9, p0, Lan/a;->e:J

    .line 13
    .line 14
    iput-object p11, p0, Lan/a;->f:Ljava/lang/String;

    .line 15
    .line 16
    iput-object p12, p0, Lan/a;->g:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p13, p0, Lan/a;->h:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p14, p0, Lan/a;->i:Ljava/lang/String;

    .line 21
    .line 22
    iput-object p15, p0, Lan/a;->j:Ljava/lang/String;

    .line 23
    .line 24
    move-object/from16 p1, p16

    .line 25
    .line 26
    iput-object p1, p0, Lan/a;->k:Ljava/lang/String;

    .line 27
    .line 28
    move-object/from16 p1, p17

    .line 29
    .line 30
    iput-object p1, p0, Lan/a;->l:Ljava/lang/String;

    .line 31
    .line 32
    move-object/from16 p1, p18

    .line 33
    .line 34
    iput-object p1, p0, Lan/a;->m:Ljava/lang/String;

    .line 35
    .line 36
    move-object/from16 p1, p19

    .line 37
    .line 38
    iput-object p1, p0, Lan/a;->n:Ljava/lang/String;

    .line 39
    .line 40
    move-object/from16 p1, p20

    .line 41
    .line 42
    iput-object p1, p0, Lan/a;->o:Ljava/lang/String;

    .line 43
    .line 44
    move-object/from16 p1, p21

    .line 45
    .line 46
    iput-object p1, p0, Lan/a;->p:Ljava/lang/String;

    .line 47
    .line 48
    move-wide/from16 p1, p22

    .line 49
    .line 50
    iput-wide p1, p0, Lan/a;->q:J

    .line 51
    .line 52
    move-object/from16 p1, p24

    .line 53
    .line 54
    iput-object p1, p0, Lan/a;->r:Ljava/lang/String;

    .line 55
    .line 56
    move-wide/from16 p1, p25

    .line 57
    .line 58
    iput-wide p1, p0, Lan/a;->s:D

    .line 59
    .line 60
    move-object/from16 p1, p27

    .line 61
    .line 62
    iput-object p1, p0, Lan/a;->t:Lan/b;

    .line 63
    .line 64
    move-object/from16 p1, p28

    .line 65
    .line 66
    iput-object p1, p0, Lan/a;->u:Ljava/lang/String;

    .line 67
    .line 68
    move-object/from16 p1, p29

    .line 69
    .line 70
    iput-object p1, p0, Lan/a;->v:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;

    .line 71
    .line 72
    move-wide/from16 p1, p30

    .line 73
    .line 74
    iput-wide p1, p0, Lan/a;->w:J

    .line 75
    .line 76
    move-object/from16 p1, p32

    .line 77
    .line 78
    iput-object p1, p0, Lan/a;->x:Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;

    .line 79
    .line 80
    move-object/from16 p1, p33

    .line 81
    .line 82
    iput-object p1, p0, Lan/a;->y:Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;

    .line 83
    .line 84
    move/from16 p1, p34

    .line 85
    .line 86
    iput p1, p0, Lan/a;->z:I

    .line 87
    .line 88
    return-void
.end method

.method public static synthetic b(Lan/a;JJJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;DLan/b;Ljava/lang/String;Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;JLcom/xbet/onexuser/domain/betting/PlayersDuelModel;Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;IILjava/lang/Object;)Lan/a;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p35

    .line 4
    .line 5
    and-int/lit8 v2, v1, 0x1

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    iget-wide v2, v0, Lan/a;->a:J

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    move-wide/from16 v2, p1

    .line 13
    .line 14
    :goto_0
    and-int/lit8 v4, v1, 0x2

    .line 15
    .line 16
    if-eqz v4, :cond_1

    .line 17
    .line 18
    iget-wide v4, v0, Lan/a;->b:J

    .line 19
    .line 20
    goto :goto_1

    .line 21
    :cond_1
    move-wide/from16 v4, p3

    .line 22
    .line 23
    :goto_1
    and-int/lit8 v6, v1, 0x4

    .line 24
    .line 25
    if-eqz v6, :cond_2

    .line 26
    .line 27
    iget-wide v6, v0, Lan/a;->c:J

    .line 28
    .line 29
    goto :goto_2

    .line 30
    :cond_2
    move-wide/from16 v6, p5

    .line 31
    .line 32
    :goto_2
    and-int/lit8 v8, v1, 0x8

    .line 33
    .line 34
    if-eqz v8, :cond_3

    .line 35
    .line 36
    iget-wide v8, v0, Lan/a;->d:J

    .line 37
    .line 38
    goto :goto_3

    .line 39
    :cond_3
    move-wide/from16 v8, p7

    .line 40
    .line 41
    :goto_3
    and-int/lit8 v10, v1, 0x10

    .line 42
    .line 43
    if-eqz v10, :cond_4

    .line 44
    .line 45
    iget-wide v10, v0, Lan/a;->e:J

    .line 46
    .line 47
    goto :goto_4

    .line 48
    :cond_4
    move-wide/from16 v10, p9

    .line 49
    .line 50
    :goto_4
    and-int/lit8 v12, v1, 0x20

    .line 51
    .line 52
    if-eqz v12, :cond_5

    .line 53
    .line 54
    iget-object v12, v0, Lan/a;->f:Ljava/lang/String;

    .line 55
    .line 56
    goto :goto_5

    .line 57
    :cond_5
    move-object/from16 v12, p11

    .line 58
    .line 59
    :goto_5
    and-int/lit8 v13, v1, 0x40

    .line 60
    .line 61
    if-eqz v13, :cond_6

    .line 62
    .line 63
    iget-object v13, v0, Lan/a;->g:Ljava/lang/String;

    .line 64
    .line 65
    goto :goto_6

    .line 66
    :cond_6
    move-object/from16 v13, p12

    .line 67
    .line 68
    :goto_6
    and-int/lit16 v14, v1, 0x80

    .line 69
    .line 70
    if-eqz v14, :cond_7

    .line 71
    .line 72
    iget-object v14, v0, Lan/a;->h:Ljava/lang/String;

    .line 73
    .line 74
    goto :goto_7

    .line 75
    :cond_7
    move-object/from16 v14, p13

    .line 76
    .line 77
    :goto_7
    and-int/lit16 v15, v1, 0x100

    .line 78
    .line 79
    if-eqz v15, :cond_8

    .line 80
    .line 81
    iget-object v15, v0, Lan/a;->i:Ljava/lang/String;

    .line 82
    .line 83
    goto :goto_8

    .line 84
    :cond_8
    move-object/from16 v15, p14

    .line 85
    .line 86
    :goto_8
    move-wide/from16 v16, v2

    .line 87
    .line 88
    and-int/lit16 v2, v1, 0x200

    .line 89
    .line 90
    if-eqz v2, :cond_9

    .line 91
    .line 92
    iget-object v2, v0, Lan/a;->j:Ljava/lang/String;

    .line 93
    .line 94
    goto :goto_9

    .line 95
    :cond_9
    move-object/from16 v2, p15

    .line 96
    .line 97
    :goto_9
    and-int/lit16 v3, v1, 0x400

    .line 98
    .line 99
    if-eqz v3, :cond_a

    .line 100
    .line 101
    iget-object v3, v0, Lan/a;->k:Ljava/lang/String;

    .line 102
    .line 103
    goto :goto_a

    .line 104
    :cond_a
    move-object/from16 v3, p16

    .line 105
    .line 106
    :goto_a
    move-object/from16 p1, v2

    .line 107
    .line 108
    and-int/lit16 v2, v1, 0x800

    .line 109
    .line 110
    if-eqz v2, :cond_b

    .line 111
    .line 112
    iget-object v2, v0, Lan/a;->l:Ljava/lang/String;

    .line 113
    .line 114
    goto :goto_b

    .line 115
    :cond_b
    move-object/from16 v2, p17

    .line 116
    .line 117
    :goto_b
    move-object/from16 p2, v2

    .line 118
    .line 119
    and-int/lit16 v2, v1, 0x1000

    .line 120
    .line 121
    if-eqz v2, :cond_c

    .line 122
    .line 123
    iget-object v2, v0, Lan/a;->m:Ljava/lang/String;

    .line 124
    .line 125
    goto :goto_c

    .line 126
    :cond_c
    move-object/from16 v2, p18

    .line 127
    .line 128
    :goto_c
    move-object/from16 p3, v2

    .line 129
    .line 130
    and-int/lit16 v2, v1, 0x2000

    .line 131
    .line 132
    if-eqz v2, :cond_d

    .line 133
    .line 134
    iget-object v2, v0, Lan/a;->n:Ljava/lang/String;

    .line 135
    .line 136
    goto :goto_d

    .line 137
    :cond_d
    move-object/from16 v2, p19

    .line 138
    .line 139
    :goto_d
    move-object/from16 p4, v2

    .line 140
    .line 141
    and-int/lit16 v2, v1, 0x4000

    .line 142
    .line 143
    if-eqz v2, :cond_e

    .line 144
    .line 145
    iget-object v2, v0, Lan/a;->o:Ljava/lang/String;

    .line 146
    .line 147
    goto :goto_e

    .line 148
    :cond_e
    move-object/from16 v2, p20

    .line 149
    .line 150
    :goto_e
    const v18, 0x8000

    .line 151
    .line 152
    .line 153
    and-int v18, v1, v18

    .line 154
    .line 155
    if-eqz v18, :cond_f

    .line 156
    .line 157
    iget-object v1, v0, Lan/a;->p:Ljava/lang/String;

    .line 158
    .line 159
    goto :goto_f

    .line 160
    :cond_f
    move-object/from16 v1, p21

    .line 161
    .line 162
    :goto_f
    const/high16 v18, 0x10000

    .line 163
    .line 164
    and-int v18, p35, v18

    .line 165
    .line 166
    move-object/from16 p6, v1

    .line 167
    .line 168
    move-object/from16 p5, v2

    .line 169
    .line 170
    if-eqz v18, :cond_10

    .line 171
    .line 172
    iget-wide v1, v0, Lan/a;->q:J

    .line 173
    .line 174
    goto :goto_10

    .line 175
    :cond_10
    move-wide/from16 v1, p22

    .line 176
    .line 177
    :goto_10
    const/high16 v18, 0x20000

    .line 178
    .line 179
    and-int v18, p35, v18

    .line 180
    .line 181
    move-wide/from16 p7, v1

    .line 182
    .line 183
    if-eqz v18, :cond_11

    .line 184
    .line 185
    iget-object v1, v0, Lan/a;->r:Ljava/lang/String;

    .line 186
    .line 187
    goto :goto_11

    .line 188
    :cond_11
    move-object/from16 v1, p24

    .line 189
    .line 190
    :goto_11
    const/high16 v2, 0x40000

    .line 191
    .line 192
    and-int v2, p35, v2

    .line 193
    .line 194
    move-object/from16 p9, v1

    .line 195
    .line 196
    if-eqz v2, :cond_12

    .line 197
    .line 198
    iget-wide v1, v0, Lan/a;->s:D

    .line 199
    .line 200
    goto :goto_12

    .line 201
    :cond_12
    move-wide/from16 v1, p25

    .line 202
    .line 203
    :goto_12
    const/high16 v18, 0x80000

    .line 204
    .line 205
    and-int v18, p35, v18

    .line 206
    .line 207
    move-wide/from16 p10, v1

    .line 208
    .line 209
    if-eqz v18, :cond_13

    .line 210
    .line 211
    iget-object v1, v0, Lan/a;->t:Lan/b;

    .line 212
    .line 213
    goto :goto_13

    .line 214
    :cond_13
    move-object/from16 v1, p27

    .line 215
    .line 216
    :goto_13
    const/high16 v2, 0x100000

    .line 217
    .line 218
    and-int v2, p35, v2

    .line 219
    .line 220
    if-eqz v2, :cond_14

    .line 221
    .line 222
    iget-object v2, v0, Lan/a;->u:Ljava/lang/String;

    .line 223
    .line 224
    goto :goto_14

    .line 225
    :cond_14
    move-object/from16 v2, p28

    .line 226
    .line 227
    :goto_14
    const/high16 v18, 0x200000

    .line 228
    .line 229
    and-int v18, p35, v18

    .line 230
    .line 231
    move-object/from16 p12, v1

    .line 232
    .line 233
    if-eqz v18, :cond_15

    .line 234
    .line 235
    iget-object v1, v0, Lan/a;->v:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;

    .line 236
    .line 237
    goto :goto_15

    .line 238
    :cond_15
    move-object/from16 v1, p29

    .line 239
    .line 240
    :goto_15
    const/high16 v18, 0x400000

    .line 241
    .line 242
    and-int v18, p35, v18

    .line 243
    .line 244
    move-object/from16 p14, v1

    .line 245
    .line 246
    move-object/from16 p13, v2

    .line 247
    .line 248
    if-eqz v18, :cond_16

    .line 249
    .line 250
    iget-wide v1, v0, Lan/a;->w:J

    .line 251
    .line 252
    goto :goto_16

    .line 253
    :cond_16
    move-wide/from16 v1, p30

    .line 254
    .line 255
    :goto_16
    const/high16 v18, 0x800000

    .line 256
    .line 257
    and-int v18, p35, v18

    .line 258
    .line 259
    move-wide/from16 p15, v1

    .line 260
    .line 261
    if-eqz v18, :cond_17

    .line 262
    .line 263
    iget-object v1, v0, Lan/a;->x:Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;

    .line 264
    .line 265
    goto :goto_17

    .line 266
    :cond_17
    move-object/from16 v1, p32

    .line 267
    .line 268
    :goto_17
    const/high16 v2, 0x1000000

    .line 269
    .line 270
    and-int v2, p35, v2

    .line 271
    .line 272
    if-eqz v2, :cond_18

    .line 273
    .line 274
    iget-object v2, v0, Lan/a;->y:Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;

    .line 275
    .line 276
    goto :goto_18

    .line 277
    :cond_18
    move-object/from16 v2, p33

    .line 278
    .line 279
    :goto_18
    const/high16 v18, 0x2000000

    .line 280
    .line 281
    and-int v18, p35, v18

    .line 282
    .line 283
    if-eqz v18, :cond_19

    .line 284
    .line 285
    move-object/from16 p17, v1

    .line 286
    .line 287
    iget v1, v0, Lan/a;->z:I

    .line 288
    .line 289
    move-object/from16 p33, p17

    .line 290
    .line 291
    move/from16 p35, v1

    .line 292
    .line 293
    :goto_19
    move-object/from16 p18, p2

    .line 294
    .line 295
    move-object/from16 p19, p3

    .line 296
    .line 297
    move-object/from16 p20, p4

    .line 298
    .line 299
    move-object/from16 p21, p5

    .line 300
    .line 301
    move-object/from16 p22, p6

    .line 302
    .line 303
    move-wide/from16 p23, p7

    .line 304
    .line 305
    move-object/from16 p25, p9

    .line 306
    .line 307
    move-wide/from16 p26, p10

    .line 308
    .line 309
    move-object/from16 p28, p12

    .line 310
    .line 311
    move-object/from16 p29, p13

    .line 312
    .line 313
    move-object/from16 p30, p14

    .line 314
    .line 315
    move-wide/from16 p31, p15

    .line 316
    .line 317
    move-object/from16 p34, v2

    .line 318
    .line 319
    move-object/from16 p17, v3

    .line 320
    .line 321
    move-wide/from16 p4, v4

    .line 322
    .line 323
    move-wide/from16 p6, v6

    .line 324
    .line 325
    move-wide/from16 p8, v8

    .line 326
    .line 327
    move-wide/from16 p10, v10

    .line 328
    .line 329
    move-object/from16 p12, v12

    .line 330
    .line 331
    move-object/from16 p13, v13

    .line 332
    .line 333
    move-object/from16 p14, v14

    .line 334
    .line 335
    move-object/from16 p15, v15

    .line 336
    .line 337
    move-wide/from16 p2, v16

    .line 338
    .line 339
    move-object/from16 p16, p1

    .line 340
    .line 341
    move-object/from16 p1, v0

    .line 342
    .line 343
    goto :goto_1a

    .line 344
    :cond_19
    move/from16 p35, p34

    .line 345
    .line 346
    move-object/from16 p33, v1

    .line 347
    .line 348
    goto :goto_19

    .line 349
    :goto_1a
    invoke-virtual/range {p1 .. p35}, Lan/a;->a(JJJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;DLan/b;Ljava/lang/String;Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;JLcom/xbet/onexuser/domain/betting/PlayersDuelModel;Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;I)Lan/a;

    .line 350
    .line 351
    .line 352
    move-result-object v0

    .line 353
    return-object v0
.end method


# virtual methods
.method public final A()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->n:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final B()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lan/a;->w:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final a(JJJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;DLan/b;Ljava/lang/String;Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;JLcom/xbet/onexuser/domain/betting/PlayersDuelModel;Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;I)Lan/a;
    .locals 35
    .param p11    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p12    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p13    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p14    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p15    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p16    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p17    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p18    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p19    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p20    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p21    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p24    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p27    # Lan/b;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p28    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p29    # Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p32    # Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p33    # Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    new-instance v0, Lan/a;

    .line 2
    .line 3
    move-wide/from16 v1, p1

    .line 4
    .line 5
    move-wide/from16 v3, p3

    .line 6
    .line 7
    move-wide/from16 v5, p5

    .line 8
    .line 9
    move-wide/from16 v7, p7

    .line 10
    .line 11
    move-wide/from16 v9, p9

    .line 12
    .line 13
    move-object/from16 v11, p11

    .line 14
    .line 15
    move-object/from16 v12, p12

    .line 16
    .line 17
    move-object/from16 v13, p13

    .line 18
    .line 19
    move-object/from16 v14, p14

    .line 20
    .line 21
    move-object/from16 v15, p15

    .line 22
    .line 23
    move-object/from16 v16, p16

    .line 24
    .line 25
    move-object/from16 v17, p17

    .line 26
    .line 27
    move-object/from16 v18, p18

    .line 28
    .line 29
    move-object/from16 v19, p19

    .line 30
    .line 31
    move-object/from16 v20, p20

    .line 32
    .line 33
    move-object/from16 v21, p21

    .line 34
    .line 35
    move-wide/from16 v22, p22

    .line 36
    .line 37
    move-object/from16 v24, p24

    .line 38
    .line 39
    move-wide/from16 v25, p25

    .line 40
    .line 41
    move-object/from16 v27, p27

    .line 42
    .line 43
    move-object/from16 v28, p28

    .line 44
    .line 45
    move-object/from16 v29, p29

    .line 46
    .line 47
    move-wide/from16 v30, p30

    .line 48
    .line 49
    move-object/from16 v32, p32

    .line 50
    .line 51
    move-object/from16 v33, p33

    .line 52
    .line 53
    move/from16 v34, p34

    .line 54
    .line 55
    invoke-direct/range {v0 .. v34}, Lan/a;-><init>(JJJJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;DLan/b;Ljava/lang/String;Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;JLcom/xbet/onexuser/domain/betting/PlayersDuelModel;Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;I)V

    .line 56
    .line 57
    .line 58
    return-object v0
.end method

.method public final c()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->p:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final d()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->r:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final e()Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->y:Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;

    .line 2
    .line 3
    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lan/a;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lan/a;

    .line 12
    .line 13
    iget-wide v3, p0, Lan/a;->a:J

    .line 14
    .line 15
    iget-wide v5, p1, Lan/a;->a:J

    .line 16
    .line 17
    cmp-long v1, v3, v5

    .line 18
    .line 19
    if-eqz v1, :cond_2

    .line 20
    .line 21
    return v2

    .line 22
    :cond_2
    iget-wide v3, p0, Lan/a;->b:J

    .line 23
    .line 24
    iget-wide v5, p1, Lan/a;->b:J

    .line 25
    .line 26
    cmp-long v1, v3, v5

    .line 27
    .line 28
    if-eqz v1, :cond_3

    .line 29
    .line 30
    return v2

    .line 31
    :cond_3
    iget-wide v3, p0, Lan/a;->c:J

    .line 32
    .line 33
    iget-wide v5, p1, Lan/a;->c:J

    .line 34
    .line 35
    cmp-long v1, v3, v5

    .line 36
    .line 37
    if-eqz v1, :cond_4

    .line 38
    .line 39
    return v2

    .line 40
    :cond_4
    iget-wide v3, p0, Lan/a;->d:J

    .line 41
    .line 42
    iget-wide v5, p1, Lan/a;->d:J

    .line 43
    .line 44
    cmp-long v1, v3, v5

    .line 45
    .line 46
    if-eqz v1, :cond_5

    .line 47
    .line 48
    return v2

    .line 49
    :cond_5
    iget-wide v3, p0, Lan/a;->e:J

    .line 50
    .line 51
    iget-wide v5, p1, Lan/a;->e:J

    .line 52
    .line 53
    cmp-long v1, v3, v5

    .line 54
    .line 55
    if-eqz v1, :cond_6

    .line 56
    .line 57
    return v2

    .line 58
    :cond_6
    iget-object v1, p0, Lan/a;->f:Ljava/lang/String;

    .line 59
    .line 60
    iget-object v3, p1, Lan/a;->f:Ljava/lang/String;

    .line 61
    .line 62
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    if-nez v1, :cond_7

    .line 67
    .line 68
    return v2

    .line 69
    :cond_7
    iget-object v1, p0, Lan/a;->g:Ljava/lang/String;

    .line 70
    .line 71
    iget-object v3, p1, Lan/a;->g:Ljava/lang/String;

    .line 72
    .line 73
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    if-nez v1, :cond_8

    .line 78
    .line 79
    return v2

    .line 80
    :cond_8
    iget-object v1, p0, Lan/a;->h:Ljava/lang/String;

    .line 81
    .line 82
    iget-object v3, p1, Lan/a;->h:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    if-nez v1, :cond_9

    .line 89
    .line 90
    return v2

    .line 91
    :cond_9
    iget-object v1, p0, Lan/a;->i:Ljava/lang/String;

    .line 92
    .line 93
    iget-object v3, p1, Lan/a;->i:Ljava/lang/String;

    .line 94
    .line 95
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    if-nez v1, :cond_a

    .line 100
    .line 101
    return v2

    .line 102
    :cond_a
    iget-object v1, p0, Lan/a;->j:Ljava/lang/String;

    .line 103
    .line 104
    iget-object v3, p1, Lan/a;->j:Ljava/lang/String;

    .line 105
    .line 106
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v1

    .line 110
    if-nez v1, :cond_b

    .line 111
    .line 112
    return v2

    .line 113
    :cond_b
    iget-object v1, p0, Lan/a;->k:Ljava/lang/String;

    .line 114
    .line 115
    iget-object v3, p1, Lan/a;->k:Ljava/lang/String;

    .line 116
    .line 117
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    if-nez v1, :cond_c

    .line 122
    .line 123
    return v2

    .line 124
    :cond_c
    iget-object v1, p0, Lan/a;->l:Ljava/lang/String;

    .line 125
    .line 126
    iget-object v3, p1, Lan/a;->l:Ljava/lang/String;

    .line 127
    .line 128
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    move-result v1

    .line 132
    if-nez v1, :cond_d

    .line 133
    .line 134
    return v2

    .line 135
    :cond_d
    iget-object v1, p0, Lan/a;->m:Ljava/lang/String;

    .line 136
    .line 137
    iget-object v3, p1, Lan/a;->m:Ljava/lang/String;

    .line 138
    .line 139
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    move-result v1

    .line 143
    if-nez v1, :cond_e

    .line 144
    .line 145
    return v2

    .line 146
    :cond_e
    iget-object v1, p0, Lan/a;->n:Ljava/lang/String;

    .line 147
    .line 148
    iget-object v3, p1, Lan/a;->n:Ljava/lang/String;

    .line 149
    .line 150
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    move-result v1

    .line 154
    if-nez v1, :cond_f

    .line 155
    .line 156
    return v2

    .line 157
    :cond_f
    iget-object v1, p0, Lan/a;->o:Ljava/lang/String;

    .line 158
    .line 159
    iget-object v3, p1, Lan/a;->o:Ljava/lang/String;

    .line 160
    .line 161
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    move-result v1

    .line 165
    if-nez v1, :cond_10

    .line 166
    .line 167
    return v2

    .line 168
    :cond_10
    iget-object v1, p0, Lan/a;->p:Ljava/lang/String;

    .line 169
    .line 170
    iget-object v3, p1, Lan/a;->p:Ljava/lang/String;

    .line 171
    .line 172
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 173
    .line 174
    .line 175
    move-result v1

    .line 176
    if-nez v1, :cond_11

    .line 177
    .line 178
    return v2

    .line 179
    :cond_11
    iget-wide v3, p0, Lan/a;->q:J

    .line 180
    .line 181
    iget-wide v5, p1, Lan/a;->q:J

    .line 182
    .line 183
    cmp-long v1, v3, v5

    .line 184
    .line 185
    if-eqz v1, :cond_12

    .line 186
    .line 187
    return v2

    .line 188
    :cond_12
    iget-object v1, p0, Lan/a;->r:Ljava/lang/String;

    .line 189
    .line 190
    iget-object v3, p1, Lan/a;->r:Ljava/lang/String;

    .line 191
    .line 192
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    move-result v1

    .line 196
    if-nez v1, :cond_13

    .line 197
    .line 198
    return v2

    .line 199
    :cond_13
    iget-wide v3, p0, Lan/a;->s:D

    .line 200
    .line 201
    iget-wide v5, p1, Lan/a;->s:D

    .line 202
    .line 203
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I

    .line 204
    .line 205
    .line 206
    move-result v1

    .line 207
    if-eqz v1, :cond_14

    .line 208
    .line 209
    return v2

    .line 210
    :cond_14
    iget-object v1, p0, Lan/a;->t:Lan/b;

    .line 211
    .line 212
    iget-object v3, p1, Lan/a;->t:Lan/b;

    .line 213
    .line 214
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 215
    .line 216
    .line 217
    move-result v1

    .line 218
    if-nez v1, :cond_15

    .line 219
    .line 220
    return v2

    .line 221
    :cond_15
    iget-object v1, p0, Lan/a;->u:Ljava/lang/String;

    .line 222
    .line 223
    iget-object v3, p1, Lan/a;->u:Ljava/lang/String;

    .line 224
    .line 225
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 226
    .line 227
    .line 228
    move-result v1

    .line 229
    if-nez v1, :cond_16

    .line 230
    .line 231
    return v2

    .line 232
    :cond_16
    iget-object v1, p0, Lan/a;->v:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;

    .line 233
    .line 234
    iget-object v3, p1, Lan/a;->v:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;

    .line 235
    .line 236
    if-eq v1, v3, :cond_17

    .line 237
    .line 238
    return v2

    .line 239
    :cond_17
    iget-wide v3, p0, Lan/a;->w:J

    .line 240
    .line 241
    iget-wide v5, p1, Lan/a;->w:J

    .line 242
    .line 243
    cmp-long v1, v3, v5

    .line 244
    .line 245
    if-eqz v1, :cond_18

    .line 246
    .line 247
    return v2

    .line 248
    :cond_18
    iget-object v1, p0, Lan/a;->x:Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;

    .line 249
    .line 250
    iget-object v3, p1, Lan/a;->x:Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;

    .line 251
    .line 252
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 253
    .line 254
    .line 255
    move-result v1

    .line 256
    if-nez v1, :cond_19

    .line 257
    .line 258
    return v2

    .line 259
    :cond_19
    iget-object v1, p0, Lan/a;->y:Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;

    .line 260
    .line 261
    iget-object v3, p1, Lan/a;->y:Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;

    .line 262
    .line 263
    if-eq v1, v3, :cond_1a

    .line 264
    .line 265
    return v2

    .line 266
    :cond_1a
    iget v1, p0, Lan/a;->z:I

    .line 267
    .line 268
    iget p1, p1, Lan/a;->z:I

    .line 269
    .line 270
    if-eq v1, p1, :cond_1b

    .line 271
    .line 272
    return v2

    .line 273
    :cond_1b
    return v0
.end method

.method public final f()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lan/a;->q:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final g()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->h:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final h()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->j:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public hashCode()I
    .locals 3

    .line 1
    iget-wide v0, p0, Lan/a;->a:J

    .line 2
    .line 3
    invoke-static {v0, v1}, Lx/k;->a(J)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-wide v1, p0, Lan/a;->b:J

    .line 10
    .line 11
    invoke-static {v1, v2}, Lx/k;->a(J)I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v0, v1

    .line 16
    mul-int/lit8 v0, v0, 0x1f

    .line 17
    .line 18
    iget-wide v1, p0, Lan/a;->c:J

    .line 19
    .line 20
    invoke-static {v1, v2}, Lx/k;->a(J)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    add-int/2addr v0, v1

    .line 25
    mul-int/lit8 v0, v0, 0x1f

    .line 26
    .line 27
    iget-wide v1, p0, Lan/a;->d:J

    .line 28
    .line 29
    invoke-static {v1, v2}, Lx/k;->a(J)I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    add-int/2addr v0, v1

    .line 34
    mul-int/lit8 v0, v0, 0x1f

    .line 35
    .line 36
    iget-wide v1, p0, Lan/a;->e:J

    .line 37
    .line 38
    invoke-static {v1, v2}, Lx/k;->a(J)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    add-int/2addr v0, v1

    .line 43
    mul-int/lit8 v0, v0, 0x1f

    .line 44
    .line 45
    iget-object v1, p0, Lan/a;->f:Ljava/lang/String;

    .line 46
    .line 47
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    add-int/2addr v0, v1

    .line 52
    mul-int/lit8 v0, v0, 0x1f

    .line 53
    .line 54
    iget-object v1, p0, Lan/a;->g:Ljava/lang/String;

    .line 55
    .line 56
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    add-int/2addr v0, v1

    .line 61
    mul-int/lit8 v0, v0, 0x1f

    .line 62
    .line 63
    iget-object v1, p0, Lan/a;->h:Ljava/lang/String;

    .line 64
    .line 65
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    add-int/2addr v0, v1

    .line 70
    mul-int/lit8 v0, v0, 0x1f

    .line 71
    .line 72
    iget-object v1, p0, Lan/a;->i:Ljava/lang/String;

    .line 73
    .line 74
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    add-int/2addr v0, v1

    .line 79
    mul-int/lit8 v0, v0, 0x1f

    .line 80
    .line 81
    iget-object v1, p0, Lan/a;->j:Ljava/lang/String;

    .line 82
    .line 83
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    add-int/2addr v0, v1

    .line 88
    mul-int/lit8 v0, v0, 0x1f

    .line 89
    .line 90
    iget-object v1, p0, Lan/a;->k:Ljava/lang/String;

    .line 91
    .line 92
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 93
    .line 94
    .line 95
    move-result v1

    .line 96
    add-int/2addr v0, v1

    .line 97
    mul-int/lit8 v0, v0, 0x1f

    .line 98
    .line 99
    iget-object v1, p0, Lan/a;->l:Ljava/lang/String;

    .line 100
    .line 101
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 102
    .line 103
    .line 104
    move-result v1

    .line 105
    add-int/2addr v0, v1

    .line 106
    mul-int/lit8 v0, v0, 0x1f

    .line 107
    .line 108
    iget-object v1, p0, Lan/a;->m:Ljava/lang/String;

    .line 109
    .line 110
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    add-int/2addr v0, v1

    .line 115
    mul-int/lit8 v0, v0, 0x1f

    .line 116
    .line 117
    iget-object v1, p0, Lan/a;->n:Ljava/lang/String;

    .line 118
    .line 119
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 120
    .line 121
    .line 122
    move-result v1

    .line 123
    add-int/2addr v0, v1

    .line 124
    mul-int/lit8 v0, v0, 0x1f

    .line 125
    .line 126
    iget-object v1, p0, Lan/a;->o:Ljava/lang/String;

    .line 127
    .line 128
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 129
    .line 130
    .line 131
    move-result v1

    .line 132
    add-int/2addr v0, v1

    .line 133
    mul-int/lit8 v0, v0, 0x1f

    .line 134
    .line 135
    iget-object v1, p0, Lan/a;->p:Ljava/lang/String;

    .line 136
    .line 137
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 138
    .line 139
    .line 140
    move-result v1

    .line 141
    add-int/2addr v0, v1

    .line 142
    mul-int/lit8 v0, v0, 0x1f

    .line 143
    .line 144
    iget-wide v1, p0, Lan/a;->q:J

    .line 145
    .line 146
    invoke-static {v1, v2}, Lx/k;->a(J)I

    .line 147
    .line 148
    .line 149
    move-result v1

    .line 150
    add-int/2addr v0, v1

    .line 151
    mul-int/lit8 v0, v0, 0x1f

    .line 152
    .line 153
    iget-object v1, p0, Lan/a;->r:Ljava/lang/String;

    .line 154
    .line 155
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 156
    .line 157
    .line 158
    move-result v1

    .line 159
    add-int/2addr v0, v1

    .line 160
    mul-int/lit8 v0, v0, 0x1f

    .line 161
    .line 162
    iget-wide v1, p0, Lan/a;->s:D

    .line 163
    .line 164
    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/colorspace/F;->a(D)I

    .line 165
    .line 166
    .line 167
    move-result v1

    .line 168
    add-int/2addr v0, v1

    .line 169
    mul-int/lit8 v0, v0, 0x1f

    .line 170
    .line 171
    iget-object v1, p0, Lan/a;->t:Lan/b;

    .line 172
    .line 173
    invoke-virtual {v1}, Lan/b;->hashCode()I

    .line 174
    .line 175
    .line 176
    move-result v1

    .line 177
    add-int/2addr v0, v1

    .line 178
    mul-int/lit8 v0, v0, 0x1f

    .line 179
    .line 180
    iget-object v1, p0, Lan/a;->u:Ljava/lang/String;

    .line 181
    .line 182
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 183
    .line 184
    .line 185
    move-result v1

    .line 186
    add-int/2addr v0, v1

    .line 187
    mul-int/lit8 v0, v0, 0x1f

    .line 188
    .line 189
    iget-object v1, p0, Lan/a;->v:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;

    .line 190
    .line 191
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 192
    .line 193
    .line 194
    move-result v1

    .line 195
    add-int/2addr v0, v1

    .line 196
    mul-int/lit8 v0, v0, 0x1f

    .line 197
    .line 198
    iget-wide v1, p0, Lan/a;->w:J

    .line 199
    .line 200
    invoke-static {v1, v2}, Lx/k;->a(J)I

    .line 201
    .line 202
    .line 203
    move-result v1

    .line 204
    add-int/2addr v0, v1

    .line 205
    mul-int/lit8 v0, v0, 0x1f

    .line 206
    .line 207
    iget-object v1, p0, Lan/a;->x:Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;

    .line 208
    .line 209
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 210
    .line 211
    .line 212
    move-result v1

    .line 213
    add-int/2addr v0, v1

    .line 214
    mul-int/lit8 v0, v0, 0x1f

    .line 215
    .line 216
    iget-object v1, p0, Lan/a;->y:Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;

    .line 217
    .line 218
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 219
    .line 220
    .line 221
    move-result v1

    .line 222
    add-int/2addr v0, v1

    .line 223
    mul-int/lit8 v0, v0, 0x1f

    .line 224
    .line 225
    iget v1, p0, Lan/a;->z:I

    .line 226
    .line 227
    add-int/2addr v0, v1

    .line 228
    return v0
.end method

.method public final i()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->i:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final j()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lan/a;->b:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final k()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->g:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final l()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->o:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final m()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lan/a;->a:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final n()Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->v:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;

    .line 2
    .line 3
    return-object v0
.end method

.method public final o()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lan/a;->c:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final p()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->u:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final q()D
    .locals 2

    .line 1
    iget-wide v0, p0, Lan/a;->s:D

    .line 2
    .line 3
    return-wide v0
.end method

.method public final r()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lan/a;->d:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final s()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->f:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final t()Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->x:Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;

    .line 2
    .line 3
    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 36
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-wide v1, v0, Lan/a;->a:J

    .line 4
    .line 5
    iget-wide v3, v0, Lan/a;->b:J

    .line 6
    .line 7
    iget-wide v5, v0, Lan/a;->c:J

    .line 8
    .line 9
    iget-wide v7, v0, Lan/a;->d:J

    .line 10
    .line 11
    iget-wide v9, v0, Lan/a;->e:J

    .line 12
    .line 13
    iget-object v11, v0, Lan/a;->f:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v12, v0, Lan/a;->g:Ljava/lang/String;

    .line 16
    .line 17
    iget-object v13, v0, Lan/a;->h:Ljava/lang/String;

    .line 18
    .line 19
    iget-object v14, v0, Lan/a;->i:Ljava/lang/String;

    .line 20
    .line 21
    iget-object v15, v0, Lan/a;->j:Ljava/lang/String;

    .line 22
    .line 23
    move-object/from16 v16, v15

    .line 24
    .line 25
    iget-object v15, v0, Lan/a;->k:Ljava/lang/String;

    .line 26
    .line 27
    move-object/from16 v17, v15

    .line 28
    .line 29
    iget-object v15, v0, Lan/a;->l:Ljava/lang/String;

    .line 30
    .line 31
    move-object/from16 v18, v15

    .line 32
    .line 33
    iget-object v15, v0, Lan/a;->m:Ljava/lang/String;

    .line 34
    .line 35
    move-object/from16 v19, v15

    .line 36
    .line 37
    iget-object v15, v0, Lan/a;->n:Ljava/lang/String;

    .line 38
    .line 39
    move-object/from16 v20, v15

    .line 40
    .line 41
    iget-object v15, v0, Lan/a;->o:Ljava/lang/String;

    .line 42
    .line 43
    move-object/from16 v21, v15

    .line 44
    .line 45
    iget-object v15, v0, Lan/a;->p:Ljava/lang/String;

    .line 46
    .line 47
    move-object/from16 v22, v14

    .line 48
    .line 49
    move-object/from16 v23, v15

    .line 50
    .line 51
    iget-wide v14, v0, Lan/a;->q:J

    .line 52
    .line 53
    move-wide/from16 v24, v14

    .line 54
    .line 55
    iget-object v14, v0, Lan/a;->r:Ljava/lang/String;

    .line 56
    .line 57
    move-object/from16 v26, v14

    .line 58
    .line 59
    iget-wide v14, v0, Lan/a;->s:D

    .line 60
    .line 61
    move-wide/from16 v27, v14

    .line 62
    .line 63
    iget-object v14, v0, Lan/a;->t:Lan/b;

    .line 64
    .line 65
    iget-object v15, v0, Lan/a;->u:Ljava/lang/String;

    .line 66
    .line 67
    move-object/from16 v29, v15

    .line 68
    .line 69
    iget-object v15, v0, Lan/a;->v:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;

    .line 70
    .line 71
    move-object/from16 v30, v14

    .line 72
    .line 73
    move-object/from16 v31, v15

    .line 74
    .line 75
    iget-wide v14, v0, Lan/a;->w:J

    .line 76
    .line 77
    move-wide/from16 v32, v14

    .line 78
    .line 79
    iget-object v14, v0, Lan/a;->x:Lcom/xbet/onexuser/domain/betting/PlayersDuelModel;

    .line 80
    .line 81
    iget-object v15, v0, Lan/a;->y:Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;

    .line 82
    .line 83
    move-object/from16 v34, v15

    .line 84
    .line 85
    iget v15, v0, Lan/a;->z:I

    .line 86
    .line 87
    new-instance v0, Ljava/lang/StringBuilder;

    .line 88
    .line 89
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 90
    .line 91
    .line 92
    move/from16 v35, v15

    .line 93
    .line 94
    const-string v15, "BetEventEntityModel(id="

    .line 95
    .line 96
    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 100
    .line 101
    .line 102
    const-string v1, ", gameId="

    .line 103
    .line 104
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 105
    .line 106
    .line 107
    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 108
    .line 109
    .line 110
    const-string v1, ", mainGameId="

    .line 111
    .line 112
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 113
    .line 114
    .line 115
    invoke-virtual {v0, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 116
    .line 117
    .line 118
    const-string v1, ", playerId="

    .line 119
    .line 120
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 121
    .line 122
    .line 123
    invoke-virtual {v0, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 124
    .line 125
    .line 126
    const-string v1, ", sportId="

    .line 127
    .line 128
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 129
    .line 130
    .line 131
    invoke-virtual {v0, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    const-string v1, ", playerName="

    .line 135
    .line 136
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    .line 138
    .line 139
    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 140
    .line 141
    .line 142
    const-string v1, ", gameMatchName="

    .line 143
    .line 144
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 145
    .line 146
    .line 147
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 148
    .line 149
    .line 150
    const-string v1, ", firstOpponentFirstImg="

    .line 151
    .line 152
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 156
    .line 157
    .line 158
    const-string v1, ", firstOpponentSecondImg="

    .line 159
    .line 160
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 161
    .line 162
    .line 163
    move-object/from16 v1, v22

    .line 164
    .line 165
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    const-string v1, ", firstOpponentName="

    .line 169
    .line 170
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 171
    .line 172
    .line 173
    move-object/from16 v1, v16

    .line 174
    .line 175
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 176
    .line 177
    .line 178
    const-string v1, ", secondOpponentFirstImg="

    .line 179
    .line 180
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    move-object/from16 v1, v17

    .line 184
    .line 185
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    const-string v1, ", secondOpponentSecondImg="

    .line 189
    .line 190
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 191
    .line 192
    .line 193
    move-object/from16 v1, v18

    .line 194
    .line 195
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 196
    .line 197
    .line 198
    const-string v1, ", secondOpponentName="

    .line 199
    .line 200
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 201
    .line 202
    .line 203
    move-object/from16 v1, v19

    .line 204
    .line 205
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 206
    .line 207
    .line 208
    const-string v1, ", tournamentStage="

    .line 209
    .line 210
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 211
    .line 212
    .line 213
    move-object/from16 v1, v20

    .line 214
    .line 215
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 216
    .line 217
    .line 218
    const-string v1, ", groupName="

    .line 219
    .line 220
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 221
    .line 222
    .line 223
    move-object/from16 v1, v21

    .line 224
    .line 225
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 226
    .line 227
    .line 228
    const-string v1, ", champName="

    .line 229
    .line 230
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 231
    .line 232
    .line 233
    move-object/from16 v1, v23

    .line 234
    .line 235
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 236
    .line 237
    .line 238
    const-string v1, ", expressNumber="

    .line 239
    .line 240
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 241
    .line 242
    .line 243
    move-wide/from16 v1, v24

    .line 244
    .line 245
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 246
    .line 247
    .line 248
    const-string v1, ", coefficient="

    .line 249
    .line 250
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 251
    .line 252
    .line 253
    move-object/from16 v1, v26

    .line 254
    .line 255
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 256
    .line 257
    .line 258
    const-string v1, ", param="

    .line 259
    .line 260
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 261
    .line 262
    .line 263
    move-wide/from16 v1, v27

    .line 264
    .line 265
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 266
    .line 267
    .line 268
    const-string v1, ", subtitle="

    .line 269
    .line 270
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 271
    .line 272
    .line 273
    move-object/from16 v1, v30

    .line 274
    .line 275
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 276
    .line 277
    .line 278
    const-string v1, ", name="

    .line 279
    .line 280
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 281
    .line 282
    .line 283
    move-object/from16 v1, v29

    .line 284
    .line 285
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 286
    .line 287
    .line 288
    const-string v1, ", kind="

    .line 289
    .line 290
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 291
    .line 292
    .line 293
    move-object/from16 v1, v31

    .line 294
    .line 295
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 296
    .line 297
    .line 298
    const-string v1, ", type="

    .line 299
    .line 300
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 301
    .line 302
    .line 303
    move-wide/from16 v1, v32

    .line 304
    .line 305
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 306
    .line 307
    .line 308
    const-string v1, ", playersDuel="

    .line 309
    .line 310
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 311
    .line 312
    .line 313
    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 314
    .line 315
    .line 316
    const-string v1, ", couponEntryFeature="

    .line 317
    .line 318
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 319
    .line 320
    .line 321
    move-object/from16 v1, v34

    .line 322
    .line 323
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 324
    .line 325
    .line 326
    const-string v1, ", playersNumber="

    .line 327
    .line 328
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 329
    .line 330
    .line 331
    move/from16 v1, v35

    .line 332
    .line 333
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 334
    .line 335
    .line 336
    const-string v1, ")"

    .line 337
    .line 338
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 339
    .line 340
    .line 341
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 342
    .line 343
    .line 344
    move-result-object v0

    .line 345
    return-object v0
.end method

.method public final u()I
    .locals 1

    .line 1
    iget v0, p0, Lan/a;->z:I

    .line 2
    .line 3
    return v0
.end method

.method public final v()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->k:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final w()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->m:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final x()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->l:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final y()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lan/a;->e:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final z()Lan/b;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lan/a;->t:Lan/b;

    .line 2
    .line 3
    return-object v0
.end method
