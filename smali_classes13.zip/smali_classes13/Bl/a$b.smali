.class public final LBl/a$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LBl/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LBl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LBl/a$b$e;,
        LBl/a$b$a;,
        LBl/a$b$d;,
        LBl/a$b$b;,
        LBl/a$b$c;
    }
.end annotation


# instance fields
.field public A:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bethistory/powerbet/presentation/PowerbetViewModel;",
            ">;"
        }
    .end annotation
.end field

.field public final a:Ly11/a;

.field public final b:LZY0/k;

.field public final c:LBl/a$b;

.field public d:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LI8/a;",
            ">;"
        }
    .end annotation
.end field

.field public e:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LJ8/e;",
            ">;"
        }
    .end annotation
.end field

.field public f:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Ldv/t;",
            ">;"
        }
    .end annotation
.end field

.field public g:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Ldn/b;",
            ">;"
        }
    .end annotation
.end field

.field public h:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Ldn/a;",
            ">;"
        }
    .end annotation
.end field

.field public i:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LF7/a;",
            ">;"
        }
    .end annotation
.end field

.field public j:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lwn/b;",
            ">;"
        }
    .end annotation
.end field

.field public k:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bethistory/powerbet/domain/usecase/GetEventNameUseCase;",
            ">;"
        }
    .end annotation
.end field

.field public l:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bethistory/powerbet/domain/usecase/GetNewBetInfoScenario;",
            ">;"
        }
    .end annotation
.end field

.field public m:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/L;",
            ">;"
        }
    .end annotation
.end field

.field public n:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LWY0/c;",
            ">;"
        }
    .end annotation
.end field

.field public o:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/betting/core/make_bet/domain/usecases/MakeSimpleBetUseCase;",
            ">;"
        }
    .end annotation
.end field

.field public p:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lkt/c;",
            ">;"
        }
    .end annotation
.end field

.field public q:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/p;",
            ">;"
        }
    .end annotation
.end field

.field public r:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bethistory/powerbet/domain/usecase/PowerbetMakeBetScenario;",
            ">;"
        }
    .end annotation
.end field

.field public s:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public t:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LWY0/g;",
            ">;"
        }
    .end annotation
.end field

.field public u:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LuZ0/e;",
            ">;"
        }
    .end annotation
.end field

.field public v:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field public w:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LAl/a;",
            ">;"
        }
    .end annotation
.end field

.field public x:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LAl/b;",
            ">;"
        }
    .end annotation
.end field

.field public y:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bethistory/powerbet/domain/usecase/c;",
            ">;"
        }
    .end annotation
.end field

.field public z:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/internet/a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LtY0/c;Lht/a;Lcv/a;Lmj/a;Lpn/d;Ly11/a;Lw8/b;LI8/a;Ldn/b;Ldn/a;Lwn/b;Lorg/xbet/ui_core/utils/L;LWY0/c;Lorg/xbet/ui_core/utils/internet/a;LAl/a;Ljava/lang/String;LWY0/g;LuZ0/e;Ljava/lang/Long;LZY0/k;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p0, p0, LBl/a$b;->c:LBl/a$b;

    .line 5
    .line 6
    iput-object p6, p0, LBl/a$b;->a:Ly11/a;

    .line 7
    .line 8
    move-object/from16 v0, p20

    .line 9
    .line 10
    iput-object v0, p0, LBl/a$b;->b:LZY0/k;

    .line 11
    .line 12
    invoke-virtual/range {p0 .. p20}, LBl/a$b;->b(LtY0/c;Lht/a;Lcv/a;Lmj/a;Lpn/d;Ly11/a;Lw8/b;LI8/a;Ldn/b;Ldn/a;Lwn/b;Lorg/xbet/ui_core/utils/L;LWY0/c;Lorg/xbet/ui_core/utils/internet/a;LAl/a;Ljava/lang/String;LWY0/g;LuZ0/e;Ljava/lang/Long;LZY0/k;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public a(Lorg/xbet/bethistory/powerbet/presentation/PowerbetFragment;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, LBl/a$b;->c(Lorg/xbet/bethistory/powerbet/presentation/PowerbetFragment;)Lorg/xbet/bethistory/powerbet/presentation/PowerbetFragment;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final b(LtY0/c;Lht/a;Lcv/a;Lmj/a;Lpn/d;Ly11/a;Lw8/b;LI8/a;Ldn/b;Ldn/a;Lwn/b;Lorg/xbet/ui_core/utils/L;LWY0/c;Lorg/xbet/ui_core/utils/internet/a;LAl/a;Ljava/lang/String;LWY0/g;LuZ0/e;Ljava/lang/Long;LZY0/k;)V
    .locals 7

    .line 1
    invoke-static {p8}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, LBl/a$b;->d:Ldagger/internal/h;

    .line 6
    .line 7
    invoke-static {v0}, LJ8/f;->a(Ldagger/internal/h;)LJ8/f;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, LBl/a$b;->e:Ldagger/internal/h;

    .line 12
    .line 13
    new-instance v0, LBl/a$b$e;

    .line 14
    .line 15
    invoke-direct {v0, p3}, LBl/a$b$e;-><init>(Lcv/a;)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, LBl/a$b;->f:Ldagger/internal/h;

    .line 19
    .line 20
    invoke-static/range {p9 .. p9}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 21
    .line 22
    .line 23
    move-result-object p3

    .line 24
    iput-object p3, p0, LBl/a$b;->g:Ldagger/internal/h;

    .line 25
    .line 26
    invoke-static/range {p10 .. p10}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 27
    .line 28
    .line 29
    move-result-object p3

    .line 30
    iput-object p3, p0, LBl/a$b;->h:Ldagger/internal/h;

    .line 31
    .line 32
    new-instance p3, LBl/a$b$a;

    .line 33
    .line 34
    invoke-direct {p3, p1}, LBl/a$b$a;-><init>(LtY0/c;)V

    .line 35
    .line 36
    .line 37
    iput-object p3, p0, LBl/a$b;->i:Ldagger/internal/h;

    .line 38
    .line 39
    invoke-static/range {p11 .. p11}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    iput-object p1, p0, LBl/a$b;->j:Ldagger/internal/h;

    .line 44
    .line 45
    iget-object p3, p0, LBl/a$b;->g:Ldagger/internal/h;

    .line 46
    .line 47
    iget-object v0, p0, LBl/a$b;->h:Ldagger/internal/h;

    .line 48
    .line 49
    iget-object v1, p0, LBl/a$b;->i:Ldagger/internal/h;

    .line 50
    .line 51
    invoke-static {p3, v0, v1, p1}, Lorg/xbet/bethistory/powerbet/domain/usecase/a;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bethistory/powerbet/domain/usecase/a;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    iput-object p1, p0, LBl/a$b;->k:Ldagger/internal/h;

    .line 56
    .line 57
    iget-object p3, p0, LBl/a$b;->e:Ldagger/internal/h;

    .line 58
    .line 59
    iget-object v0, p0, LBl/a$b;->f:Ldagger/internal/h;

    .line 60
    .line 61
    invoke-static {p3, v0, p1}, Lorg/xbet/bethistory/powerbet/domain/usecase/b;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bethistory/powerbet/domain/usecase/b;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    iput-object p1, p0, LBl/a$b;->l:Ldagger/internal/h;

    .line 66
    .line 67
    invoke-static/range {p12 .. p12}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    iput-object p1, p0, LBl/a$b;->m:Ldagger/internal/h;

    .line 72
    .line 73
    invoke-static/range {p13 .. p13}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    iput-object p1, p0, LBl/a$b;->n:Ldagger/internal/h;

    .line 78
    .line 79
    new-instance p1, LBl/a$b$d;

    .line 80
    .line 81
    invoke-direct {p1, p5}, LBl/a$b$d;-><init>(Lpn/d;)V

    .line 82
    .line 83
    .line 84
    iput-object p1, p0, LBl/a$b;->o:Ldagger/internal/h;

    .line 85
    .line 86
    new-instance p1, LBl/a$b$b;

    .line 87
    .line 88
    invoke-direct {p1, p2}, LBl/a$b$b;-><init>(Lht/a;)V

    .line 89
    .line 90
    .line 91
    iput-object p1, p0, LBl/a$b;->p:Ldagger/internal/h;

    .line 92
    .line 93
    new-instance p1, LBl/a$b$c;

    .line 94
    .line 95
    invoke-direct {p1, p4}, LBl/a$b$c;-><init>(Lmj/a;)V

    .line 96
    .line 97
    .line 98
    iput-object p1, p0, LBl/a$b;->q:Ldagger/internal/h;

    .line 99
    .line 100
    iget-object p2, p0, LBl/a$b;->o:Ldagger/internal/h;

    .line 101
    .line 102
    iget-object p3, p0, LBl/a$b;->e:Ldagger/internal/h;

    .line 103
    .line 104
    iget-object p4, p0, LBl/a$b;->p:Ldagger/internal/h;

    .line 105
    .line 106
    invoke-static {p2, p3, p4, p1}, Lorg/xbet/bethistory/powerbet/domain/usecase/e;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bethistory/powerbet/domain/usecase/e;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    iput-object p1, p0, LBl/a$b;->r:Ldagger/internal/h;

    .line 111
    .line 112
    invoke-static/range {p16 .. p16}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    iput-object p1, p0, LBl/a$b;->s:Ldagger/internal/h;

    .line 117
    .line 118
    invoke-static/range {p17 .. p17}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    iput-object p1, p0, LBl/a$b;->t:Ldagger/internal/h;

    .line 123
    .line 124
    invoke-static/range {p18 .. p18}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    iput-object p1, p0, LBl/a$b;->u:Ldagger/internal/h;

    .line 129
    .line 130
    invoke-static/range {p19 .. p19}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 131
    .line 132
    .line 133
    move-result-object p1

    .line 134
    iput-object p1, p0, LBl/a$b;->v:Ldagger/internal/h;

    .line 135
    .line 136
    invoke-static/range {p15 .. p15}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 137
    .line 138
    .line 139
    move-result-object p1

    .line 140
    iput-object p1, p0, LBl/a$b;->w:Ldagger/internal/h;

    .line 141
    .line 142
    invoke-static {p1}, LAl/c;->a(Ldagger/internal/h;)LAl/c;

    .line 143
    .line 144
    .line 145
    move-result-object p1

    .line 146
    iput-object p1, p0, LBl/a$b;->x:Ldagger/internal/h;

    .line 147
    .line 148
    invoke-static {p1}, Lorg/xbet/bethistory/powerbet/domain/usecase/d;->a(Ldagger/internal/h;)Lorg/xbet/bethistory/powerbet/domain/usecase/d;

    .line 149
    .line 150
    .line 151
    move-result-object p1

    .line 152
    iput-object p1, p0, LBl/a$b;->y:Ldagger/internal/h;

    .line 153
    .line 154
    invoke-static/range {p14 .. p14}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 155
    .line 156
    .line 157
    move-result-object p1

    .line 158
    iput-object p1, p0, LBl/a$b;->z:Ldagger/internal/h;

    .line 159
    .line 160
    iget-object p2, p0, LBl/a$b;->l:Ldagger/internal/h;

    .line 161
    .line 162
    iget-object p3, p0, LBl/a$b;->m:Ldagger/internal/h;

    .line 163
    .line 164
    iget-object p4, p0, LBl/a$b;->n:Ldagger/internal/h;

    .line 165
    .line 166
    iget-object v0, p0, LBl/a$b;->i:Ldagger/internal/h;

    .line 167
    .line 168
    iget-object v1, p0, LBl/a$b;->r:Ldagger/internal/h;

    .line 169
    .line 170
    iget-object v2, p0, LBl/a$b;->s:Ldagger/internal/h;

    .line 171
    .line 172
    iget-object v3, p0, LBl/a$b;->t:Ldagger/internal/h;

    .line 173
    .line 174
    iget-object v4, p0, LBl/a$b;->u:Ldagger/internal/h;

    .line 175
    .line 176
    iget-object v5, p0, LBl/a$b;->v:Ldagger/internal/h;

    .line 177
    .line 178
    iget-object v6, p0, LBl/a$b;->y:Ldagger/internal/h;

    .line 179
    .line 180
    move-object/from16 p12, p1

    .line 181
    .line 182
    move-object p5, v0

    .line 183
    move-object p6, v1

    .line 184
    move-object p7, v2

    .line 185
    move-object p8, v3

    .line 186
    move-object/from16 p9, v4

    .line 187
    .line 188
    move-object/from16 p10, v5

    .line 189
    .line 190
    move-object/from16 p11, v6

    .line 191
    .line 192
    invoke-static/range {p2 .. p12}, Lorg/xbet/bethistory/powerbet/presentation/n;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bethistory/powerbet/presentation/n;

    .line 193
    .line 194
    .line 195
    move-result-object p1

    .line 196
    iput-object p1, p0, LBl/a$b;->A:Ldagger/internal/h;

    .line 197
    .line 198
    return-void
.end method

.method public final c(Lorg/xbet/bethistory/powerbet/presentation/PowerbetFragment;)Lorg/xbet/bethistory/powerbet/presentation/PowerbetFragment;
    .locals 1
    .annotation build Lcom/google/errorprone/annotations/CanIgnoreReturnValue;
    .end annotation

    .line 1
    invoke-virtual {p0}, LBl/a$b;->e()Lorg/xbet/ui_core/viewmodel/core/l;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p1, v0}, Lorg/xbet/bethistory/powerbet/presentation/e;->c(Lorg/xbet/bethistory/powerbet/presentation/PowerbetFragment;Lorg/xbet/ui_core/viewmodel/core/l;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LBl/a$b;->a:Ly11/a;

    .line 9
    .line 10
    invoke-static {p1, v0}, Lorg/xbet/bethistory/powerbet/presentation/e;->a(Lorg/xbet/bethistory/powerbet/presentation/PowerbetFragment;Ly11/a;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, LBl/a$b;->b:LZY0/k;

    .line 14
    .line 15
    invoke-static {p1, v0}, Lorg/xbet/bethistory/powerbet/presentation/e;->b(Lorg/xbet/bethistory/powerbet/presentation/PowerbetFragment;LZY0/k;)V

    .line 16
    .line 17
    .line 18
    return-object p1
.end method

.method public d()Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "+",
            "Landroidx/lifecycle/f0;",
            ">;",
            "Lib/a<",
            "Landroidx/lifecycle/f0;",
            ">;>;"
        }
    .end annotation

    .line 1
    const-class v0, Lorg/xbet/bethistory/powerbet/presentation/PowerbetViewModel;

    .line 2
    .line 3
    iget-object v1, p0, LBl/a$b;->A:Ldagger/internal/h;

    .line 4
    .line 5
    invoke-static {v0, v1}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public e()Lorg/xbet/ui_core/viewmodel/core/l;
    .locals 2

    .line 1
    new-instance v0, Lorg/xbet/ui_core/viewmodel/core/l;

    .line 2
    .line 3
    invoke-virtual {p0}, LBl/a$b;->d()Ljava/util/Map;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, Lorg/xbet/ui_core/viewmodel/core/l;-><init>(Ljava/util/Map;)V

    .line 8
    .line 9
    .line 10
    return-object v0
.end method
