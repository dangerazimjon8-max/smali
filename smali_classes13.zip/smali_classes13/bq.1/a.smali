.class public final Lbq/a;
.super Landroid/view/animation/Animation;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lbq/a$a;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0008\n\u0002\u0008\u0004\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0010\u000b\n\u0002\u0008\u0005\u0008\u0000\u0018\u0000 %2\u00020\u0001:\u0001\u0015B\u001b\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u00a2\u0006\u0004\u0008\u0005\u0010\u0006J/\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0008\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u0007H\u0016\u00a2\u0006\u0004\u0008\r\u0010\u000eJ\u001f\u0010\u0013\u001a\u00020\u000c2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u0011H\u0014\u00a2\u0006\u0004\u0008\u0013\u0010\u0014R\u0018\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u0015\u0010\u0016R\u0018\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u0017\u0010\u0016R\u0018\u0010\u001b\u001a\u0004\u0018\u00010\u00188\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u0019\u0010\u001aR\u0016\u0010\u001e\u001a\u00020\u000f8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u001c\u0010\u001dR\u0016\u0010 \u001a\u00020\u000f8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u001f\u0010\u001dR\u0016\u0010$\u001a\u00020!8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\"\u0010#\u00a8\u0006&"
    }
    d2 = {
        "Lbq/a;",
        "Landroid/view/animation/Animation;",
        "Landroid/view/View;",
        "fromView",
        "toView",
        "<init>",
        "(Landroid/view/View;Landroid/view/View;)V",
        "",
        "width",
        "height",
        "parentWidth",
        "parentHeight",
        "",
        "initialize",
        "(IIII)V",
        "",
        "interpolatedTime",
        "Landroid/view/animation/Transformation;",
        "t",
        "applyTransformation",
        "(FLandroid/view/animation/Transformation;)V",
        "a",
        "Landroid/view/View;",
        "b",
        "Landroid/graphics/Camera;",
        "c",
        "Landroid/graphics/Camera;",
        "camera",
        "d",
        "F",
        "centerX",
        "e",
        "centerY",
        "",
        "f",
        "Z",
        "forward",
        "g",
        "impl_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final g:Lbq/a$a;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# instance fields
.field public a:Landroid/view/View;

.field public b:Landroid/view/View;

.field public c:Landroid/graphics/Camera;

.field public d:F

.field public e:F

.field public f:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lbq/a$a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lbq/a$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lbq/a;->g:Lbq/a$a;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Landroid/view/View;Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/view/animation/Animation;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbq/a;->a:Landroid/view/View;

    .line 5
    .line 6
    iput-object p2, p0, Lbq/a;->b:Landroid/view/View;

    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    iput-boolean p1, p0, Lbq/a;->f:Z

    .line 10
    .line 11
    const-wide/16 p1, 0x1f4

    .line 12
    .line 13
    invoke-virtual {p0, p1, p2}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 14
    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    invoke-virtual {p0, p1}, Landroid/view/animation/Animation;->setFillAfter(Z)V

    .line 18
    .line 19
    .line 20
    new-instance p1, Landroid/view/animation/AccelerateDecelerateInterpolator;

    .line 21
    .line 22
    invoke-direct {p1}, Landroid/view/animation/AccelerateDecelerateInterpolator;-><init>()V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p0, p1}, Landroid/view/animation/Animation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 26
    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public applyTransformation(FLandroid/view/animation/Transformation;)V
    .locals 7
    .param p2    # Landroid/view/animation/Transformation;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    float-to-double v0, p1

    .line 2
    const-wide v2, 0x400921fb54442d18L    # Math.PI

    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    mul-double v0, v0, v2

    .line 8
    .line 9
    const/high16 v4, 0x43340000    # 180.0f

    .line 10
    .line 11
    float-to-double v5, v4

    .line 12
    mul-double v5, v5, v0

    .line 13
    .line 14
    div-double/2addr v5, v2

    .line 15
    double-to-float v0, v5

    .line 16
    const/high16 v1, 0x3f000000    # 0.5f

    .line 17
    .line 18
    cmpl-float p1, p1, v1

    .line 19
    .line 20
    if-ltz p1, :cond_1

    .line 21
    .line 22
    sub-float/2addr v0, v4

    .line 23
    iget-object p1, p0, Lbq/a;->a:Landroid/view/View;

    .line 24
    .line 25
    if-eqz p1, :cond_0

    .line 26
    .line 27
    const/4 v1, 0x4

    .line 28
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 29
    .line 30
    .line 31
    :cond_0
    iget-object p1, p0, Lbq/a;->b:Landroid/view/View;

    .line 32
    .line 33
    if-eqz p1, :cond_1

    .line 34
    .line 35
    const/4 v1, 0x0

    .line 36
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 37
    .line 38
    .line 39
    :cond_1
    iget-boolean p1, p0, Lbq/a;->f:Z

    .line 40
    .line 41
    if-eqz p1, :cond_2

    .line 42
    .line 43
    neg-float v0, v0

    .line 44
    :cond_2
    invoke-virtual {p2}, Landroid/view/animation/Transformation;->getMatrix()Landroid/graphics/Matrix;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    iget-object p2, p0, Lbq/a;->c:Landroid/graphics/Camera;

    .line 49
    .line 50
    if-eqz p2, :cond_3

    .line 51
    .line 52
    invoke-virtual {p2}, Landroid/graphics/Camera;->save()V

    .line 53
    .line 54
    .line 55
    :cond_3
    iget-object p2, p0, Lbq/a;->c:Landroid/graphics/Camera;

    .line 56
    .line 57
    if-eqz p2, :cond_4

    .line 58
    .line 59
    invoke-virtual {p2, v0}, Landroid/graphics/Camera;->rotateY(F)V

    .line 60
    .line 61
    .line 62
    :cond_4
    iget-object p2, p0, Lbq/a;->c:Landroid/graphics/Camera;

    .line 63
    .line 64
    if-eqz p2, :cond_5

    .line 65
    .line 66
    invoke-virtual {p2, p1}, Landroid/graphics/Camera;->getMatrix(Landroid/graphics/Matrix;)V

    .line 67
    .line 68
    .line 69
    :cond_5
    iget-object p2, p0, Lbq/a;->c:Landroid/graphics/Camera;

    .line 70
    .line 71
    if-eqz p2, :cond_6

    .line 72
    .line 73
    invoke-virtual {p2}, Landroid/graphics/Camera;->restore()V

    .line 74
    .line 75
    .line 76
    :cond_6
    iget p2, p0, Lbq/a;->d:F

    .line 77
    .line 78
    neg-float p2, p2

    .line 79
    iget v0, p0, Lbq/a;->e:F

    .line 80
    .line 81
    neg-float v0, v0

    .line 82
    invoke-virtual {p1, p2, v0}, Landroid/graphics/Matrix;->preTranslate(FF)Z

    .line 83
    .line 84
    .line 85
    iget p2, p0, Lbq/a;->d:F

    .line 86
    .line 87
    iget v0, p0, Lbq/a;->e:F

    .line 88
    .line 89
    invoke-virtual {p1, p2, v0}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 90
    .line 91
    .line 92
    return-void
.end method

.method public initialize(IIII)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/animation/Animation;->initialize(IIII)V

    .line 2
    .line 3
    .line 4
    div-int/lit8 p1, p1, 0x2

    .line 5
    .line 6
    int-to-float p1, p1

    .line 7
    iput p1, p0, Lbq/a;->d:F

    .line 8
    .line 9
    div-int/lit8 p2, p2, 0x2

    .line 10
    .line 11
    int-to-float p1, p2

    .line 12
    iput p1, p0, Lbq/a;->e:F

    .line 13
    .line 14
    new-instance p1, Landroid/graphics/Camera;

    .line 15
    .line 16
    invoke-direct {p1}, Landroid/graphics/Camera;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, Lbq/a;->c:Landroid/graphics/Camera;

    .line 20
    .line 21
    return-void
.end method
