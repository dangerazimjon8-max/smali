.class public final Lbp/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0004\n\u0002\u0010\u000e\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\t\u001ao\u0010\u0012\u001a\u00020\u0011*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u000c\u0010\u0005\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u00032\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\u000c\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u0012\u0010\u0013\u001a\u0013\u0010\u0015\u001a\u00020\u0014*\u00020\u0000H\u0002\u00a2\u0006\u0004\u0008\u0015\u0010\u0016\u001a\u0013\u0010\u0018\u001a\u00020\u0017*\u00020\u0000H\u0002\u00a2\u0006\u0004\u0008\u0018\u0010\u0019\u001a\u001d\u0010\u001d\u001a\u00020\u001c2\u000c\u0010\u001b\u001a\u0008\u0012\u0004\u0012\u00020\u001a0\u0003H\u0002\u00a2\u0006\u0004\u0008\u001d\u0010\u001e\u001a\u001b\u0010!\u001a\u00020\u000b*\u00020\u00002\u0006\u0010 \u001a\u00020\u001fH\u0002\u00a2\u0006\u0004\u0008!\u0010\"\u001a\u0017\u0010$\u001a\u00020\u000b2\u0006\u0010#\u001a\u00020\u000bH\u0002\u00a2\u0006\u0004\u0008$\u0010%\u001a\u0013\u0010&\u001a\u00020\u0006*\u00020\u0000H\u0002\u00a2\u0006\u0004\u0008&\u0010\'\u00a8\u0006("
    }
    d2 = {
        "LQn/k;",
        "LmZ0/f;",
        "resourceManager",
        "",
        "",
        "specialEventList",
        "",
        "bettingDisabled",
        "hasStream",
        "hasZone",
        "betGroupMultiline",
        "",
        "champImage",
        "betGroupBlocked",
        "addAnyInfo",
        "customSportIcon",
        "topIcon",
        "Lbp/a;",
        "f",
        "(LQn/k;LmZ0/f;Ljava/util/List;ZZZZLjava/lang/String;ZZZZ)Lbp/a;",
        "Lbp/a$a$d;",
        "e",
        "(LQn/k;)Lbp/a$a$d;",
        "Lbp/a$a$g;",
        "g",
        "(LQn/k;)Lbp/a$a$g;",
        "LQn/a;",
        "dealerCards",
        "Lbp/a$a$c;",
        "b",
        "(Ljava/util/List;)Ljava/util/List;",
        "Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;",
        "key",
        "c",
        "(LQn/k;Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;)Ljava/lang/String;",
        "combination",
        "a",
        "(Ljava/lang/String;)Ljava/lang/String;",
        "d",
        "(LQn/k;)Z",
        "event_card_release"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final a(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/16 v1, 0xd

    .line 6
    .line 7
    if-le v0, v1, :cond_0

    .line 8
    .line 9
    invoke-static {p0, v1}, Lkotlin/text/C;->a2(Ljava/lang/String;I)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    new-instance v0, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    const-string p0, "..."

    .line 22
    .line 23
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    :cond_0
    return-object p0
.end method

.method public static final b(Ljava/util/List;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LQn/a;",
            ">;)",
            "Ljava/util/List<",
            "+",
            "Ly31/K;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    const/16 v1, 0xa

    .line 4
    .line 5
    invoke-static {p0, v1}, Lkotlin/collections/x;->z(Ljava/lang/Iterable;I)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 10
    .line 11
    .line 12
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, LQn/a;

    .line 27
    .line 28
    invoke-static {v1}, LMo/a;->e(LQn/a;)Ly31/K;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    if-eqz p0, :cond_1

    .line 41
    .line 42
    sget-object p0, Ly31/K$a;->b:Ly31/K$a;

    .line 43
    .line 44
    invoke-static {p0}, Lkotlin/collections/v;->e(Ljava/lang/Object;)Ljava/util/List;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    :cond_1
    invoke-static {v0}, Lbp/a$a$c;->b(Ljava/util/List;)Ljava/util/List;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0
.end method

.method public static final c(LQn/k;Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;)Ljava/lang/String;
    .locals 3

    .line 1
    invoke-virtual {p0}, LQn/k;->x()LQn/i;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, LQn/i;->b()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    const/4 v1, 0x0

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    move-object v2, v0

    .line 25
    check-cast v2, LQn/f;

    .line 26
    .line 27
    invoke-virtual {v2}, LQn/f;->a()Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    if-ne v2, p1, :cond_0

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    move-object v0, v1

    .line 35
    :goto_0
    check-cast v0, LQn/f;

    .line 36
    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    invoke-virtual {v0}, LQn/f;->b()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    :cond_2
    if-nez v1, :cond_3

    .line 44
    .line 45
    const-string v1, ""

    .line 46
    .line 47
    :cond_3
    const-string p0, "\""

    .line 48
    .line 49
    invoke-static {v1, p0}, Lkotlin/text/StringsKt;->d1(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    return-object p0
.end method

.method public static final d(LQn/k;)Z
    .locals 1

    .line 1
    invoke-virtual {p0}, LQn/k;->t()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-static {p0}, LJn/c;->y(LQn/k;)Z

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0

    .line 12
    :cond_0
    invoke-static {p0}, LJn/c;->t(LQn/k;)Z

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    return p0
.end method

.method public static final e(LQn/k;)Lbp/a$a$d;
    .locals 4

    .line 1
    sget-object v0, Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;->FIRST_TEAM_CARDS:Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 2
    .line 3
    invoke-static {p0, v0}, Lbp/b;->c(LQn/k;Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sget-object v1, Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;->FIRST_TEAM_COMBINATION:Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 8
    .line 9
    invoke-static {p0, v1}, Lbp/b;->c(LQn/k;Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-static {p0}, LJn/c;->e(LQn/k;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    invoke-static {v0}, LOo/a;->a(Ljava/lang/String;)Ljava/util/List;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v2, 0x3

    .line 22
    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->q1(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    new-instance v2, Ljava/util/ArrayList;

    .line 27
    .line 28
    const/16 v3, 0xa

    .line 29
    .line 30
    invoke-static {v0, v3}, Lkotlin/collections/x;->z(Ljava/lang/Iterable;I)I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 35
    .line 36
    .line 37
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    if-eqz v3, :cond_0

    .line 46
    .line 47
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    check-cast v3, LQn/a;

    .line 52
    .line 53
    invoke-static {v3}, LMo/a;->e(LQn/a;)Ly31/K;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-interface {v2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_0
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-eqz v0, :cond_1

    .line 66
    .line 67
    sget-object v0, Ly31/K$a;->b:Ly31/K$a;

    .line 68
    .line 69
    invoke-static {v0}, Lkotlin/collections/v;->e(Ljava/lang/Object;)Ljava/util/List;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    :cond_1
    invoke-static {v1}, Lbp/b;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    new-instance v1, Lbp/a$a$d;

    .line 78
    .line 79
    invoke-direct {v1, p0, v2, v0}, Lbp/a$a$d;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    return-object v1
.end method

.method public static final f(LQn/k;LmZ0/f;Ljava/util/List;ZZZZLjava/lang/String;ZZZZ)Lbp/a;
    .locals 28
    .param p0    # LQn/k;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p1    # LmZ0/f;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p7    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LQn/k;",
            "LmZ0/f;",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;ZZZZ",
            "Ljava/lang/String;",
            "ZZZZ)",
            "Lbp/a;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    sget-object v1, Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;->BOARD_CARDS:Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 4
    .line 5
    invoke-static {v0, v1}, Lbp/b;->c(LQn/k;Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-static {v1}, LOo/a;->a(Ljava/lang/String;)Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object v10

    .line 13
    invoke-static {v0}, Lbp/b;->d(LQn/k;)Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    const/4 v11, 0x0

    .line 18
    const/4 v12, 0x1

    .line 19
    if-eqz v1, :cond_0

    .line 20
    .line 21
    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_0

    .line 26
    .line 27
    const/4 v13, 0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    const/4 v13, 0x0

    .line 30
    :goto_0
    new-instance v14, Lbp/a;

    .line 31
    .line 32
    invoke-virtual {v0}, LQn/k;->q()J

    .line 33
    .line 34
    .line 35
    move-result-wide v15

    .line 36
    const/4 v7, 0x0

    .line 37
    move-object/from16 v6, p2

    .line 38
    .line 39
    move/from16 v1, p3

    .line 40
    .line 41
    move/from16 v2, p4

    .line 42
    .line 43
    move/from16 v3, p5

    .line 44
    .line 45
    move-object/from16 v4, p7

    .line 46
    .line 47
    move/from16 v5, p9

    .line 48
    .line 49
    move/from16 v8, p10

    .line 50
    .line 51
    move/from16 v9, p11

    .line 52
    .line 53
    invoke-static/range {v0 .. v9}, LRo/c;->c(LQn/k;ZZZLjava/lang/String;ZLjava/util/List;LVY0/e;ZZ)LRo/a;

    .line 54
    .line 55
    .line 56
    move-result-object v17

    .line 57
    const/16 v7, 0x3c

    .line 58
    .line 59
    const/4 v8, 0x0

    .line 60
    const/4 v3, 0x0

    .line 61
    const/4 v4, 0x0

    .line 62
    const/4 v5, 0x0

    .line 63
    const/4 v6, 0x0

    .line 64
    move-object/from16 v0, p0

    .line 65
    .line 66
    move/from16 v1, p6

    .line 67
    .line 68
    move/from16 v2, p8

    .line 69
    .line 70
    invoke-static/range {v0 .. v8}, LPo/f;->c(LQn/k;ZZIZZZILjava/lang/Object;)LPo/e;

    .line 71
    .line 72
    .line 73
    move-result-object v18

    .line 74
    sget v1, LjY0/J;->number_of_round_dice:I

    .line 75
    .line 76
    invoke-virtual {v0}, LQn/k;->c()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    new-array v3, v12, [Ljava/lang/Object;

    .line 81
    .line 82
    aput-object v2, v3, v11

    .line 83
    .line 84
    move-object/from16 v2, p1

    .line 85
    .line 86
    invoke-interface {v2, v1, v3}, LmZ0/f;->a(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    invoke-static {v1}, Lbp/a$a$e;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v19

    .line 94
    if-eqz v13, :cond_1

    .line 95
    .line 96
    sget-object v1, Lorg/xbet/uikit_sport/score/a$b;->b:Lorg/xbet/uikit_sport/score/a$b;

    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_1
    invoke-static {v0}, LVo/a;->a(LQn/k;)Lorg/xbet/uikit_sport/score/a;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    :goto_1
    invoke-static {v1}, Lbp/a$a$f;->b(Lorg/xbet/uikit_sport/score/a;)Lorg/xbet/uikit_sport/score/a;

    .line 104
    .line 105
    .line 106
    move-result-object v20

    .line 107
    invoke-static {v0}, Lbp/b;->e(LQn/k;)Lbp/a$a$d;

    .line 108
    .line 109
    .line 110
    move-result-object v21

    .line 111
    invoke-static {v0}, Lbp/b;->g(LQn/k;)Lbp/a$a$g;

    .line 112
    .line 113
    .line 114
    move-result-object v22

    .line 115
    invoke-static {v10}, Lbp/b;->b(Ljava/util/List;)Ljava/util/List;

    .line 116
    .line 117
    .line 118
    move-result-object v23

    .line 119
    sget-object v1, Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;->CURRENT_GAME_STATE:Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 120
    .line 121
    invoke-static {v0, v1}, Lbp/b;->c(LQn/k;Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    invoke-static {v1}, Lbp/a$a$a;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v24

    .line 129
    new-instance v1, Lno/c;

    .line 130
    .line 131
    invoke-virtual {v0}, LQn/k;->t()Z

    .line 132
    .line 133
    .line 134
    move-result v2

    .line 135
    if-eqz v2, :cond_2

    .line 136
    .line 137
    invoke-virtual {v0}, LQn/k;->x()LQn/i;

    .line 138
    .line 139
    .line 140
    move-result-object v2

    .line 141
    invoke-virtual {v2}, LQn/i;->r()J

    .line 142
    .line 143
    .line 144
    move-result-wide v2

    .line 145
    goto :goto_2

    .line 146
    :cond_2
    invoke-virtual {v0}, LQn/k;->O()J

    .line 147
    .line 148
    .line 149
    move-result-wide v2

    .line 150
    :goto_2
    invoke-virtual {v0}, LQn/k;->w()Ljava/util/Date;

    .line 151
    .line 152
    .line 153
    move-result-object v4

    .line 154
    invoke-virtual {v4}, Ljava/util/Date;->getTime()J

    .line 155
    .line 156
    .line 157
    move-result-wide v4

    .line 158
    const/4 v6, 0x1

    .line 159
    move-object/from16 p1, v1

    .line 160
    .line 161
    move-wide/from16 p4, v2

    .line 162
    .line 163
    move-wide/from16 p6, v4

    .line 164
    .line 165
    move/from16 p2, v13

    .line 166
    .line 167
    const/16 p3, 0x1

    .line 168
    .line 169
    invoke-direct/range {p1 .. p7}, Lno/c;-><init>(ZZJJ)V

    .line 170
    .line 171
    .line 172
    move/from16 v11, p2

    .line 173
    .line 174
    invoke-static {v1}, Lbp/a$a$h;->b(Lno/c;)Lno/c;

    .line 175
    .line 176
    .line 177
    move-result-object v25

    .line 178
    if-eqz v11, :cond_3

    .line 179
    .line 180
    invoke-virtual {v0}, LQn/k;->x()LQn/i;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    invoke-virtual {v0}, LQn/i;->c()Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    goto :goto_3

    .line 189
    :cond_3
    const-string v0, ""

    .line 190
    .line 191
    :goto_3
    invoke-static {v0}, Lbp/a$a$b;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v26

    .line 195
    const/16 v27, 0x0

    .line 196
    .line 197
    invoke-direct/range {v14 .. v27}, Lbp/a;-><init>(JLRo/a;LPo/e;Ljava/lang/String;Lorg/xbet/uikit_sport/score/a;Lbp/a$a$d;Lbp/a$a$g;Ljava/util/List;Ljava/lang/String;Lno/c;Ljava/lang/String;Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 198
    .line 199
    .line 200
    return-object v14
.end method

.method public static final g(LQn/k;)Lbp/a$a$g;
    .locals 4

    .line 1
    sget-object v0, Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;->SECOND_TEAM_CARDS:Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 2
    .line 3
    invoke-static {p0, v0}, Lbp/b;->c(LQn/k;Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sget-object v1, Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;->SECOND_TEAM_COMBINATION:Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;

    .line 8
    .line 9
    invoke-static {p0, v1}, Lbp/b;->c(LQn/k;Lorg/xbet/betting/core/zip/model/zip/game/GameAddTimeKey;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-static {p0}, LJn/c;->o(LQn/k;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    invoke-static {v0}, LOo/a;->a(Ljava/lang/String;)Ljava/util/List;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v2, 0x3

    .line 22
    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->q1(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    new-instance v2, Ljava/util/ArrayList;

    .line 27
    .line 28
    const/16 v3, 0xa

    .line 29
    .line 30
    invoke-static {v0, v3}, Lkotlin/collections/x;->z(Ljava/lang/Iterable;I)I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 35
    .line 36
    .line 37
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    if-eqz v3, :cond_0

    .line 46
    .line 47
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    check-cast v3, LQn/a;

    .line 52
    .line 53
    invoke-static {v3}, LMo/a;->e(LQn/a;)Ly31/K;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-interface {v2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_0
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-eqz v0, :cond_1

    .line 66
    .line 67
    sget-object v0, Ly31/K$a;->b:Ly31/K$a;

    .line 68
    .line 69
    invoke-static {v0}, Lkotlin/collections/v;->e(Ljava/lang/Object;)Ljava/util/List;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    :cond_1
    invoke-static {v1}, Lbp/b;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    new-instance v1, Lbp/a$a$g;

    .line 78
    .line 79
    invoke-direct {v1, p0, v2, v0}, Lbp/a$a$g;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    return-object v1
.end method
