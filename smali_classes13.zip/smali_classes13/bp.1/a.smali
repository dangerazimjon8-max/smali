.class public final Lbp/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LLo/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lbp/a$a;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0084\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008&\u0008\u0086\u0008\u0018\u00002\u00020\u0001:\u0001.B_\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\u0008\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u0006\u0010\r\u001a\u00020\u000c\u0012\u0006\u0010\u000f\u001a\u00020\u000e\u0012\u0006\u0010\u0011\u001a\u00020\u0010\u0012\u0006\u0010\u0013\u001a\u00020\u0012\u0012\u0006\u0010\u0015\u001a\u00020\u0014\u0012\u0006\u0010\u0017\u001a\u00020\u0016\u00a2\u0006\u0004\u0008\u0018\u0010\u0019J-\u0010!\u001a\u00020 2\u000c\u0010\u001c\u001a\u0008\u0012\u0004\u0012\u00020\u001b0\u001a2\u0006\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001f\u001a\u00020\u001dH\u0016\u00a2\u0006\u0004\u0008!\u0010\"J\u0010\u0010$\u001a\u00020#H\u00d6\u0001\u00a2\u0006\u0004\u0008$\u0010%J\u0010\u0010\'\u001a\u00020&H\u00d6\u0001\u00a2\u0006\u0004\u0008\'\u0010(J\u001a\u0010,\u001a\u00020+2\u0008\u0010*\u001a\u0004\u0018\u00010)H\u00d6\u0003\u00a2\u0006\u0004\u0008,\u0010-R\u001a\u0010\u0003\u001a\u00020\u00028\u0016X\u0096\u0004\u00a2\u0006\u000c\n\u0004\u0008.\u0010/\u001a\u0004\u00080\u00101R\u001a\u0010\u0005\u001a\u00020\u00048\u0016X\u0096\u0004\u00a2\u0006\u000c\n\u0004\u00080\u00102\u001a\u0004\u00083\u00104R\u001a\u0010\u0007\u001a\u00020\u00068\u0016X\u0096\u0004\u00a2\u0006\u000c\n\u0004\u00085\u00106\u001a\u0004\u00087\u00108R\u0017\u0010\t\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u00089\u0010:\u001a\u0004\u0008;\u0010%R\u0017\u0010\u000b\u001a\u00020\n8\u0006\u00a2\u0006\u000c\n\u0004\u0008<\u0010=\u001a\u0004\u0008>\u0010?R\u0017\u0010\r\u001a\u00020\u000c8\u0006\u00a2\u0006\u000c\n\u0004\u0008@\u0010A\u001a\u0004\u0008B\u0010CR\u0017\u0010\u000f\u001a\u00020\u000e8\u0006\u00a2\u0006\u000c\n\u0004\u0008D\u0010E\u001a\u0004\u0008F\u0010GR\u0017\u0010\u0011\u001a\u00020\u00108\u0006\u00a2\u0006\u000c\n\u0004\u0008H\u0010I\u001a\u0004\u0008J\u0010KR\u0017\u0010\u0013\u001a\u00020\u00128\u0006\u00a2\u0006\u000c\n\u0004\u0008L\u0010:\u001a\u0004\u0008<\u0010%R\u0017\u0010\u0015\u001a\u00020\u00148\u0006\u00a2\u0006\u000c\n\u0004\u0008!\u0010M\u001a\u0004\u0008N\u0010OR\u0017\u0010\u0017\u001a\u00020\u00168\u0006\u00a2\u0006\u000c\n\u0004\u0008P\u0010:\u001a\u0004\u0008@\u0010%\u00a8\u0006Q"
    }
    d2 = {
        "Lbp/a;",
        "LLo/c;",
        "",
        "gameId",
        "LRo/a;",
        "header",
        "LPo/e;",
        "footer",
        "Lbp/a$a$e;",
        "information",
        "Lbp/a$a$f;",
        "score",
        "Lbp/a$a$d;",
        "firstTeam",
        "Lbp/a$a$g;",
        "secondTeam",
        "Lbp/a$a$c;",
        "dealearCards",
        "Lbp/a$a$a;",
        "bottomInfo",
        "Lbp/a$a$h;",
        "timer",
        "Lbp/a$a$b;",
        "caption",
        "<init>",
        "(JLRo/a;LPo/e;Ljava/lang/String;Lorg/xbet/uikit_sport/score/a;Lbp/a$a$d;Lbp/a$a$g;Ljava/util/List;Ljava/lang/String;Lno/c;Ljava/lang/String;Lkotlin/jvm/internal/DefaultConstructorMarker;)V",
        "",
        "LLo/a;",
        "payloads",
        "LxZ0/i;",
        "oldItem",
        "newItem",
        "",
        "j",
        "(Ljava/util/List;LxZ0/i;LxZ0/i;)V",
        "",
        "toString",
        "()Ljava/lang/String;",
        "",
        "hashCode",
        "()I",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "a",
        "J",
        "b",
        "()J",
        "LRo/a;",
        "getHeader",
        "()LRo/a;",
        "c",
        "LPo/e;",
        "x",
        "()LPo/e;",
        "d",
        "Ljava/lang/String;",
        "E",
        "e",
        "Lorg/xbet/uikit_sport/score/a;",
        "F",
        "()Lorg/xbet/uikit_sport/score/a;",
        "f",
        "Lbp/a$a$d;",
        "B",
        "()Lbp/a$a$d;",
        "g",
        "Lbp/a$a$g;",
        "G",
        "()Lbp/a$a$g;",
        "h",
        "Ljava/util/List;",
        "A",
        "()Ljava/util/List;",
        "i",
        "Lno/c;",
        "H",
        "()Lno/c;",
        "k",
        "event_card_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field public final a:J

.field public final b:LRo/a;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final c:LPo/e;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final d:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final e:Lorg/xbet/uikit_sport/score/a;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final f:Lbp/a$a$d;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final g:Lbp/a$a$g;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final h:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "+",
            "Ly31/K;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final i:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final j:Lno/c;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final k:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public constructor <init>(JLRo/a;LPo/e;Ljava/lang/String;Lorg/xbet/uikit_sport/score/a;Lbp/a$a$d;Lbp/a$a$g;Ljava/util/List;Ljava/lang/String;Lno/c;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "LRo/a;",
            "LPo/e;",
            "Ljava/lang/String;",
            "Lorg/xbet/uikit_sport/score/a;",
            "Lbp/a$a$d;",
            "Lbp/a$a$g;",
            "Ljava/util/List<",
            "+",
            "Ly31/K;",
            ">;",
            "Ljava/lang/String;",
            "Lno/c;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-wide p1, p0, Lbp/a;->a:J

    .line 4
    iput-object p3, p0, Lbp/a;->b:LRo/a;

    .line 5
    iput-object p4, p0, Lbp/a;->c:LPo/e;

    .line 6
    iput-object p5, p0, Lbp/a;->d:Ljava/lang/String;

    .line 7
    iput-object p6, p0, Lbp/a;->e:Lorg/xbet/uikit_sport/score/a;

    .line 8
    iput-object p7, p0, Lbp/a;->f:Lbp/a$a$d;

    .line 9
    iput-object p8, p0, Lbp/a;->g:Lbp/a$a$g;

    .line 10
    iput-object p9, p0, Lbp/a;->h:Ljava/util/List;

    .line 11
    iput-object p10, p0, Lbp/a;->i:Ljava/lang/String;

    .line 12
    iput-object p11, p0, Lbp/a;->j:Lno/c;

    .line 13
    iput-object p12, p0, Lbp/a;->k:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(JLRo/a;LPo/e;Ljava/lang/String;Lorg/xbet/uikit_sport/score/a;Lbp/a$a$d;Lbp/a$a$g;Ljava/util/List;Ljava/lang/String;Lno/c;Ljava/lang/String;Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct/range {p0 .. p12}, Lbp/a;-><init>(JLRo/a;LPo/e;Ljava/lang/String;Lorg/xbet/uikit_sport/score/a;Lbp/a$a$d;Lbp/a$a$g;Ljava/util/List;Ljava/lang/String;Lno/c;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final A()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Ly31/K;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbp/a;->h:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public final B()Lbp/a$a$d;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbp/a;->f:Lbp/a$a$d;

    .line 2
    .line 3
    return-object v0
.end method

.method public final E()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbp/a;->d:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final F()Lorg/xbet/uikit_sport/score/a;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbp/a;->e:Lorg/xbet/uikit_sport/score/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public final G()Lbp/a$a$g;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbp/a;->g:Lbp/a$a$g;

    .line 2
    .line 3
    return-object v0
.end method

.method public final H()Lno/c;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbp/a;->j:Lno/c;

    .line 2
    .line 3
    return-object v0
.end method

.method public areContentsTheSame(LxZ0/i;LxZ0/i;)Z
    .locals 0
    .param p1    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-static {p0, p1, p2}, LLo/b;->a(LLo/c;LxZ0/i;LxZ0/i;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public areItemsTheSame(LxZ0/i;LxZ0/i;)Z
    .locals 0
    .param p1    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-static {p0, p1, p2}, LLo/b;->b(LLo/c;LxZ0/i;LxZ0/i;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public b()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lbp/a;->a:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final e()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbp/a;->i:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lbp/a;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lbp/a;

    .line 12
    .line 13
    iget-wide v3, p0, Lbp/a;->a:J

    .line 14
    .line 15
    iget-wide v5, p1, Lbp/a;->a:J

    .line 16
    .line 17
    cmp-long v1, v3, v5

    .line 18
    .line 19
    if-eqz v1, :cond_2

    .line 20
    .line 21
    return v2

    .line 22
    :cond_2
    iget-object v1, p0, Lbp/a;->b:LRo/a;

    .line 23
    .line 24
    iget-object v3, p1, Lbp/a;->b:LRo/a;

    .line 25
    .line 26
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-nez v1, :cond_3

    .line 31
    .line 32
    return v2

    .line 33
    :cond_3
    iget-object v1, p0, Lbp/a;->c:LPo/e;

    .line 34
    .line 35
    iget-object v3, p1, Lbp/a;->c:LPo/e;

    .line 36
    .line 37
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-nez v1, :cond_4

    .line 42
    .line 43
    return v2

    .line 44
    :cond_4
    iget-object v1, p0, Lbp/a;->d:Ljava/lang/String;

    .line 45
    .line 46
    iget-object v3, p1, Lbp/a;->d:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {v1, v3}, Lbp/a$a$e;->d(Ljava/lang/String;Ljava/lang/String;)Z

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    if-nez v1, :cond_5

    .line 53
    .line 54
    return v2

    .line 55
    :cond_5
    iget-object v1, p0, Lbp/a;->e:Lorg/xbet/uikit_sport/score/a;

    .line 56
    .line 57
    iget-object v3, p1, Lbp/a;->e:Lorg/xbet/uikit_sport/score/a;

    .line 58
    .line 59
    invoke-static {v1, v3}, Lbp/a$a$f;->d(Lorg/xbet/uikit_sport/score/a;Lorg/xbet/uikit_sport/score/a;)Z

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    if-nez v1, :cond_6

    .line 64
    .line 65
    return v2

    .line 66
    :cond_6
    iget-object v1, p0, Lbp/a;->f:Lbp/a$a$d;

    .line 67
    .line 68
    iget-object v3, p1, Lbp/a;->f:Lbp/a$a$d;

    .line 69
    .line 70
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    if-nez v1, :cond_7

    .line 75
    .line 76
    return v2

    .line 77
    :cond_7
    iget-object v1, p0, Lbp/a;->g:Lbp/a$a$g;

    .line 78
    .line 79
    iget-object v3, p1, Lbp/a;->g:Lbp/a$a$g;

    .line 80
    .line 81
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v1

    .line 85
    if-nez v1, :cond_8

    .line 86
    .line 87
    return v2

    .line 88
    :cond_8
    iget-object v1, p0, Lbp/a;->h:Ljava/util/List;

    .line 89
    .line 90
    iget-object v3, p1, Lbp/a;->h:Ljava/util/List;

    .line 91
    .line 92
    invoke-static {v1, v3}, Lbp/a$a$c;->d(Ljava/util/List;Ljava/util/List;)Z

    .line 93
    .line 94
    .line 95
    move-result v1

    .line 96
    if-nez v1, :cond_9

    .line 97
    .line 98
    return v2

    .line 99
    :cond_9
    iget-object v1, p0, Lbp/a;->i:Ljava/lang/String;

    .line 100
    .line 101
    iget-object v3, p1, Lbp/a;->i:Ljava/lang/String;

    .line 102
    .line 103
    invoke-static {v1, v3}, Lbp/a$a$a;->d(Ljava/lang/String;Ljava/lang/String;)Z

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    if-nez v1, :cond_a

    .line 108
    .line 109
    return v2

    .line 110
    :cond_a
    iget-object v1, p0, Lbp/a;->j:Lno/c;

    .line 111
    .line 112
    iget-object v3, p1, Lbp/a;->j:Lno/c;

    .line 113
    .line 114
    invoke-static {v1, v3}, Lbp/a$a$h;->d(Lno/c;Lno/c;)Z

    .line 115
    .line 116
    .line 117
    move-result v1

    .line 118
    if-nez v1, :cond_b

    .line 119
    .line 120
    return v2

    .line 121
    :cond_b
    iget-object v1, p0, Lbp/a;->k:Ljava/lang/String;

    .line 122
    .line 123
    iget-object p1, p1, Lbp/a;->k:Ljava/lang/String;

    .line 124
    .line 125
    invoke-static {v1, p1}, Lbp/a$a$b;->d(Ljava/lang/String;Ljava/lang/String;)Z

    .line 126
    .line 127
    .line 128
    move-result p1

    .line 129
    if-nez p1, :cond_c

    .line 130
    .line 131
    return v2

    .line 132
    :cond_c
    return v0
.end method

.method public final f()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbp/a;->k:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public g(LxZ0/i;LxZ0/i;)Ljava/util/List;
    .locals 0
    .param p1    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LxZ0/i;",
            "LxZ0/i;",
            ")",
            "Ljava/util/List<",
            "LxZ0/k;",
            ">;"
        }
    .end annotation

    .line 1
    invoke-static {p0, p1, p2}, LLo/b;->c(LLo/c;LxZ0/i;LxZ0/i;)Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public bridge synthetic getChangePayload(LxZ0/i;LxZ0/i;)Ljava/util/Collection;
    .locals 0

    .line 1
    invoke-virtual {p0, p1, p2}, Lbp/a;->g(LxZ0/i;LxZ0/i;)Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public getHeader()LRo/a;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbp/a;->b:LRo/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public getKey()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    invoke-static {p0}, LxZ0/h;->d(LxZ0/i;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public hashCode()I
    .locals 2

    .line 1
    iget-wide v0, p0, Lbp/a;->a:J

    .line 2
    .line 3
    invoke-static {v0, v1}, Lx/k;->a(J)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, Lbp/a;->b:LRo/a;

    .line 10
    .line 11
    invoke-virtual {v1}, LRo/a;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v0, v1

    .line 16
    mul-int/lit8 v0, v0, 0x1f

    .line 17
    .line 18
    iget-object v1, p0, Lbp/a;->c:LPo/e;

    .line 19
    .line 20
    invoke-virtual {v1}, LPo/e;->hashCode()I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    add-int/2addr v0, v1

    .line 25
    mul-int/lit8 v0, v0, 0x1f

    .line 26
    .line 27
    iget-object v1, p0, Lbp/a;->d:Ljava/lang/String;

    .line 28
    .line 29
    invoke-static {v1}, Lbp/a$a$e;->e(Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    add-int/2addr v0, v1

    .line 34
    mul-int/lit8 v0, v0, 0x1f

    .line 35
    .line 36
    iget-object v1, p0, Lbp/a;->e:Lorg/xbet/uikit_sport/score/a;

    .line 37
    .line 38
    invoke-static {v1}, Lbp/a$a$f;->e(Lorg/xbet/uikit_sport/score/a;)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    add-int/2addr v0, v1

    .line 43
    mul-int/lit8 v0, v0, 0x1f

    .line 44
    .line 45
    iget-object v1, p0, Lbp/a;->f:Lbp/a$a$d;

    .line 46
    .line 47
    invoke-virtual {v1}, Lbp/a$a$d;->hashCode()I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    add-int/2addr v0, v1

    .line 52
    mul-int/lit8 v0, v0, 0x1f

    .line 53
    .line 54
    iget-object v1, p0, Lbp/a;->g:Lbp/a$a$g;

    .line 55
    .line 56
    invoke-virtual {v1}, Lbp/a$a$g;->hashCode()I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    add-int/2addr v0, v1

    .line 61
    mul-int/lit8 v0, v0, 0x1f

    .line 62
    .line 63
    iget-object v1, p0, Lbp/a;->h:Ljava/util/List;

    .line 64
    .line 65
    invoke-static {v1}, Lbp/a$a$c;->e(Ljava/util/List;)I

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    add-int/2addr v0, v1

    .line 70
    mul-int/lit8 v0, v0, 0x1f

    .line 71
    .line 72
    iget-object v1, p0, Lbp/a;->i:Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v1}, Lbp/a$a$a;->e(Ljava/lang/String;)I

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    add-int/2addr v0, v1

    .line 79
    mul-int/lit8 v0, v0, 0x1f

    .line 80
    .line 81
    iget-object v1, p0, Lbp/a;->j:Lno/c;

    .line 82
    .line 83
    invoke-static {v1}, Lbp/a$a$h;->e(Lno/c;)I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    add-int/2addr v0, v1

    .line 88
    mul-int/lit8 v0, v0, 0x1f

    .line 89
    .line 90
    iget-object v1, p0, Lbp/a;->k:Ljava/lang/String;

    .line 91
    .line 92
    invoke-static {v1}, Lbp/a$a$b;->e(Ljava/lang/String;)I

    .line 93
    .line 94
    .line 95
    move-result v1

    .line 96
    add-int/2addr v0, v1

    .line 97
    return v0
.end method

.method public j(Ljava/util/List;LxZ0/i;LxZ0/i;)V
    .locals 2
    .param p1    # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LLo/a;",
            ">;",
            "LxZ0/i;",
            "LxZ0/i;",
            ")V"
        }
    .end annotation

    .line 1
    instance-of v0, p2, Lbp/a;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    instance-of v0, p3, Lbp/a;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    check-cast p2, Lbp/a;

    .line 10
    .line 11
    iget-object v0, p2, Lbp/a;->d:Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {v0}, Lbp/a$a$e;->a(Ljava/lang/String;)Lbp/a$a$e;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast p3, Lbp/a;

    .line 18
    .line 19
    iget-object v1, p3, Lbp/a;->d:Ljava/lang/String;

    .line 20
    .line 21
    invoke-static {v1}, Lbp/a$a$e;->a(Ljava/lang/String;)Lbp/a$a$e;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    iget-object v0, p2, Lbp/a;->e:Lorg/xbet/uikit_sport/score/a;

    .line 29
    .line 30
    invoke-static {v0}, Lbp/a$a$f;->a(Lorg/xbet/uikit_sport/score/a;)Lbp/a$a$f;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    iget-object v1, p3, Lbp/a;->e:Lorg/xbet/uikit_sport/score/a;

    .line 35
    .line 36
    invoke-static {v1}, Lbp/a$a$f;->a(Lorg/xbet/uikit_sport/score/a;)Lbp/a$a$f;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    iget-object v0, p2, Lbp/a;->f:Lbp/a$a$d;

    .line 44
    .line 45
    iget-object v1, p3, Lbp/a;->f:Lbp/a$a$d;

    .line 46
    .line 47
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    iget-object v0, p2, Lbp/a;->g:Lbp/a$a$g;

    .line 51
    .line 52
    iget-object v1, p3, Lbp/a;->g:Lbp/a$a$g;

    .line 53
    .line 54
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iget-object v0, p2, Lbp/a;->h:Ljava/util/List;

    .line 58
    .line 59
    invoke-static {v0}, Lbp/a$a$c;->a(Ljava/util/List;)Lbp/a$a$c;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    iget-object v1, p3, Lbp/a;->h:Ljava/util/List;

    .line 64
    .line 65
    invoke-static {v1}, Lbp/a$a$c;->a(Ljava/util/List;)Lbp/a$a$c;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    iget-object v0, p2, Lbp/a;->i:Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v0}, Lbp/a$a$a;->a(Ljava/lang/String;)Lbp/a$a$a;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    iget-object v1, p3, Lbp/a;->i:Ljava/lang/String;

    .line 79
    .line 80
    invoke-static {v1}, Lbp/a$a$a;->a(Ljava/lang/String;)Lbp/a$a$a;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    iget-object v0, p2, Lbp/a;->j:Lno/c;

    .line 88
    .line 89
    invoke-static {v0}, Lbp/a$a$h;->a(Lno/c;)Lbp/a$a$h;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    iget-object v1, p3, Lbp/a;->j:Lno/c;

    .line 94
    .line 95
    invoke-static {v1}, Lbp/a$a$h;->a(Lno/c;)Lbp/a$a$h;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-static {p1, v0, v1}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    iget-object p2, p2, Lbp/a;->k:Ljava/lang/String;

    .line 103
    .line 104
    invoke-static {p2}, Lbp/a$a$b;->a(Ljava/lang/String;)Lbp/a$a$b;

    .line 105
    .line 106
    .line 107
    move-result-object p2

    .line 108
    iget-object p3, p3, Lbp/a;->k:Ljava/lang/String;

    .line 109
    .line 110
    invoke-static {p3}, Lbp/a$a$b;->a(Ljava/lang/String;)Lbp/a$a$b;

    .line 111
    .line 112
    .line 113
    move-result-object p3

    .line 114
    invoke-static {p1, p2, p3}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    :cond_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 14
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-wide v0, p0, Lbp/a;->a:J

    .line 2
    .line 3
    iget-object v2, p0, Lbp/a;->b:LRo/a;

    .line 4
    .line 5
    iget-object v3, p0, Lbp/a;->c:LPo/e;

    .line 6
    .line 7
    iget-object v4, p0, Lbp/a;->d:Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {v4}, Lbp/a$a$e;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v4

    .line 13
    iget-object v5, p0, Lbp/a;->e:Lorg/xbet/uikit_sport/score/a;

    .line 14
    .line 15
    invoke-static {v5}, Lbp/a$a$f;->f(Lorg/xbet/uikit_sport/score/a;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v5

    .line 19
    iget-object v6, p0, Lbp/a;->f:Lbp/a$a$d;

    .line 20
    .line 21
    iget-object v7, p0, Lbp/a;->g:Lbp/a$a$g;

    .line 22
    .line 23
    iget-object v8, p0, Lbp/a;->h:Ljava/util/List;

    .line 24
    .line 25
    invoke-static {v8}, Lbp/a$a$c;->f(Ljava/util/List;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v8

    .line 29
    iget-object v9, p0, Lbp/a;->i:Ljava/lang/String;

    .line 30
    .line 31
    invoke-static {v9}, Lbp/a$a$a;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v9

    .line 35
    iget-object v10, p0, Lbp/a;->j:Lno/c;

    .line 36
    .line 37
    invoke-static {v10}, Lbp/a$a$h;->f(Lno/c;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v10

    .line 41
    iget-object v11, p0, Lbp/a;->k:Ljava/lang/String;

    .line 42
    .line 43
    invoke-static {v11}, Lbp/a$a$b;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v11

    .line 47
    new-instance v12, Ljava/lang/StringBuilder;

    .line 48
    .line 49
    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    .line 50
    .line 51
    .line 52
    const-string v13, "GameCardType14UiModel(gameId="

    .line 53
    .line 54
    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    invoke-virtual {v12, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    const-string v0, ", header="

    .line 61
    .line 62
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-virtual {v12, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    const-string v0, ", footer="

    .line 69
    .line 70
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v12, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    const-string v0, ", information="

    .line 77
    .line 78
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 82
    .line 83
    .line 84
    const-string v0, ", score="

    .line 85
    .line 86
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v12, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    const-string v0, ", firstTeam="

    .line 93
    .line 94
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    invoke-virtual {v12, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    const-string v0, ", secondTeam="

    .line 101
    .line 102
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 103
    .line 104
    .line 105
    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    const-string v0, ", dealearCards="

    .line 109
    .line 110
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    const-string v0, ", bottomInfo="

    .line 117
    .line 118
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 119
    .line 120
    .line 121
    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    const-string v0, ", timer="

    .line 125
    .line 126
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 127
    .line 128
    .line 129
    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 130
    .line 131
    .line 132
    const-string v0, ", caption="

    .line 133
    .line 134
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 135
    .line 136
    .line 137
    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 138
    .line 139
    .line 140
    const-string v0, ")"

    .line 141
    .line 142
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    return-object v0
.end method

.method public x()LPo/e;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, Lbp/a;->c:LPo/e;

    .line 2
    .line 3
    return-object v0
.end method
