.class public final Lbr/k$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lbr/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lbr/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lbr/k$a$b;,
        Lbr/k$a$d;,
        Lbr/k$a$a;,
        Lbr/k$a$c;
    }
.end annotation


# instance fields
.field public final a:Ly11/a;

.field public final b:LZY0/k;

.field public final c:Lbr/k$a;

.field public d:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LmZ0/f;",
            ">;"
        }
    .end annotation
.end field

.field public e:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bonuses/impl/domain/b;",
            ">;"
        }
    .end annotation
.end field

.field public f:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bonuses/impl/domain/e;",
            ">;"
        }
    .end annotation
.end field

.field public g:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/n;",
            ">;"
        }
    .end annotation
.end field

.field public h:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/z;",
            ">;"
        }
    .end annotation
.end field

.field public i:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lrj/i;",
            ">;"
        }
    .end annotation
.end field

.field public j:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bonuses/impl/domain/RefuseBonusScenario;",
            ">;"
        }
    .end annotation
.end field

.field public k:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LuZ0/e;",
            ">;"
        }
    .end annotation
.end field

.field public l:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/internet/a;",
            ">;"
        }
    .end annotation
.end field

.field public m:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LF7/a;",
            ">;"
        }
    .end annotation
.end field

.field public n:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LWY0/C;",
            ">;"
        }
    .end annotation
.end field

.field public o:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/L;",
            ">;"
        }
    .end annotation
.end field

.field public p:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LR6/a;",
            ">;"
        }
    .end annotation
.end field

.field public q:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bonuses/impl/domain/c;",
            ">;"
        }
    .end annotation
.end field

.field public r:Lorg/xbet/bonuses/impl/presentation/v;

.field public s:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lbr/i;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LtY0/c;Lmj/a;Ly11/a;LmZ0/f;Lorg/xbet/ui_core/utils/internet/a;Lx7/f;Lw8/b;Lorg/xbet/bonuses/impl/domain/b;LuZ0/e;LWY0/C;Lorg/xbet/ui_core/utils/L;LZY0/k;LR6/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p0, p0, Lbr/k$a;->c:Lbr/k$a;

    .line 5
    .line 6
    iput-object p3, p0, Lbr/k$a;->a:Ly11/a;

    .line 7
    .line 8
    iput-object p12, p0, Lbr/k$a;->b:LZY0/k;

    .line 9
    .line 10
    invoke-virtual/range {p0 .. p13}, Lbr/k$a;->b(LtY0/c;Lmj/a;Ly11/a;LmZ0/f;Lorg/xbet/ui_core/utils/internet/a;Lx7/f;Lw8/b;Lorg/xbet/bonuses/impl/domain/b;LuZ0/e;LWY0/C;Lorg/xbet/ui_core/utils/L;LZY0/k;LR6/a;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public a(Lorg/xbet/bonuses/impl/presentation/BonusesFragment;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lbr/k$a;->c(Lorg/xbet/bonuses/impl/presentation/BonusesFragment;)Lorg/xbet/bonuses/impl/presentation/BonusesFragment;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final b(LtY0/c;Lmj/a;Ly11/a;LmZ0/f;Lorg/xbet/ui_core/utils/internet/a;Lx7/f;Lw8/b;Lorg/xbet/bonuses/impl/domain/b;LuZ0/e;LWY0/C;Lorg/xbet/ui_core/utils/L;LZY0/k;LR6/a;)V
    .locals 0

    .line 1
    invoke-static {p4}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 2
    .line 3
    .line 4
    move-result-object p3

    .line 5
    iput-object p3, p0, Lbr/k$a;->d:Ldagger/internal/h;

    .line 6
    .line 7
    invoke-static {p8}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 8
    .line 9
    .line 10
    move-result-object p3

    .line 11
    iput-object p3, p0, Lbr/k$a;->e:Ldagger/internal/h;

    .line 12
    .line 13
    invoke-static {p3}, Lorg/xbet/bonuses/impl/domain/f;->a(Ldagger/internal/h;)Lorg/xbet/bonuses/impl/domain/f;

    .line 14
    .line 15
    .line 16
    move-result-object p3

    .line 17
    iput-object p3, p0, Lbr/k$a;->f:Ldagger/internal/h;

    .line 18
    .line 19
    new-instance p3, Lbr/k$a$b;

    .line 20
    .line 21
    invoke-direct {p3, p2}, Lbr/k$a$b;-><init>(Lmj/a;)V

    .line 22
    .line 23
    .line 24
    iput-object p3, p0, Lbr/k$a;->g:Ldagger/internal/h;

    .line 25
    .line 26
    new-instance p3, Lbr/k$a$d;

    .line 27
    .line 28
    invoke-direct {p3, p2}, Lbr/k$a$d;-><init>(Lmj/a;)V

    .line 29
    .line 30
    .line 31
    iput-object p3, p0, Lbr/k$a;->h:Ldagger/internal/h;

    .line 32
    .line 33
    new-instance p3, Lbr/k$a$a;

    .line 34
    .line 35
    invoke-direct {p3, p2}, Lbr/k$a$a;-><init>(Lmj/a;)V

    .line 36
    .line 37
    .line 38
    iput-object p3, p0, Lbr/k$a;->i:Ldagger/internal/h;

    .line 39
    .line 40
    iget-object p2, p0, Lbr/k$a;->e:Ldagger/internal/h;

    .line 41
    .line 42
    iget-object p4, p0, Lbr/k$a;->g:Ldagger/internal/h;

    .line 43
    .line 44
    iget-object p6, p0, Lbr/k$a;->h:Ldagger/internal/h;

    .line 45
    .line 46
    invoke-static {p2, p4, p6, p3}, Lorg/xbet/bonuses/impl/domain/g;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bonuses/impl/domain/g;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    iput-object p2, p0, Lbr/k$a;->j:Ldagger/internal/h;

    .line 51
    .line 52
    invoke-static {p9}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 53
    .line 54
    .line 55
    move-result-object p2

    .line 56
    iput-object p2, p0, Lbr/k$a;->k:Ldagger/internal/h;

    .line 57
    .line 58
    invoke-static {p5}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 59
    .line 60
    .line 61
    move-result-object p2

    .line 62
    iput-object p2, p0, Lbr/k$a;->l:Ldagger/internal/h;

    .line 63
    .line 64
    new-instance p2, Lbr/k$a$c;

    .line 65
    .line 66
    invoke-direct {p2, p1}, Lbr/k$a$c;-><init>(LtY0/c;)V

    .line 67
    .line 68
    .line 69
    iput-object p2, p0, Lbr/k$a;->m:Ldagger/internal/h;

    .line 70
    .line 71
    invoke-static {p10}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    iput-object p1, p0, Lbr/k$a;->n:Ldagger/internal/h;

    .line 76
    .line 77
    invoke-static {p11}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    iput-object p1, p0, Lbr/k$a;->o:Ldagger/internal/h;

    .line 82
    .line 83
    invoke-static {p13}, Ldagger/internal/e;->a(Ljava/lang/Object;)Ldagger/internal/d;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    iput-object p1, p0, Lbr/k$a;->p:Ldagger/internal/h;

    .line 88
    .line 89
    iget-object p1, p0, Lbr/k$a;->e:Ldagger/internal/h;

    .line 90
    .line 91
    invoke-static {p1}, Lorg/xbet/bonuses/impl/domain/d;->a(Ldagger/internal/h;)Lorg/xbet/bonuses/impl/domain/d;

    .line 92
    .line 93
    .line 94
    move-result-object p11

    .line 95
    iput-object p11, p0, Lbr/k$a;->q:Ldagger/internal/h;

    .line 96
    .line 97
    iget-object p2, p0, Lbr/k$a;->d:Ldagger/internal/h;

    .line 98
    .line 99
    iget-object p3, p0, Lbr/k$a;->f:Ldagger/internal/h;

    .line 100
    .line 101
    iget-object p4, p0, Lbr/k$a;->j:Ldagger/internal/h;

    .line 102
    .line 103
    iget-object p5, p0, Lbr/k$a;->k:Ldagger/internal/h;

    .line 104
    .line 105
    iget-object p6, p0, Lbr/k$a;->l:Ldagger/internal/h;

    .line 106
    .line 107
    iget-object p7, p0, Lbr/k$a;->m:Ldagger/internal/h;

    .line 108
    .line 109
    iget-object p8, p0, Lbr/k$a;->n:Ldagger/internal/h;

    .line 110
    .line 111
    iget-object p9, p0, Lbr/k$a;->o:Ldagger/internal/h;

    .line 112
    .line 113
    iget-object p10, p0, Lbr/k$a;->p:Ldagger/internal/h;

    .line 114
    .line 115
    invoke-static/range {p2 .. p11}, Lorg/xbet/bonuses/impl/presentation/v;->a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lorg/xbet/bonuses/impl/presentation/v;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    iput-object p1, p0, Lbr/k$a;->r:Lorg/xbet/bonuses/impl/presentation/v;

    .line 120
    .line 121
    invoke-static {p1}, Lbr/j;->c(Lorg/xbet/bonuses/impl/presentation/v;)Ldagger/internal/h;

    .line 122
    .line 123
    .line 124
    move-result-object p1

    .line 125
    iput-object p1, p0, Lbr/k$a;->s:Ldagger/internal/h;

    .line 126
    .line 127
    return-void
.end method

.method public final c(Lorg/xbet/bonuses/impl/presentation/BonusesFragment;)Lorg/xbet/bonuses/impl/presentation/BonusesFragment;
    .locals 1
    .annotation build Lcom/google/errorprone/annotations/CanIgnoreReturnValue;
    .end annotation

    .line 1
    iget-object v0, p0, Lbr/k$a;->s:Ldagger/internal/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lbr/i;

    .line 8
    .line 9
    invoke-static {p1, v0}, Lorg/xbet/bonuses/impl/presentation/j;->c(Lorg/xbet/bonuses/impl/presentation/BonusesFragment;Lbr/i;)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, Lbr/k$a;->a:Ly11/a;

    .line 13
    .line 14
    invoke-static {p1, v0}, Lorg/xbet/bonuses/impl/presentation/j;->a(Lorg/xbet/bonuses/impl/presentation/BonusesFragment;Ly11/a;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lbr/k$a;->b:LZY0/k;

    .line 18
    .line 19
    invoke-static {p1, v0}, Lorg/xbet/bonuses/impl/presentation/j;->b(Lorg/xbet/bonuses/impl/presentation/BonusesFragment;LZY0/k;)V

    .line 20
    .line 21
    .line 22
    return-object p1
.end method
