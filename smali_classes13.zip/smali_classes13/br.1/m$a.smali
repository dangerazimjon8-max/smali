.class public final Lbr/m$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lbr/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lbr/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Lbr/m$a;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p0, p0, Lbr/m$a;->a:Lbr/m$a;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public a()LWq/a;
    .locals 1

    .line 1
    new-instance v0, Lcr/a;

    .line 2
    .line 3
    invoke-direct {v0}, Lcr/a;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
