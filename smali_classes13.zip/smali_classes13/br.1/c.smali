.class public final Lbr/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldagger/internal/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ldagger/internal/d<",
        "Lbr/b;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LmZ0/f;",
            ">;"
        }
    .end annotation
.end field

.field public final b:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/internet/a;",
            ">;"
        }
    .end annotation
.end field

.field public final c:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lx7/f;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lw8/b;",
            ">;"
        }
    .end annotation
.end field

.field public final e:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/bonuses/impl/domain/b;",
            ">;"
        }
    .end annotation
.end field

.field public final f:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LuZ0/e;",
            ">;"
        }
    .end annotation
.end field

.field public final g:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Ly11/a;",
            ">;"
        }
    .end annotation
.end field

.field public final h:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LWY0/C;",
            ">;"
        }
    .end annotation
.end field

.field public final i:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lmj/a;",
            ">;"
        }
    .end annotation
.end field

.field public final j:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/L;",
            ">;"
        }
    .end annotation
.end field

.field public final k:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LZY0/k;",
            ">;"
        }
    .end annotation
.end field

.field public final l:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LtY0/c;",
            ">;"
        }
    .end annotation
.end field

.field public final m:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LR6/a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "LmZ0/f;",
            ">;",
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/internet/a;",
            ">;",
            "Ldagger/internal/h<",
            "Lx7/f;",
            ">;",
            "Ldagger/internal/h<",
            "Lw8/b;",
            ">;",
            "Ldagger/internal/h<",
            "Lorg/xbet/bonuses/impl/domain/b;",
            ">;",
            "Ldagger/internal/h<",
            "LuZ0/e;",
            ">;",
            "Ldagger/internal/h<",
            "Ly11/a;",
            ">;",
            "Ldagger/internal/h<",
            "LWY0/C;",
            ">;",
            "Ldagger/internal/h<",
            "Lmj/a;",
            ">;",
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/L;",
            ">;",
            "Ldagger/internal/h<",
            "LZY0/k;",
            ">;",
            "Ldagger/internal/h<",
            "LtY0/c;",
            ">;",
            "Ldagger/internal/h<",
            "LR6/a;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbr/c;->a:Ldagger/internal/h;

    .line 5
    .line 6
    iput-object p2, p0, Lbr/c;->b:Ldagger/internal/h;

    .line 7
    .line 8
    iput-object p3, p0, Lbr/c;->c:Ldagger/internal/h;

    .line 9
    .line 10
    iput-object p4, p0, Lbr/c;->d:Ldagger/internal/h;

    .line 11
    .line 12
    iput-object p5, p0, Lbr/c;->e:Ldagger/internal/h;

    .line 13
    .line 14
    iput-object p6, p0, Lbr/c;->f:Ldagger/internal/h;

    .line 15
    .line 16
    iput-object p7, p0, Lbr/c;->g:Ldagger/internal/h;

    .line 17
    .line 18
    iput-object p8, p0, Lbr/c;->h:Ldagger/internal/h;

    .line 19
    .line 20
    iput-object p9, p0, Lbr/c;->i:Ldagger/internal/h;

    .line 21
    .line 22
    iput-object p10, p0, Lbr/c;->j:Ldagger/internal/h;

    .line 23
    .line 24
    iput-object p11, p0, Lbr/c;->k:Ldagger/internal/h;

    .line 25
    .line 26
    iput-object p12, p0, Lbr/c;->l:Ldagger/internal/h;

    .line 27
    .line 28
    iput-object p13, p0, Lbr/c;->m:Ldagger/internal/h;

    .line 29
    .line 30
    return-void
.end method

.method public static a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)Lbr/c;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "LmZ0/f;",
            ">;",
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/internet/a;",
            ">;",
            "Ldagger/internal/h<",
            "Lx7/f;",
            ">;",
            "Ldagger/internal/h<",
            "Lw8/b;",
            ">;",
            "Ldagger/internal/h<",
            "Lorg/xbet/bonuses/impl/domain/b;",
            ">;",
            "Ldagger/internal/h<",
            "LuZ0/e;",
            ">;",
            "Ldagger/internal/h<",
            "Ly11/a;",
            ">;",
            "Ldagger/internal/h<",
            "LWY0/C;",
            ">;",
            "Ldagger/internal/h<",
            "Lmj/a;",
            ">;",
            "Ldagger/internal/h<",
            "Lorg/xbet/ui_core/utils/L;",
            ">;",
            "Ldagger/internal/h<",
            "LZY0/k;",
            ">;",
            "Ldagger/internal/h<",
            "LtY0/c;",
            ">;",
            "Ldagger/internal/h<",
            "LR6/a;",
            ">;)",
            "Lbr/c;"
        }
    .end annotation

    .line 1
    new-instance v0, Lbr/c;

    .line 2
    .line 3
    move-object v1, p0

    .line 4
    move-object v2, p1

    .line 5
    move-object/from16 v3, p2

    .line 6
    .line 7
    move-object/from16 v4, p3

    .line 8
    .line 9
    move-object/from16 v5, p4

    .line 10
    .line 11
    move-object/from16 v6, p5

    .line 12
    .line 13
    move-object/from16 v7, p6

    .line 14
    .line 15
    move-object/from16 v8, p7

    .line 16
    .line 17
    move-object/from16 v9, p8

    .line 18
    .line 19
    move-object/from16 v10, p9

    .line 20
    .line 21
    move-object/from16 v11, p10

    .line 22
    .line 23
    move-object/from16 v12, p11

    .line 24
    .line 25
    move-object/from16 v13, p12

    .line 26
    .line 27
    invoke-direct/range {v0 .. v13}, Lbr/c;-><init>(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)V

    .line 28
    .line 29
    .line 30
    return-object v0
.end method

.method public static c(LmZ0/f;Lorg/xbet/ui_core/utils/internet/a;Lx7/f;Lw8/b;Lorg/xbet/bonuses/impl/domain/b;LuZ0/e;Ly11/a;LWY0/C;Lmj/a;Lorg/xbet/ui_core/utils/L;LZY0/k;LtY0/c;LR6/a;)Lbr/b;
    .locals 14

    .line 1
    new-instance v0, Lbr/b;

    .line 2
    .line 3
    move-object v1, p0

    .line 4
    move-object v2, p1

    .line 5
    move-object/from16 v3, p2

    .line 6
    .line 7
    move-object/from16 v4, p3

    .line 8
    .line 9
    move-object/from16 v5, p4

    .line 10
    .line 11
    move-object/from16 v6, p5

    .line 12
    .line 13
    move-object/from16 v7, p6

    .line 14
    .line 15
    move-object/from16 v8, p7

    .line 16
    .line 17
    move-object/from16 v9, p8

    .line 18
    .line 19
    move-object/from16 v10, p9

    .line 20
    .line 21
    move-object/from16 v11, p10

    .line 22
    .line 23
    move-object/from16 v12, p11

    .line 24
    .line 25
    move-object/from16 v13, p12

    .line 26
    .line 27
    invoke-direct/range {v0 .. v13}, Lbr/b;-><init>(LmZ0/f;Lorg/xbet/ui_core/utils/internet/a;Lx7/f;Lw8/b;Lorg/xbet/bonuses/impl/domain/b;LuZ0/e;Ly11/a;LWY0/C;Lmj/a;Lorg/xbet/ui_core/utils/L;LZY0/k;LtY0/c;LR6/a;)V

    .line 28
    .line 29
    .line 30
    return-object v0
.end method


# virtual methods
.method public b()Lbr/b;
    .locals 14

    .line 1
    iget-object v0, p0, Lbr/c;->a:Ldagger/internal/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    move-object v1, v0

    .line 8
    check-cast v1, LmZ0/f;

    .line 9
    .line 10
    iget-object v0, p0, Lbr/c;->b:Ldagger/internal/h;

    .line 11
    .line 12
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    move-object v2, v0

    .line 17
    check-cast v2, Lorg/xbet/ui_core/utils/internet/a;

    .line 18
    .line 19
    iget-object v0, p0, Lbr/c;->c:Ldagger/internal/h;

    .line 20
    .line 21
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    move-object v3, v0

    .line 26
    check-cast v3, Lx7/f;

    .line 27
    .line 28
    iget-object v0, p0, Lbr/c;->d:Ldagger/internal/h;

    .line 29
    .line 30
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    move-object v4, v0

    .line 35
    check-cast v4, Lw8/b;

    .line 36
    .line 37
    iget-object v0, p0, Lbr/c;->e:Ldagger/internal/h;

    .line 38
    .line 39
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    move-object v5, v0

    .line 44
    check-cast v5, Lorg/xbet/bonuses/impl/domain/b;

    .line 45
    .line 46
    iget-object v0, p0, Lbr/c;->f:Ldagger/internal/h;

    .line 47
    .line 48
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    move-object v6, v0

    .line 53
    check-cast v6, LuZ0/e;

    .line 54
    .line 55
    iget-object v0, p0, Lbr/c;->g:Ldagger/internal/h;

    .line 56
    .line 57
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    move-object v7, v0

    .line 62
    check-cast v7, Ly11/a;

    .line 63
    .line 64
    iget-object v0, p0, Lbr/c;->h:Ldagger/internal/h;

    .line 65
    .line 66
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    move-object v8, v0

    .line 71
    check-cast v8, LWY0/C;

    .line 72
    .line 73
    iget-object v0, p0, Lbr/c;->i:Ldagger/internal/h;

    .line 74
    .line 75
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    move-object v9, v0

    .line 80
    check-cast v9, Lmj/a;

    .line 81
    .line 82
    iget-object v0, p0, Lbr/c;->j:Ldagger/internal/h;

    .line 83
    .line 84
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    move-object v10, v0

    .line 89
    check-cast v10, Lorg/xbet/ui_core/utils/L;

    .line 90
    .line 91
    iget-object v0, p0, Lbr/c;->k:Ldagger/internal/h;

    .line 92
    .line 93
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    move-object v11, v0

    .line 98
    check-cast v11, LZY0/k;

    .line 99
    .line 100
    iget-object v0, p0, Lbr/c;->l:Ldagger/internal/h;

    .line 101
    .line 102
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    move-object v12, v0

    .line 107
    check-cast v12, LtY0/c;

    .line 108
    .line 109
    iget-object v0, p0, Lbr/c;->m:Ldagger/internal/h;

    .line 110
    .line 111
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    move-object v13, v0

    .line 116
    check-cast v13, LR6/a;

    .line 117
    .line 118
    invoke-static/range {v1 .. v13}, Lbr/c;->c(LmZ0/f;Lorg/xbet/ui_core/utils/internet/a;Lx7/f;Lw8/b;Lorg/xbet/bonuses/impl/domain/b;LuZ0/e;Ly11/a;LWY0/C;Lmj/a;Lorg/xbet/ui_core/utils/L;LZY0/k;LtY0/c;LR6/a;)Lbr/b;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    return-object v0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lbr/c;->b()Lbr/b;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
