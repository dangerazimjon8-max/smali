.class public final Lbr/m$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lbr/d$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lbr/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lbr/n;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lbr/m$b;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lbr/d;
    .locals 1

    .line 1
    new-instance v0, Lbr/m$a;

    .line 2
    .line 3
    invoke-direct {v0}, Lbr/m$a;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
