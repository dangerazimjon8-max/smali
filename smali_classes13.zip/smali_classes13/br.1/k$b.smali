.class public final Lbr/k$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lbr/a$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lbr/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lbr/l;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lbr/k$b;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ly11/a;LmZ0/f;Lorg/xbet/ui_core/utils/internet/a;Lx7/f;Lw8/b;Lorg/xbet/bonuses/impl/domain/b;LuZ0/e;LWY0/C;Lorg/xbet/ui_core/utils/L;LZY0/k;LR6/a;LtY0/c;Lmj/a;)Lbr/a;
    .locals 14

    .line 1
    invoke-static {p1}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    invoke-static/range {p2 .. p2}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    invoke-static/range {p3 .. p3}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    invoke-static/range {p4 .. p4}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    invoke-static/range {p5 .. p5}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    invoke-static/range {p6 .. p6}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    invoke-static/range {p7 .. p7}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    invoke-static/range {p8 .. p8}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    invoke-static/range {p9 .. p9}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    invoke-static/range {p10 .. p10}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    invoke-static/range {p11 .. p11}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    invoke-static/range {p12 .. p12}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    invoke-static/range {p13 .. p13}, Ldagger/internal/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    new-instance v0, Lbr/k$a;

    .line 41
    .line 42
    move-object v3, p1

    .line 43
    move-object/from16 v4, p2

    .line 44
    .line 45
    move-object/from16 v5, p3

    .line 46
    .line 47
    move-object/from16 v6, p4

    .line 48
    .line 49
    move-object/from16 v7, p5

    .line 50
    .line 51
    move-object/from16 v8, p6

    .line 52
    .line 53
    move-object/from16 v9, p7

    .line 54
    .line 55
    move-object/from16 v10, p8

    .line 56
    .line 57
    move-object/from16 v11, p9

    .line 58
    .line 59
    move-object/from16 v12, p10

    .line 60
    .line 61
    move-object/from16 v13, p11

    .line 62
    .line 63
    move-object/from16 v1, p12

    .line 64
    .line 65
    move-object/from16 v2, p13

    .line 66
    .line 67
    invoke-direct/range {v0 .. v13}, Lbr/k$a;-><init>(LtY0/c;Lmj/a;Ly11/a;LmZ0/f;Lorg/xbet/ui_core/utils/internet/a;Lx7/f;Lw8/b;Lorg/xbet/bonuses/impl/domain/b;LuZ0/e;LWY0/C;Lorg/xbet/ui_core/utils/L;LZY0/k;LR6/a;)V

    .line 68
    .line 69
    .line 70
    return-object v0
.end method
