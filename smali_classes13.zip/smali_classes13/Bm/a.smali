.class public final LBm/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0014\u0008\u0000\u0018\u00002\u00020\u0001B+\u0008\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0008\u0008\u0001\u0010\t\u001a\u00020\u0008\u00a2\u0006\u0004\u0008\n\u0010\u000bJ\u001d\u0010\u0011\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u000f\u001a\u00020\u000e\u00a2\u0006\u0004\u0008\u0011\u0010\u0012J\u0015\u0010\u0013\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u000c\u00a2\u0006\u0004\u0008\u0013\u0010\u0014J\u0015\u0010\u0015\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u000c\u00a2\u0006\u0004\u0008\u0015\u0010\u0014J\u001d\u0010\u0017\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0016\u001a\u00020\u0008\u00a2\u0006\u0004\u0008\u0017\u0010\u0018J\u0015\u0010\u0019\u001a\u00020\u00102\u0006\u0010\u0016\u001a\u00020\u0008\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0015\u0010\u001b\u001a\u00020\u00102\u0006\u0010\u0016\u001a\u00020\u0008\u00a2\u0006\u0004\u0008\u001b\u0010\u001aJ\u0015\u0010\u001c\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u000c\u00a2\u0006\u0004\u0008\u001c\u0010\u0014J\u0015\u0010\u001d\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u000c\u00a2\u0006\u0004\u0008\u001d\u0010\u0014J\u0015\u0010\u001e\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u000c\u00a2\u0006\u0004\u0008\u001e\u0010\u0014J\u0017\u0010\u001f\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u000cH\u0002\u00a2\u0006\u0004\u0008\u001f\u0010\u0014R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u0019\u0010 R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u001e\u0010!R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u001d\u0010\"R\u0014\u0010\t\u001a\u00020\u00088\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u0013\u0010#\u00a8\u0006$"
    }
    d2 = {
        "LBm/a;",
        "",
        "LZQ/b;",
        "historyFatmanLogger",
        "Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;",
        "historyAnalytics",
        "LqR/a;",
        "pushFatmanLogger",
        "",
        "screenName",
        "<init>",
        "(LZQ/b;Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;LqR/a;Ljava/lang/String;)V",
        "Lorg/xbet/analytics/domain/scope/history/HistoryEventType;",
        "eventType",
        "",
        "errorCode",
        "",
        "g",
        "(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;I)V",
        "d",
        "(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V",
        "f",
        "betId",
        "h",
        "(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;Ljava/lang/String;)V",
        "a",
        "(Ljava/lang/String;)V",
        "j",
        "e",
        "c",
        "b",
        "i",
        "LZQ/b;",
        "Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;",
        "LqR/a;",
        "Ljava/lang/String;",
        "impl_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field public final a:LZQ/b;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final b:Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final c:LqR/a;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final d:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public constructor <init>(LZQ/b;Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;LqR/a;Ljava/lang/String;)V
    .locals 0
    .param p1    # LZQ/b;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3    # LqR/a;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LBm/a;->a:LZQ/b;

    .line 5
    .line 6
    iput-object p2, p0, LBm/a;->b:Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;

    .line 7
    .line 8
    iput-object p3, p0, LBm/a;->c:LqR/a;

    .line 9
    .line 10
    iput-object p4, p0, LBm/a;->d:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    iget-object v0, p0, LBm/a;->c:LqR/a;

    .line 2
    .line 3
    iget-object v1, p0, LBm/a;->d:Ljava/lang/String;

    .line 4
    .line 5
    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 6
    .line 7
    .line 8
    move-result-wide v2

    .line 9
    invoke-interface {v0, v1, v2, v3}, LqR/a;->s(Ljava/lang/String;J)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final b(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V
    .locals 0
    .param p1    # Lorg/xbet/analytics/domain/scope/history/HistoryEventType;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-virtual {p0, p1}, LBm/a;->i(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final c(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V
    .locals 0
    .param p1    # Lorg/xbet/analytics/domain/scope/history/HistoryEventType;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-virtual {p0, p1}, LBm/a;->i(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final d(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V
    .locals 2
    .param p1    # Lorg/xbet/analytics/domain/scope/history/HistoryEventType;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-virtual {p0, p1}, LBm/a;->i(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, LBm/a;->a:LZQ/b;

    .line 5
    .line 6
    iget-object v0, p0, LBm/a;->d:Ljava/lang/String;

    .line 7
    .line 8
    sget-object v1, Lorg/xbet/analytics/domain/scope/history/HistoryScreenType;->BET_SCREEN_ABOUT_BET:Lorg/xbet/analytics/domain/scope/history/HistoryScreenType;

    .line 9
    .line 10
    invoke-virtual {v1}, Lorg/xbet/analytics/domain/scope/history/HistoryScreenType;->getEventName()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-interface {p1, v0, v1}, LZQ/b;->j(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final e(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V
    .locals 0
    .param p1    # Lorg/xbet/analytics/domain/scope/history/HistoryEventType;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-virtual {p0, p1}, LBm/a;->i(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final f(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V
    .locals 2
    .param p1    # Lorg/xbet/analytics/domain/scope/history/HistoryEventType;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-virtual {p0, p1}, LBm/a;->i(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, LBm/a;->a:LZQ/b;

    .line 5
    .line 6
    iget-object v0, p0, LBm/a;->d:Ljava/lang/String;

    .line 7
    .line 8
    sget-object v1, Lorg/xbet/analytics/domain/scope/history/HistoryScreenType;->BET_SCREEN_ABOUT_BET:Lorg/xbet/analytics/domain/scope/history/HistoryScreenType;

    .line 9
    .line 10
    invoke-virtual {v1}, Lorg/xbet/analytics/domain/scope/history/HistoryScreenType;->getEventName()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-interface {p1, v0, v1}, LZQ/b;->k(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final g(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;I)V
    .locals 3
    .param p1    # Lorg/xbet/analytics/domain/scope/history/HistoryEventType;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    iget-object v0, p0, LBm/a;->b:Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;

    .line 2
    .line 3
    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sget-object v2, Lorg/xbet/analytics/domain/scope/history/HistoryScreenType;->BET_SCREEN_ABOUT_BET:Lorg/xbet/analytics/domain/scope/history/HistoryScreenType;

    .line 8
    .line 9
    invoke-virtual {v0, p1, v1, v2}, Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;->d(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;Ljava/lang/String;Lorg/xbet/analytics/domain/scope/history/HistoryScreenType;)V

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, LBm/a;->a:LZQ/b;

    .line 13
    .line 14
    iget-object v0, p0, LBm/a;->d:Ljava/lang/String;

    .line 15
    .line 16
    invoke-virtual {v2}, Lorg/xbet/analytics/domain/scope/history/HistoryScreenType;->getEventName()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    invoke-interface {p1, v0, p2, v1}, LZQ/b;->f(Ljava/lang/String;ILjava/lang/String;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final h(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;Ljava/lang/String;)V
    .locals 1
    .param p1    # Lorg/xbet/analytics/domain/scope/history/HistoryEventType;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    iget-object v0, p0, LBm/a;->b:Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;->g(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final i(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V
    .locals 1

    .line 1
    iget-object v0, p0, LBm/a;->b:Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;->p(Lorg/xbet/analytics/domain/scope/history/HistoryEventType;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final j(Ljava/lang/String;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    iget-object v0, p0, LBm/a;->c:LqR/a;

    .line 2
    .line 3
    iget-object v1, p0, LBm/a;->d:Ljava/lang/String;

    .line 4
    .line 5
    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 6
    .line 7
    .line 8
    move-result-wide v2

    .line 9
    invoke-interface {v0, v1, v2, v3}, LqR/a;->w(Ljava/lang/String;J)V

    .line 10
    .line 11
    .line 12
    return-void
.end method
