.class public final LBm/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldagger/internal/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ldagger/internal/d<",
        "LBm/a;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LZQ/b;",
            ">;"
        }
    .end annotation
.end field

.field public final b:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;",
            ">;"
        }
    .end annotation
.end field

.field public final c:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "LqR/a;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Ldagger/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldagger/internal/h<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "LZQ/b;",
            ">;",
            "Ldagger/internal/h<",
            "Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;",
            ">;",
            "Ldagger/internal/h<",
            "LqR/a;",
            ">;",
            "Ldagger/internal/h<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LBm/b;->a:Ldagger/internal/h;

    .line 5
    .line 6
    iput-object p2, p0, LBm/b;->b:Ldagger/internal/h;

    .line 7
    .line 8
    iput-object p3, p0, LBm/b;->c:Ldagger/internal/h;

    .line 9
    .line 10
    iput-object p4, p0, LBm/b;->d:Ldagger/internal/h;

    .line 11
    .line 12
    return-void
.end method

.method public static a(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)LBm/b;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldagger/internal/h<",
            "LZQ/b;",
            ">;",
            "Ldagger/internal/h<",
            "Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;",
            ">;",
            "Ldagger/internal/h<",
            "LqR/a;",
            ">;",
            "Ldagger/internal/h<",
            "Ljava/lang/String;",
            ">;)",
            "LBm/b;"
        }
    .end annotation

    .line 1
    new-instance v0, LBm/b;

    .line 2
    .line 3
    invoke-direct {v0, p0, p1, p2, p3}, LBm/b;-><init>(Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;Ldagger/internal/h;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public static c(LZQ/b;Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;LqR/a;Ljava/lang/String;)LBm/a;
    .locals 1

    .line 1
    new-instance v0, LBm/a;

    .line 2
    .line 3
    invoke-direct {v0, p0, p1, p2, p3}, LBm/a;-><init>(LZQ/b;Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;LqR/a;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method


# virtual methods
.method public b()LBm/a;
    .locals 4

    .line 1
    iget-object v0, p0, LBm/b;->a:Ldagger/internal/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lib/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LZQ/b;

    .line 8
    .line 9
    iget-object v1, p0, LBm/b;->b:Ldagger/internal/h;

    .line 10
    .line 11
    invoke-interface {v1}, Lib/a;->get()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;

    .line 16
    .line 17
    iget-object v2, p0, LBm/b;->c:Ldagger/internal/h;

    .line 18
    .line 19
    invoke-interface {v2}, Lib/a;->get()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    check-cast v2, LqR/a;

    .line 24
    .line 25
    iget-object v3, p0, LBm/b;->d:Ldagger/internal/h;

    .line 26
    .line 27
    invoke-interface {v3}, Lib/a;->get()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    check-cast v3, Ljava/lang/String;

    .line 32
    .line 33
    invoke-static {v0, v1, v2, v3}, LBm/b;->c(LZQ/b;Lorg/xbet/analytics/domain/scope/history/HistoryAnalytics;LqR/a;Ljava/lang/String;)LBm/a;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    return-object v0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, LBm/b;->b()LBm/a;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
