.class public final LC10/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LxZ0/i;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\u001e\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0012\u0008\u0080\u0008\u0018\u00002\u00020\u0001B\'\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\u0008\u00a2\u0006\u0004\u0008\n\u0010\u000bJ\u001f\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u000c\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\u0001H\u0016\u00a2\u0006\u0004\u0008\u000f\u0010\u0010J\u001f\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u000c\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\u0001H\u0016\u00a2\u0006\u0004\u0008\u0011\u0010\u0010J\'\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u00122\u0006\u0010\u000c\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\u0001H\u0016\u00a2\u0006\u0004\u0008\u0014\u0010\u0015J\u0010\u0010\u0017\u001a\u00020\u0016H\u00d6\u0001\u00a2\u0006\u0004\u0008\u0017\u0010\u0018J\u0010\u0010\u001a\u001a\u00020\u0019H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001a\u0010\u001bJ\u001a\u0010\u001e\u001a\u00020\u000e2\u0008\u0010\u001d\u001a\u0004\u0018\u00010\u001cH\u00d6\u0003\u00a2\u0006\u0004\u0008\u001e\u0010\u001fR\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008 \u0010!\u001a\u0004\u0008\"\u0010#R\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008$\u0010%\u001a\u0004\u0008&\u0010\u001bR\u0017\u0010\u0007\u001a\u00020\u00068\u0006\u00a2\u0006\u000c\n\u0004\u0008\'\u0010(\u001a\u0004\u0008)\u0010\u0018R\u0017\u0010\t\u001a\u00020\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008*\u0010+\u001a\u0004\u0008,\u0010-\u00a8\u0006."
    }
    d2 = {
        "LC10/e;",
        "LxZ0/i;",
        "LC10/c;",
        "limitType",
        "LC10/d;",
        "limitValue",
        "LC10/b;",
        "text",
        "LC10/a;",
        "limitSelected",
        "<init>",
        "(Lorg/xbet/finsecurity/impl/domain/LimitType;ILjava/lang/String;ZLkotlin/jvm/internal/DefaultConstructorMarker;)V",
        "oldItem",
        "newItem",
        "",
        "areItemsTheSame",
        "(LxZ0/i;LxZ0/i;)Z",
        "areContentsTheSame",
        "",
        "LxZ0/k;",
        "getChangePayload",
        "(LxZ0/i;LxZ0/i;)Ljava/util/Collection;",
        "",
        "toString",
        "()Ljava/lang/String;",
        "",
        "hashCode",
        "()I",
        "",
        "other",
        "equals",
        "(Ljava/lang/Object;)Z",
        "a",
        "Lorg/xbet/finsecurity/impl/domain/LimitType;",
        "getLimitType-O4gB_74",
        "()Lorg/xbet/finsecurity/impl/domain/LimitType;",
        "b",
        "I",
        "f",
        "c",
        "Ljava/lang/String;",
        "g",
        "d",
        "Z",
        "e",
        "()Z",
        "impl_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field public final a:Lorg/xbet/finsecurity/impl/domain/LimitType;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final b:I

.field public final c:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public final d:Z


# direct methods
.method public constructor <init>(Lorg/xbet/finsecurity/impl/domain/LimitType;ILjava/lang/String;Z)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, LC10/e;->a:Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 4
    iput p2, p0, LC10/e;->b:I

    .line 5
    iput-object p3, p0, LC10/e;->c:Ljava/lang/String;

    .line 6
    iput-boolean p4, p0, LC10/e;->d:Z

    return-void
.end method

.method public synthetic constructor <init>(Lorg/xbet/finsecurity/impl/domain/LimitType;ILjava/lang/String;ZLkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, LC10/e;-><init>(Lorg/xbet/finsecurity/impl/domain/LimitType;ILjava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public areContentsTheSame(LxZ0/i;LxZ0/i;)Z
    .locals 0
    .param p1    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public areItemsTheSame(LxZ0/i;LxZ0/i;)Z
    .locals 1
    .param p1    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    instance-of v0, p1, LC10/e;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    instance-of v0, p2, LC10/e;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    check-cast p1, LC10/e;

    .line 10
    .line 11
    iget-object p1, p1, LC10/e;->a:Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 12
    .line 13
    check-cast p2, LC10/e;

    .line 14
    .line 15
    iget-object p2, p2, LC10/e;->a:Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 16
    .line 17
    invoke-static {p1, p2}, LC10/c;->d(Lorg/xbet/finsecurity/impl/domain/LimitType;Lorg/xbet/finsecurity/impl/domain/LimitType;)Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    return p1

    .line 22
    :cond_0
    const/4 p1, 0x0

    .line 23
    return p1
.end method

.method public final e()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LC10/e;->d:Z

    .line 2
    .line 3
    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, LC10/e;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, LC10/e;

    .line 12
    .line 13
    iget-object v1, p0, LC10/e;->a:Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 14
    .line 15
    iget-object v3, p1, LC10/e;->a:Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 16
    .line 17
    invoke-static {v1, v3}, LC10/c;->d(Lorg/xbet/finsecurity/impl/domain/LimitType;Lorg/xbet/finsecurity/impl/domain/LimitType;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget v1, p0, LC10/e;->b:I

    .line 25
    .line 26
    iget v3, p1, LC10/e;->b:I

    .line 27
    .line 28
    invoke-static {v1, v3}, LC10/d;->b(II)Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-nez v1, :cond_3

    .line 33
    .line 34
    return v2

    .line 35
    :cond_3
    iget-object v1, p0, LC10/e;->c:Ljava/lang/String;

    .line 36
    .line 37
    iget-object v3, p1, LC10/e;->c:Ljava/lang/String;

    .line 38
    .line 39
    invoke-static {v1, v3}, LC10/b;->b(Ljava/lang/String;Ljava/lang/String;)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-nez v1, :cond_4

    .line 44
    .line 45
    return v2

    .line 46
    :cond_4
    iget-boolean v1, p0, LC10/e;->d:Z

    .line 47
    .line 48
    iget-boolean p1, p1, LC10/e;->d:Z

    .line 49
    .line 50
    invoke-static {v1, p1}, LC10/a;->b(ZZ)Z

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    if-nez p1, :cond_5

    .line 55
    .line 56
    return v2

    .line 57
    :cond_5
    return v0
.end method

.method public final f()I
    .locals 1

    .line 1
    iget v0, p0, LC10/e;->b:I

    .line 2
    .line 3
    return v0
.end method

.method public final g()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, LC10/e;->c:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getChangePayload(LxZ0/i;LxZ0/i;)Ljava/util/Collection;
    .locals 2
    .param p1    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # LxZ0/i;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LxZ0/i;",
            "LxZ0/i;",
            ")",
            "Ljava/util/Collection<",
            "LxZ0/k;",
            ">;"
        }
    .end annotation

    .line 1
    instance-of v0, p1, LC10/e;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    instance-of v0, p2, LC10/e;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 11
    .line 12
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 13
    .line 14
    .line 15
    check-cast p1, LC10/e;

    .line 16
    .line 17
    iget-object p1, p1, LC10/e;->a:Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 18
    .line 19
    invoke-static {p1}, LC10/c;->a(Lorg/xbet/finsecurity/impl/domain/LimitType;)LC10/c;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    check-cast p2, LC10/e;

    .line 24
    .line 25
    iget-object p2, p2, LC10/e;->a:Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 26
    .line 27
    invoke-static {p2}, LC10/c;->a(Lorg/xbet/finsecurity/impl/domain/LimitType;)LC10/c;

    .line 28
    .line 29
    .line 30
    move-result-object p2

    .line 31
    invoke-static {v0, p1, p2}, LGY0/a;->a(Ljava/util/Collection;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 35
    .line 36
    .line 37
    move-result p1

    .line 38
    if-nez p1, :cond_0

    .line 39
    .line 40
    return-object v0

    .line 41
    :cond_0
    return-object v1
.end method

.method public getKey()Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    invoke-static {p0}, LxZ0/h;->d(LxZ0/i;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public hashCode()I
    .locals 2

    .line 1
    iget-object v0, p0, LC10/e;->a:Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 2
    .line 3
    invoke-static {v0}, LC10/c;->e(Lorg/xbet/finsecurity/impl/domain/LimitType;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget v1, p0, LC10/e;->b:I

    .line 10
    .line 11
    invoke-static {v1}, LC10/d;->c(I)I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v0, v1

    .line 16
    mul-int/lit8 v0, v0, 0x1f

    .line 17
    .line 18
    iget-object v1, p0, LC10/e;->c:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1}, LC10/b;->c(Ljava/lang/String;)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    add-int/2addr v0, v1

    .line 25
    mul-int/lit8 v0, v0, 0x1f

    .line 26
    .line 27
    iget-boolean v1, p0, LC10/e;->d:Z

    .line 28
    .line 29
    invoke-static {v1}, LC10/a;->c(Z)I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    add-int/2addr v0, v1

    .line 34
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 6
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    iget-object v0, p0, LC10/e;->a:Lorg/xbet/finsecurity/impl/domain/LimitType;

    .line 2
    .line 3
    invoke-static {v0}, LC10/c;->f(Lorg/xbet/finsecurity/impl/domain/LimitType;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget v1, p0, LC10/e;->b:I

    .line 8
    .line 9
    invoke-static {v1}, LC10/d;->d(I)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iget-object v2, p0, LC10/e;->c:Ljava/lang/String;

    .line 14
    .line 15
    invoke-static {v2}, LC10/b;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    iget-boolean v3, p0, LC10/e;->d:Z

    .line 20
    .line 21
    invoke-static {v3}, LC10/a;->d(Z)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    new-instance v4, Ljava/lang/StringBuilder;

    .line 26
    .line 27
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 28
    .line 29
    .line 30
    const-string v5, "LimitSetUiModel(limitType="

    .line 31
    .line 32
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    const-string v0, ", limitValue="

    .line 39
    .line 40
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    const-string v0, ", text="

    .line 47
    .line 48
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    const-string v0, ", limitSelected="

    .line 55
    .line 56
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    const-string v0, ")"

    .line 63
    .line 64
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    return-object v0
.end method
