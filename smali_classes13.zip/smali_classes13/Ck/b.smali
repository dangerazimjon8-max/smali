.class public final LCk/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a\u0013\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u0000\u00a2\u0006\u0004\u0008\u0002\u0010\u0003\u00a8\u0006\u0004"
    }
    d2 = {
        "LDk/a;",
        "Lzk/d;",
        "a",
        "(LDk/a;)Lzk/d;",
        "impl_release"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final a(LDk/a;)Lzk/d;
    .locals 36
    .param p0    # LDk/a;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    invoke-virtual/range {p0 .. p0}, LDk/a;->a()Ljava/lang/Integer;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    move v5, v0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v5, 0x0

    .line 15
    :goto_0
    invoke-virtual/range {p0 .. p0}, LDk/a;->b()Ljava/lang/Long;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const-wide/16 v2, 0x0

    .line 20
    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 24
    .line 25
    .line 26
    move-result-wide v6

    .line 27
    move-wide v8, v6

    .line 28
    goto :goto_1

    .line 29
    :cond_1
    move-wide v8, v2

    .line 30
    :goto_1
    invoke-virtual/range {p0 .. p0}, LDk/a;->c()Ljava/lang/Integer;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    if-eqz v0, :cond_2

    .line 35
    .line 36
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    move v10, v0

    .line 41
    goto :goto_2

    .line 42
    :cond_2
    const/4 v10, 0x0

    .line 43
    :goto_2
    invoke-virtual/range {p0 .. p0}, LDk/a;->d()Ljava/lang/Double;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    const-wide/16 v6, 0x0

    .line 48
    .line 49
    if-eqz v0, :cond_3

    .line 50
    .line 51
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    .line 52
    .line 53
    .line 54
    move-result-wide v11

    .line 55
    goto :goto_3

    .line 56
    :cond_3
    move-wide v11, v6

    .line 57
    :goto_3
    invoke-virtual/range {p0 .. p0}, LDk/a;->e()Ljava/lang/Integer;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-eqz v0, :cond_4

    .line 62
    .line 63
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    move v13, v0

    .line 68
    goto :goto_4

    .line 69
    :cond_4
    const/4 v13, 0x0

    .line 70
    :goto_4
    invoke-virtual/range {p0 .. p0}, LDk/a;->f()Ljava/lang/Long;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    if-eqz v0, :cond_5

    .line 75
    .line 76
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 77
    .line 78
    .line 79
    move-result-wide v2

    .line 80
    :cond_5
    move-wide/from16 v20, v2

    .line 81
    .line 82
    invoke-virtual/range {p0 .. p0}, LDk/a;->g()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    const-string v2, ""

    .line 87
    .line 88
    if-nez v0, :cond_6

    .line 89
    .line 90
    move-object/from16 v23, v2

    .line 91
    .line 92
    goto :goto_5

    .line 93
    :cond_6
    move-object/from16 v23, v0

    .line 94
    .line 95
    :goto_5
    invoke-virtual/range {p0 .. p0}, LDk/a;->h()Ljava/lang/Double;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    if-eqz v0, :cond_7

    .line 100
    .line 101
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    .line 102
    .line 103
    .line 104
    move-result-wide v3

    .line 105
    move-wide/from16 v26, v3

    .line 106
    .line 107
    goto :goto_6

    .line 108
    :cond_7
    move-wide/from16 v26, v6

    .line 109
    .line 110
    :goto_6
    invoke-virtual/range {p0 .. p0}, LDk/a;->i()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    if-nez v0, :cond_8

    .line 115
    .line 116
    move-object/from16 v28, v2

    .line 117
    .line 118
    goto :goto_7

    .line 119
    :cond_8
    move-object/from16 v28, v0

    .line 120
    .line 121
    :goto_7
    invoke-virtual/range {p0 .. p0}, LDk/a;->j()Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    if-nez v0, :cond_9

    .line 126
    .line 127
    move-object/from16 v29, v2

    .line 128
    .line 129
    goto :goto_8

    .line 130
    :cond_9
    move-object/from16 v29, v0

    .line 131
    .line 132
    :goto_8
    invoke-virtual/range {p0 .. p0}, LDk/a;->k()Ljava/util/List;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    if-eqz v0, :cond_a

    .line 137
    .line 138
    new-instance v2, Ljava/util/ArrayList;

    .line 139
    .line 140
    const/16 v3, 0xa

    .line 141
    .line 142
    invoke-static {v0, v3}, Lkotlin/collections/x;->z(Ljava/lang/Iterable;I)I

    .line 143
    .line 144
    .line 145
    move-result v3

    .line 146
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 147
    .line 148
    .line 149
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    :goto_9
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 154
    .line 155
    .line 156
    move-result v3

    .line 157
    if-eqz v3, :cond_b

    .line 158
    .line 159
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    move-result-object v3

    .line 163
    check-cast v3, LDk/d;

    .line 164
    .line 165
    invoke-static {v3}, LCk/d;->a(LDk/d;)Lzk/g;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    invoke-interface {v2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 170
    .line 171
    .line 172
    goto :goto_9

    .line 173
    :cond_a
    const/4 v2, 0x0

    .line 174
    :cond_b
    if-nez v2, :cond_c

    .line 175
    .line 176
    invoke-static {}, Lkotlin/collections/w;->o()Ljava/util/List;

    .line 177
    .line 178
    .line 179
    move-result-object v2

    .line 180
    :cond_c
    move-object/from16 v30, v2

    .line 181
    .line 182
    invoke-virtual/range {p0 .. p0}, LDk/a;->l()Ljava/lang/Double;

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    if-eqz v0, :cond_d

    .line 187
    .line 188
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    .line 189
    .line 190
    .line 191
    move-result-wide v2

    .line 192
    move-wide/from16 v31, v2

    .line 193
    .line 194
    goto :goto_a

    .line 195
    :cond_d
    move-wide/from16 v31, v6

    .line 196
    .line 197
    :goto_a
    invoke-virtual/range {p0 .. p0}, LDk/a;->m()Ljava/lang/Double;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    if-eqz v0, :cond_e

    .line 202
    .line 203
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    .line 204
    .line 205
    .line 206
    move-result-wide v6

    .line 207
    :cond_e
    move-wide/from16 v33, v6

    .line 208
    .line 209
    invoke-virtual/range {p0 .. p0}, LDk/a;->n()Ljava/lang/Integer;

    .line 210
    .line 211
    .line 212
    move-result-object v0

    .line 213
    if-eqz v0, :cond_f

    .line 214
    .line 215
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 216
    .line 217
    .line 218
    move-result v1

    .line 219
    move/from16 v35, v1

    .line 220
    .line 221
    goto :goto_b

    .line 222
    :cond_f
    const/16 v35, 0x0

    .line 223
    .line 224
    :goto_b
    new-instance v2, Lzk/d;

    .line 225
    .line 226
    const/16 v24, 0x0

    .line 227
    .line 228
    const/16 v25, 0x0

    .line 229
    .line 230
    const-wide/16 v3, 0x0

    .line 231
    .line 232
    const-wide/16 v6, 0x0

    .line 233
    .line 234
    const/4 v14, 0x0

    .line 235
    const-wide/16 v15, 0x0

    .line 236
    .line 237
    const-wide/16 v17, 0x0

    .line 238
    .line 239
    const-string v19, ""

    .line 240
    .line 241
    const/16 v22, 0x0

    .line 242
    .line 243
    invoke-direct/range {v2 .. v35}, Lzk/d;-><init>(JIJJIDIZDJLjava/lang/String;JZLjava/lang/String;ZZDLjava/lang/String;Ljava/lang/String;Ljava/util/List;DDI)V

    .line 244
    .line 245
    .line 246
    return-object v2
.end method
