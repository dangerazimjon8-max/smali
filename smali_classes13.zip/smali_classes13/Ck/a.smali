.class public final LCk/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a\u0013\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u0000\u00a2\u0006\u0004\u0008\u0002\u0010\u0003\u00a8\u0006\u0004"
    }
    d2 = {
        "LGk/a;",
        "Ljn/a;",
        "a",
        "(LGk/a;)Ljn/a;",
        "impl_release"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final a(LGk/a;)Ljn/a;
    .locals 15
    .param p0    # LGk/a;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    new-instance v0, Ljn/a;

    .line 2
    .line 3
    invoke-virtual {p0}, LGk/a;->h()D

    .line 4
    .line 5
    .line 6
    move-result-wide v1

    .line 7
    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {p0}, LGk/a;->n()J

    .line 12
    .line 13
    .line 14
    move-result-wide v2

    .line 15
    invoke-virtual {p0}, LGk/a;->B()Z

    .line 16
    .line 17
    .line 18
    move-result v4

    .line 19
    if-eqz v4, :cond_0

    .line 20
    .line 21
    sget-object v4, Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;->LIVE:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    sget-object v4, Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;->LINE:Lorg/xbet/betting/core/zip/model/bet/KindEnumModel;

    .line 25
    .line 26
    :goto_0
    invoke-virtual {p0}, LGk/a;->q()D

    .line 27
    .line 28
    .line 29
    move-result-wide v5

    .line 30
    invoke-virtual {p0}, LGk/a;->s()J

    .line 31
    .line 32
    .line 33
    move-result-wide v7

    .line 34
    invoke-virtual {p0}, LGk/a;->A()J

    .line 35
    .line 36
    .line 37
    move-result-wide v9

    .line 38
    sget-object p0, Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;->DEFAULT:Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;

    .line 39
    .line 40
    invoke-virtual {p0}, Lorg/xbet/betting/core/coupon/models/CouponEntryFeature;->getFeatureId()I

    .line 41
    .line 42
    .line 43
    move-result v12

    .line 44
    const/16 v13, 0x40

    .line 45
    .line 46
    const/4 v14, 0x0

    .line 47
    const/4 v11, 0x0

    .line 48
    invoke-direct/range {v0 .. v14}, Ljn/a;-><init>(Ljava/lang/String;JLorg/xbet/betting/core/zip/model/bet/KindEnumModel;DJJLcom/xbet/onexuser/domain/betting/PlayersDuelModel;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 49
    .line 50
    .line 51
    return-object v0
.end method
